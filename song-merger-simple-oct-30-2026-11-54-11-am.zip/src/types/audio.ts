export interface YouTubeSongInfo {
  title: string;
  authorName: string;
  thumbnailUrl: string;
  canonicalUrl: string;
}

export interface TrackAnalysis {
  bpm: number | null;
  bpmConfidence: number;
  rmsDb: number;
}

export interface SongSlotState {
  ytUrl: string;
  ytInfo: YouTubeSongInfo | null;
  ytLoading: boolean;
  ytError: string | null;
  file: File | null;
  fileName: string | null;
  fullAudioBuffer: AudioBuffer | null;
  fullDurationSec: number;
  trimStartSec: number;
  trimEndSec: number;
  audioBuffer: AudioBuffer | null; // Active trimmed AudioBuffer used for merge
  durationSec: number; // Active trimmed duration (trimEndSec - trimStartSec)
  analysis: TrackAnalysis | null;
  fileLoading: boolean;
  fileError: string | null;
  filePermissionDenied?: boolean;
}

export type SpeedMode = 'preserve-pitch' | 'tape-pitch';

export interface MergeSettings {
  crossfadeSec: number; // 0 to 15, default 8
  autoMatch: boolean; // default true
  speedMode: SpeedMode; // default 'preserve-pitch' ("Speed — Pitch same rahe")
  speed: number; // 0.5 to 1.5, default 1.0
  pitchSemitones: number; // -6 to +6, default 0
  lofi: boolean; // default false
}

export interface MixRenderSummary {
  song1Bpm: number | null;
  song2Bpm: number | null;
  song2MatchedTempoRatio: number;
  song2PitchShiftSemitones: number;
  autoMatchApplied: boolean;
  effectiveCrossfadeSec: number;
  transitionStartSec: number;
  transitionEndSec: number;
  finalDurationSec: number;
  expectedDurationSec: number;
  fileSizeBytes: number;
  format: 'mp3' | 'wav';
  wavFallbackUsed: boolean;
}

export type MergePhase =
  | 'idle'
  | 'mixing'
  | 'mastering'
  | 'encoding'
  | 'ready'
  | 'error';
