import {
  analyzeTrackCore,
  encodeMp3OrWavCore,
  probeAudioLibrariesCore,
  renderMixDspCore,
  renderOverlapLoopDspCore,
} from '../utils/audioProcessorCore';
import { SpeedMode } from '../types/audio';

interface HealthProbeRequest {
  type: 'HEALTH_PROBE';
  id: string;
}

interface AnalyzeRequest {
  type: 'ANALYZE_TRACK';
  id: string;
  left: Float32Array;
  right: Float32Array;
  sampleRate: number;
  preferEndSection: boolean;
}

interface RenderDspRequest {
  type: 'RENDER_MIX_DSP';
  id: string;
  s1Left: Float32Array;
  s1Right: Float32Array;
  s2Left: Float32Array;
  s2Right: Float32Array;
  sampleRate: number;
  crossfadeSec: number;
  autoMatch: boolean;
  speedMode?: SpeedMode;
  speed: number;
  pitchSemitones: number;
  lofi: boolean;
  userTrimmedEnd1?: boolean;
  userTrimmedStart2?: boolean;
}

interface RenderOverlapLoopRequest {
  type: 'RENDER_OVERLAP_LOOP_DSP';
  id: string;
  s1Left: Float32Array;
  s1Right: Float32Array;
  s2Left: Float32Array;
  s2Right: Float32Array;
  sampleRate: number;
  crossfadeSec: number;
  autoMatch: boolean;
  speedMode?: SpeedMode;
  speed: number;
  pitchSemitones: number;
  lofi: boolean;
  userTrimmedEnd1?: boolean;
  userTrimmedStart2?: boolean;
}

interface EncodeMp3Request {
  type: 'ENCODE_MP3';
  id: string;
  left: Float32Array;
  right: Float32Array;
  sampleRate: number;
}

type WorkerIncomingMessage =
  | HealthProbeRequest
  | AnalyzeRequest
  | RenderDspRequest
  | RenderOverlapLoopRequest
  | EncodeMp3Request;

self.onmessage = (event: MessageEvent<WorkerIncomingMessage>) => {
  const msg = event.data;

  try {
    if (msg.type === 'HEALTH_PROBE') {
      const report = probeAudioLibrariesCore();
      (self as unknown as Worker).postMessage({
        type: 'HEALTH_PROBE_DONE',
        id: msg.id,
        report,
      });
      return;
    }

    if (msg.type === 'ANALYZE_TRACK') {
      const analysis = analyzeTrackCore(
        msg.left,
        msg.right,
        msg.sampleRate,
        msg.preferEndSection
      );
      (self as unknown as Worker).postMessage({
        type: 'ANALYZE_DONE',
        id: msg.id,
        analysis,
      });
      return;
    }

    if (msg.type === 'RENDER_MIX_DSP') {
      const result = renderMixDspCore({
        s1Left: msg.s1Left,
        s1Right: msg.s1Right,
        s2Left: msg.s2Left,
        s2Right: msg.s2Right,
        sampleRate: msg.sampleRate,
        crossfadeSec: msg.crossfadeSec,
        autoMatch: msg.autoMatch,
        speedMode: msg.speedMode ?? 'preserve-pitch',
        speed: msg.speed,
        pitchSemitones: msg.pitchSemitones,
        lofi: msg.lofi,
        userTrimmedEnd1: msg.userTrimmedEnd1,
        userTrimmedStart2: msg.userTrimmedStart2,
        onProgress: (percent, stage) => {
          (self as unknown as Worker).postMessage({
            type: 'DSP_PROGRESS',
            id: msg.id,
            percent,
            stage,
          });
        },
      });

      const outL: Float32Array = result.left;
      const outR: Float32Array = result.right;

      (self as unknown as Worker).postMessage(
        {
          type: 'RENDER_MIX_DSP_DONE',
          id: msg.id,
          left: outL,
          right: outR,
          stats: result.stats,
        },
        [outL.buffer as ArrayBuffer, outR.buffer as ArrayBuffer]
      );
      return;
    }

    if (msg.type === 'RENDER_OVERLAP_LOOP_DSP') {
      const res = renderOverlapLoopDspCore({
        s1Left: msg.s1Left,
        s1Right: msg.s1Right,
        s2Left: msg.s2Left,
        s2Right: msg.s2Right,
        sampleRate: msg.sampleRate,
        crossfadeSec: msg.crossfadeSec,
        autoMatch: msg.autoMatch,
        speedMode: msg.speedMode ?? 'preserve-pitch',
        speed: msg.speed,
        pitchSemitones: msg.pitchSemitones,
        lofi: msg.lofi,
        userTrimmedEnd1: msg.userTrimmedEnd1,
        userTrimmedStart2: msg.userTrimmedStart2,
      });

      const outL: Float32Array = res.left;
      const outR: Float32Array = res.right;

      (self as unknown as Worker).postMessage(
        {
          type: 'RENDER_OVERLAP_LOOP_DONE',
          id: msg.id,
          left: outL,
          right: outR,
          loopStartOutFrame: res.loopStartOutFrame,
          loopEndOutFrame: res.loopEndOutFrame,
          xfadeStartInLoopSec: res.xfadeStartInLoopSec,
          xfadeEndInLoopSec: res.xfadeEndInLoopSec,
        },
        [outL.buffer as ArrayBuffer, outR.buffer as ArrayBuffer]
      );
      return;
    }

    if (msg.type === 'ENCODE_MP3') {
      const encoded = encodeMp3OrWavCore(
        msg.left,
        msg.right,
        msg.sampleRate,
        (percent) => {
          (self as unknown as Worker).postMessage({
            type: 'MP3_PROGRESS',
            id: msg.id,
            percent,
          });
        }
      );

      (self as unknown as Worker).postMessage(
        {
          type: 'ENCODE_DONE',
          id: msg.id,
          buffer: encoded.buffer,
          format: encoded.format,
          wavFallbackUsed: encoded.wavFallbackUsed,
        },
        [encoded.buffer]
      );
      return;
    }
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Audio processing error';
    (self as unknown as Worker).postMessage({
      type: 'WORKER_ERROR',
      id: msg.id,
      error: message,
    });
  }
};
