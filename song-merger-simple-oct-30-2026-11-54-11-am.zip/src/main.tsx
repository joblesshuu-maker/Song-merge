import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

// Register PWA service worker safely so all audio libraries & UI work 100% offline after install
try {
  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    registerSW({
      immediate: true,
      onRegisterError() {
        // Ignore in custom WebViews that disable ServiceWorker registration
      },
    });
  }
} catch {
  // Ignore in restricted WebView environments
}

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
