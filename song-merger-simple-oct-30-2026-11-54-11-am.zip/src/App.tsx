/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2, RotateCcw, ShieldCheck, WifiOff, X } from 'lucide-react';
import { HealthCheckPanel } from './components/HealthCheckPanel';
import { InstallAppButton } from './components/InstallAppButton';
import { MergeControlsCard } from './components/MergeControlsCard';
import { MixOutputCard } from './components/MixOutputCard';
import { SongSlotCard } from './components/SongSlotCard';
import { useAudioPlayback } from './hooks/useAudioPlayback';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import {
  MergePhase,
  MergeSettings,
  MixRenderSummary,
  SongSlotState,
} from './types/audio';
import {
  analyzeTrackInWorker,
  decodeAudioFileTo44kStereo,
  FilePermissionError,
  isWebAudioAvailable,
  renderAndEncodeSeamlessMix,
  renderOverlapLoopBuffer,
  sliceAudioBuffer,
  verifyAudioLibrariesReady,
} from './utils/audioEngine';
import {
  canShareAudioFile,
  SaveAudioResult,
  saveExportedAudioFile,
  shareAudioFileWithSystem,
} from './utils/downloadHelper';
import { HealthCheckItem, runRealHealthChecks } from './utils/healthCheck';
import {
  isHealthCheckDismissed,
  loadPersistedSettings,
  savePersistedSettings,
  setHealthCheckDismissed,
} from './utils/settingsStorage';
import { fetchYouTubeSongInfo, OfflineNetworkError } from './utils/youtubeInfo';

const createEmptySlotState = (): SongSlotState => ({
  ytUrl: '',
  ytInfo: null,
  ytLoading: false,
  ytError: null,
  file: null,
  fileName: null,
  fullAudioBuffer: null,
  fullDurationSec: 0,
  trimStartSec: 0,
  trimEndSec: 0,
  audioBuffer: null,
  durationSec: 0,
  analysis: null,
  fileLoading: false,
  fileError: null,
  filePermissionDenied: false,
});

const INITIAL_CHECKING_ITEMS: HealthCheckItem[] = [
  {
    key: 'internet',
    label: 'Internet',
    status: 'checking',
    detail: 'Check ho raha hai...',
  },
  {
    key: 'webAudio',
    label: 'Web Audio',
    status: 'checking',
    detail: 'Check ho raha hai...',
  },
  {
    key: 'filePicker',
    label: 'File picker',
    status: 'checking',
    detail: 'Check ho raha hai...',
  },
  {
    key: 'audioLibs',
    label: 'Audio libraries loaded',
    status: 'checking',
    detail: 'Check ho raha hai...',
  },
  {
    key: 'download',
    label: 'Download test',
    status: 'checking',
    detail: 'Check ho raha hai...',
  },
];

export default function App() {
  const [slot1, setSlot1] = useState<SongSlotState>(createEmptySlotState);
  const [slot2, setSlot2] = useState<SongSlotState>(createEmptySlotState);
  const [settings, setSettings] = useState<MergeSettings>(() =>
    loadPersistedSettings()
  );

  const [phase, setPhase] = useState<MergePhase>('idle');
  const [dspStageText, setDspStageText] = useState<string>('');
  const [dspPercent, setDspPercent] = useState<number>(0);
  const [mp3Percent, setMp3Percent] = useState<number>(0);
  const [showLongEncodeHint, setShowLongEncodeHint] = useState<boolean>(false);
  const [mergeError, setMergeError] = useState<string | null>(null);
  const [globalErrorNotice, setGlobalErrorNotice] = useState<string | null>(null);

  const [previewBuffer, setPreviewBuffer] = useState<AudioBuffer | null>(null);
  const [exportBlob, setExportBlob] = useState<Blob | null>(null);
  const [mixSummary, setMixSummary] = useState<MixRenderSummary | null>(null);
  const [isStaleMix, setIsStaleMix] = useState<boolean>(false);
  const [downloadStatus, setDownloadStatus] = useState<SaveAudioResult | null>(
    null
  );

  // Overlap Loop state
  const [isLoopRendering, setIsLoopRendering] = useState<boolean>(false);
  const [loopErrorMessage, setLoopErrorMessage] = useState<string | null>(null);
  const [loopXfadeStartSec, setLoopXfadeStartSec] = useState<number>(0);
  const [loopXfadeEndSec, setLoopXfadeEndSec] = useState<number>(0);

  // Runtime capability & first-run Health Check state
  const [webAudioSupported, setWebAudioSupported] = useState<boolean>(() =>
    isWebAudioAvailable()
  );
  const [filePickerSupported, setFilePickerSupported] = useState<boolean>(true);
  const [audioLibsReady, setAudioLibsReady] = useState<boolean>(true);
  const [isCheckingLibs, setIsCheckingLibs] = useState<boolean>(false);

  const [healthOpen, setHealthOpen] = useState<boolean>(
    () => !isHealthCheckDismissed()
  );
  const [healthRunning, setHealthRunning] = useState<boolean>(false);
  const [healthItems, setHealthItems] = useState<HealthCheckItem[]>(
    INITIAL_CHECKING_ITEMS
  );

  const { isOnline, isChecking, recheckInternet, markOffline } =
    useOnlineStatus();

  const slot1Ref = useRef<SongSlotState>(slot1);
  const slot2Ref = useRef<SongSlotState>(slot2);
  const settingsRef = useRef<MergeSettings>(settings);
  slot1Ref.current = slot1;
  slot2Ref.current = slot2;
  settingsRef.current = settings;

  const loopAbortRef = useRef<AbortController | null>(null);
  const trimLoopDebounceRef = useRef<number | null>(null);
  const encodeTimerRef = useRef<number | null>(null);
  const trimAnalyzeTimersRef = useRef<{ 1: number | null; 2: number | null }>({
    1: null,
    2: null,
  });

  const playback = useAudioPlayback();

  // Persist user settings across restarts (crossfade, speedMode, speed, pitch, lofi, autoMatch)
  useEffect(() => {
    savePersistedSettings(settings);
  }, [settings]);

  // Catch any unexpected unhandled promise rejections so errors never fail silently
  useEffect(() => {
    const onUnhandledRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      if (reason instanceof DOMException && reason.name === 'AbortError') {
        event.preventDefault();
        return;
      }
      const msg =
        reason instanceof Error && reason.message
          ? reason.message
          : 'Ek unexpected error aaya — kripya Retry karein.';
      setGlobalErrorNotice(msg);
      event.preventDefault();
    };

    window.addEventListener('unhandledrejection', onUnhandledRejection);
    return () => {
      window.removeEventListener('unhandledrejection', onUnhandledRejection);
    };
  }, []);

  const executeHealthCheck = useCallback(async (forceOpenPanel: boolean) => {
    if (forceOpenPanel) {
      setHealthOpen(true);
    }
    setHealthRunning(true);
    setHealthItems(INITIAL_CHECKING_ITEMS);

    try {
      const report = await runRealHealthChecks();
      setHealthItems(report.items);
      setWebAudioSupported(report.webAudioOk);
      setFilePickerSupported(report.filePickerOk);
      setAudioLibsReady(report.audioLibsOk);

      // If any core local capability failed even after dismissal, surface panel so user sees plain fix
      if (!report.webAudioOk || !report.audioLibsOk || !report.filePickerOk) {
        setHealthOpen(true);
      }
    } catch {
      setHealthOpen(true);
    } finally {
      setHealthRunning(false);
    }
  }, []);

  // Run real capability & first-run health check on startup
  useEffect(() => {
    executeHealthCheck(!isHealthCheckDismissed());
  }, [executeHealthCheck]);

  const handleRetryLoadLibraries = useCallback(async () => {
    setIsCheckingLibs(true);
    try {
      const res = await verifyAudioLibrariesReady();
      setAudioLibsReady(res.ready);
      if (!res.ready) {
        setMergeError(
          'Audio library abhi bhi load nahi ho payi — internet check karke Retry dabao ya app reload karo.'
        );
      } else {
        setMergeError(null);
      }
    } finally {
      setIsCheckingLibs(false);
    }
  }, []);

  const cancelPendingLoopRender = useCallback(() => {
    if (loopAbortRef.current) {
      loopAbortRef.current.abort();
      loopAbortRef.current = null;
    }
    if (trimLoopDebounceRef.current !== null) {
      window.clearTimeout(trimLoopDebounceRef.current);
      trimLoopDebounceRef.current = null;
    }
    setIsLoopRendering(false);
  }, []);

  const clearEncodeHintTimer = useCallback(() => {
    if (encodeTimerRef.current !== null) {
      window.clearTimeout(encodeTimerRef.current);
      encodeTimerRef.current = null;
    }
    setShowLongEncodeHint(false);
  }, []);

  useEffect(() => {
    return () => {
      cancelPendingLoopRender();
      clearEncodeHintTimer();
      if (trimAnalyzeTimersRef.current[1] !== null) {
        window.clearTimeout(trimAnalyzeTimersRef.current[1]);
      }
      if (trimAnalyzeTimersRef.current[2] !== null) {
        window.clearTimeout(trimAnalyzeTimersRef.current[2]);
      }
    };
  }, [cancelPendingLoopRender, clearEncodeHintTimer]);

  const markMixStaleIfPresent = useCallback(() => {
    setDownloadStatus(null);
    setPreviewBuffer((curr) => {
      if (curr) {
        setIsStaleMix(true);
      }
      return curr;
    });
  }, []);

  /**
   * Renders & starts/updates the Overlap Loop (-3s before crossfade start to +3s after crossfade end)
   * using all current settings & trims. Surfaces plain-words error + Retry if anything fails.
   */
  const startOrUpdateOverlapLoop = useCallback(
    async (
      overrideSettings?: MergeSettings,
      overrideS1?: SongSlotState,
      overrideS2?: SongSlotState
    ) => {
      const s1 = overrideS1 ?? slot1Ref.current;
      const s2 = overrideS2 ?? slot2Ref.current;
      const activeSettings = overrideSettings ?? settingsRef.current;

      if (!s1.audioBuffer || !s2.audioBuffer) return;

      if (loopAbortRef.current) {
        loopAbortRef.current.abort();
      }
      const abortController = new AbortController();
      loopAbortRef.current = abortController;
      setIsLoopRendering(true);
      setLoopErrorMessage(null);

      const userTrimmedEnd1 =
        s1.fullDurationSec > 0 && s1.trimEndSec < s1.fullDurationSec - 0.1;
      const userTrimmedStart2 = s2.trimStartSec > 0.1;

      try {
        const res = await renderOverlapLoopBuffer(
          s1.audioBuffer,
          s2.audioBuffer,
          activeSettings,
          {
            userTrimmedEnd1,
            userTrimmedStart2,
            signal: abortController.signal,
          }
        );

        if (abortController.signal.aborted) return;

        setLoopXfadeStartSec(res.xfadeStartInLoopSec);
        setLoopXfadeEndSec(res.xfadeEndInLoopSec);
        setIsLoopRendering(false);
        await playback.playOverlapLoop(res.loopBuffer);
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          return;
        }
        setIsLoopRendering(false);
        const msg =
          err instanceof Error && err.message
            ? err.message
            : 'Overlap loop chalane me dikkat aayi — Retry dabao.';
        setLoopErrorMessage(msg);
      }
    },
    [playback]
  );

  const handleStopOverlapLoop = useCallback(() => {
    cancelPendingLoopRender();
    setLoopErrorMessage(null);
    playback.stopOverlapLoop();
  }, [cancelPendingLoopRender, playback]);

  // YouTube Info handlers (never downloads audio — strictly metadata via oEmbed)
  const handleFetchYtInfo = async (slotNum: 1 | 2) => {
    const target = slotNum === 1 ? slot1 : slot2;
    const setTarget = slotNum === 1 ? setSlot1 : setSlot2;

    if (!target.ytUrl.trim()) return;

    setTarget((prev) => ({
      ...prev,
      ytLoading: true,
      ytError: null,
    }));

    try {
      const info = await fetchYouTubeSongInfo(target.ytUrl);
      setTarget((prev) => ({
        ...prev,
        ytInfo: info,
        ytLoading: false,
        ytError: null,
      }));
    } catch (err) {
      if (err instanceof OfflineNetworkError) {
        markOffline();
      }
      const msg =
        err instanceof Error
          ? err.message
          : 'YouTube info fetch nahi ho paya — Retry dabao.';
      setTarget((prev) => ({
        ...prev,
        ytLoading: false,
        ytError: msg,
      }));
    }
  };

  const handleClearYtInfo = (slotNum: 1 | 2) => {
    const setTarget = slotNum === 1 ? setSlot1 : setSlot2;
    setTarget((prev) => ({
      ...prev,
      ytUrl: '',
      ytInfo: null,
      ytError: null,
    }));
  };

  const handleFilePermissionError = (slotNum: 1 | 2) => {
    const setTarget = slotNum === 1 ? setSlot1 : setSlot2;
    setTarget((prev) => ({
      ...prev,
      fileLoading: false,
      filePermissionDenied: true,
      fileError: 'Permission nahi mili — File chuno kaam nahi karega',
    }));
  };

  // Device Audio File Import handler (stops Overlap Loop when a song file changes)
  const handleSelectFile = async (slotNum: 1 | 2, file: File) => {
    const playerId = slotNum === 1 ? 'song1' : 'song2';
    const setTarget = slotNum === 1 ? setSlot1 : setSlot2;

    if (trimAnalyzeTimersRef.current[slotNum] !== null) {
      window.clearTimeout(trimAnalyzeTimersRef.current[slotNum]!);
      trimAnalyzeTimersRef.current[slotNum] = null;
    }

    cancelPendingLoopRender();
    setLoopErrorMessage(null);
    playback.stopOverlapLoop();
    playback.resetSlot(playerId);
    playback.resetSlot('mix');

    setPreviewBuffer(null);
    setExportBlob(null);
    setMixSummary(null);
    setDownloadStatus(null);
    setIsStaleMix(false);
    setPhase('idle');
    setMergeError(null);

    setTarget((prev) => ({
      ...prev,
      file,
      fileName: file.name,
      fileLoading: true,
      fileError: null,
      filePermissionDenied: false,
      fullAudioBuffer: null,
      fullDurationSec: 0,
      trimStartSec: 0,
      trimEndSec: 0,
      audioBuffer: null,
      durationSec: 0,
      analysis: null,
    }));

    try {
      const buffer44k = await decodeAudioFileTo44kStereo(file);
      const fullDur = buffer44k.duration;
      setTarget((prev) => ({
        ...prev,
        fullAudioBuffer: buffer44k,
        fullDurationSec: fullDur,
        trimStartSec: 0,
        trimEndSec: fullDur,
        audioBuffer: buffer44k,
        durationSec: fullDur,
        fileLoading: false,
        fileError: null,
        filePermissionDenied: false,
      }));

      const analysis = await analyzeTrackInWorker(buffer44k, slotNum === 1);
      setTarget((prev) =>
        prev.audioBuffer === buffer44k
          ? {
              ...prev,
              analysis,
            }
          : prev
      );
    } catch (err) {
      const isPermDenied = err instanceof FilePermissionError;
      const msg =
        err instanceof Error
          ? err.message
          : 'Audio file load nahi ho payi. Sahi MP3/WAV/M4A chuno aur Retry dabao.';
      setTarget((prev) => ({
        ...prev,
        fileLoading: false,
        fileError: msg,
        filePermissionDenied: isPermDenied,
      }));
    }
  };

  // Cut/Trim handler: updates trimmed portion immediately without stopping slot playback when cutting live!
  const handleTrimChange = useCallback(
    (
      slotNum: 1 | 2,
      newStartSec: number,
      newEndSec: number,
      preserveSlotPlayback = false
    ) => {
      const playerId = slotNum === 1 ? 'song1' : 'song2';
      const setTarget = slotNum === 1 ? setSlot1 : setSlot2;

      if (!preserveSlotPlayback) {
        playback.resetSlot(playerId);
      }
      if (playback.playingId === 'mix') {
        playback.stopNonLoopPlayers();
      }
      markMixStaleIfPresent();

      const currentSlot = slotNum === 1 ? slot1Ref.current : slot2Ref.current;
      if (!currentSlot.fullAudioBuffer) return;

      const minLen = Math.min(
        0.5,
        Math.max(0.1, currentSlot.fullDurationSec * 0.25)
      );
      const clampedStart = Math.max(
        0,
        Math.min(currentSlot.fullDurationSec - minLen, newStartSec)
      );
      const clampedEnd = Math.max(
        clampedStart + minLen,
        Math.min(currentSlot.fullDurationSec, newEndSec)
      );

      let trimmedBuf: AudioBuffer;
      try {
        trimmedBuf = sliceAudioBuffer(
          currentSlot.fullAudioBuffer,
          clampedStart,
          clampedEnd
        );
      } catch (err) {
        const msg =
          err instanceof Error
            ? err.message
            : 'Trim karne me dikkat aayi — dobara try karein.';
        setTarget((curr) => ({ ...curr, fileError: msg }));
        return;
      }

      const updatedSlot: SongSlotState = {
        ...currentSlot,
        trimStartSec: clampedStart,
        trimEndSec: clampedEnd,
        audioBuffer: trimmedBuf,
        durationSec: trimmedBuf.duration,
      };

      if (slotNum === 1) {
        slot1Ref.current = updatedSlot;
      } else {
        slot2Ref.current = updatedSlot;
      }

      setTarget(updatedSlot);

      if (trimAnalyzeTimersRef.current[slotNum] !== null) {
        window.clearTimeout(trimAnalyzeTimersRef.current[slotNum]!);
      }
      trimAnalyzeTimersRef.current[slotNum] = window.setTimeout(async () => {
        const updatedAnalysis = await analyzeTrackInWorker(
          trimmedBuf,
          slotNum === 1
        );
        setTarget((curr) =>
          curr.audioBuffer === trimmedBuf
            ? { ...curr, analysis: updatedAnalysis }
            : curr
        );
      }, 350);

      // If Overlap Loop is already playing, update it seamlessly to reflect the new trim point!
      if (playback.isLoopPlaying) {
        if (trimLoopDebounceRef.current !== null) {
          window.clearTimeout(trimLoopDebounceRef.current);
        }
        trimLoopDebounceRef.current = window.setTimeout(() => {
          trimLoopDebounceRef.current = null;
          startOrUpdateOverlapLoop(
            settingsRef.current,
            slotNum === 1 ? updatedSlot : slot1Ref.current,
            slotNum === 2 ? updatedSlot : slot2Ref.current
          );
        }, 180);
      }
    },
    [markMixStaleIfPresent, playback, startOrUpdateOverlapLoop]
  );

  // Live UI update while dragging slider (does NOT stop running Overlap Loop!)
  const handleSettingsChange = useCallback(
    (nextSettings: MergeSettings) => {
      if (playback.playingId === 'mix') {
        playback.stopNonLoopPlayers();
      }
      settingsRef.current = nextSettings;
      setSettings(nextSettings);
      savePersistedSettings(nextSettings);
      markMixStaleIfPresent();
    },
    [markMixStaleIfPresent, playback]
  );

  // Triggered strictly when Crossfade/Speed/Pitch slider settles OR Lofi/AutoMatch/SpeedMode changes
  const handleControlSettled = useCallback(
    (settledSettings: MergeSettings, shouldAutoStartLoop: boolean) => {
      settingsRef.current = settledSettings;
      savePersistedSettings(settledSettings);
      const bothSongsLoaded = Boolean(
        slot1Ref.current.audioBuffer && slot2Ref.current.audioBuffer
      );
      if (!bothSongsLoaded || !audioLibsReady || !webAudioSupported) return;

      if (shouldAutoStartLoop || playback.isLoopPlaying) {
        startOrUpdateOverlapLoop(settledSettings);
      }
    },
    [
      audioLibsReady,
      playback.isLoopPlaying,
      startOrUpdateOverlapLoop,
      webAudioSupported,
    ]
  );

  // Full offline Mix Render + 320 kbps MP3 Export (stops Overlap Loop when export starts)
  const runMergePipeline = useCallback(
    async (autoPlayWhenPreviewReady = false) => {
      if (!slot1.audioBuffer || !slot2.audioBuffer) return;

      cancelPendingLoopRender();
      setLoopErrorMessage(null);
      playback.stopAll();
      playback.resetSlot('mix');
      clearEncodeHintTimer();

      setMergeError(null);
      setExportBlob(null);
      setMixSummary(null);
      setDownloadStatus(null);
      setIsStaleMix(false);
      setDspPercent(2);
      setMp3Percent(0);
      setDspStageText('Mix shuru ho raha hai...');
      setPhase('mixing');

      const userTrimmedEnd1 =
        slot1.fullDurationSec > 0 &&
        slot1.trimEndSec < slot1.fullDurationSec - 0.1;
      const userTrimmedStart2 = slot2.trimStartSec > 0.1;

      try {
        const result = await renderAndEncodeSeamlessMix(
          slot1.audioBuffer,
          slot2.audioBuffer,
          settings,
          {
            onDspProgress: (pct, stageText) => {
              setDspPercent(pct);
              setDspStageText(stageText);
              if (pct >= 100) {
                setPhase('mastering');
              }
            },
            onPreviewBufferReady: (readyBuffer) => {
              setPreviewBuffer(readyBuffer);
              setPhase('encoding');
              clearEncodeHintTimer();
              encodeTimerRef.current = window.setTimeout(() => {
                setShowLongEncodeHint(true);
              }, 3200);

              if (autoPlayWhenPreviewReady) {
                playback.playFromOffset('mix', readyBuffer, 0).catch(() => {});
              }
            },
            onMp3Progress: (pct) => {
              setMp3Percent(pct);
            },
          },
          {
            userTrimmedEnd1,
            userTrimmedStart2,
          }
        );

        clearEncodeHintTimer();
        setPreviewBuffer(result.previewBuffer);
        setExportBlob(result.exportBlob);
        setMixSummary(result.summary);
        setIsStaleMix(false);
        setPhase('ready');
      } catch (err) {
        clearEncodeHintTimer();
        const msg =
          err instanceof Error
            ? err.message
            : 'Mix banane mein dikkat aayi. Niche Retry dabakar dobara koshish karein.';
        setMergeError(msg);
        setPhase('error');
      }
    },
    [
      cancelPendingLoopRender,
      clearEncodeHintTimer,
      playback,
      settings,
      slot1.audioBuffer,
      slot1.fullDurationSec,
      slot1.trimEndSec,
      slot2.audioBuffer,
      slot2.trimStartSec,
    ]
  );

  const handleToggleSlotPreview = async (slotNum: 1 | 2) => {
    const slotState = slotNum === 1 ? slot1 : slot2;
    const setTarget = slotNum === 1 ? setSlot1 : setSlot2;
    const id = slotNum === 1 ? 'song1' : 'song2';
    try {
      await playback.togglePlay(
        id,
        slotState.fullAudioBuffer,
        slotState.trimStartSec
      );
    } catch {
      setTarget((prev) => ({
        ...prev,
        fileError: 'Audio preview play nahi ho paya — Retry ya Play dobara dabao.',
      }));
    }
  };

  const handleToggleMixPreview = async () => {
    cancelPendingLoopRender();
    playback.stopOverlapLoop();
    if (isStaleMix && slot1.audioBuffer && slot2.audioBuffer) {
      await runMergePipeline(true);
      return;
    }
    try {
      await playback.togglePlay('mix', previewBuffer);
    } catch {
      setMergeError(
        'Mixed preview play nahi ho paya — phone silent mode check karke Play dobara dabao.'
      );
    }
  };

  const handleJumpToJoin = async () => {
    if (!previewBuffer || !mixSummary) return;
    cancelPendingLoopRender();
    playback.stopOverlapLoop();
    const preRollSec = Math.max(0, mixSummary.transitionStartSec - 4);
    try {
      await playback.playFromOffset('mix', previewBuffer, preRollSec);
    } catch {
      setMergeError('Transition preview play nahi ho paya — dobara try karein.');
    }
  };

  const handleDownload = async () => {
    if (!exportBlob || !mixSummary) {
      setDownloadStatus({
        ok: false,
        method: 'none',
        message: 'MP3 file abhi taiyaar nahi hai. Pehle Merge karo dabayein.',
      });
      return;
    }

    cancelPendingLoopRender();
    playback.stopOverlapLoop();

    const ext = mixSummary.format === 'mp3' ? 'mp3' : 'wav';
    const mimeType = mixSummary.format === 'mp3' ? 'audio/mpeg' : 'audio/wav';
    const filename = `merged-song.${ext}`;

    const res = await saveExportedAudioFile(exportBlob, filename, mimeType);
    setDownloadStatus(res);
  };

  const handleShareExportFile = async () => {
    if (!exportBlob || !mixSummary) return;
    cancelPendingLoopRender();
    playback.stopOverlapLoop();

    const ext = mixSummary.format === 'mp3' ? 'mp3' : 'wav';
    const mimeType = mixSummary.format === 'mp3' ? 'audio/mpeg' : 'audio/wav';
    const filename = `merged-song.${ext}`;

    const res = await shareAudioFileWithSystem(exportBlob, filename, mimeType);
    setDownloadStatus(res);
  };

  const canMerge = Boolean(
    webAudioSupported &&
      audioLibsReady &&
      slot1.audioBuffer &&
      slot2.audioBuffer &&
      !slot1.fileLoading &&
      !slot2.fileLoading
  );

  const canShareCurrentExport = Boolean(
    exportBlob &&
      mixSummary &&
      canShareAudioFile(
        exportBlob,
        `merged-song.${mixSummary.format === 'mp3' ? 'mp3' : 'wav'}`,
        mixSummary.format === 'mp3' ? 'audio/mpeg' : 'audio/wav'
      )
  );

  let missingFilesReason: string | null = null;
  if (!slot1.audioBuffer && !slot2.audioBuffer) {
    if (
      slot1.ytUrl.trim() ||
      slot2.ytUrl.trim() ||
      slot1.ytInfo ||
      slot2.ytInfo
    ) {
      missingFilesReason =
        'Merge ke liye audio file import karo (Song 1 aur Song 2 dono).';
    } else {
      missingFilesReason =
        'Shuru karne ke liye Song 1 aur Song 2 ki audio files chuno.';
    }
  } else if (!slot1.audioBuffer) {
    missingFilesReason = 'Song 1: Merge ke liye audio file import karo.';
  } else if (!slot2.audioBuffer) {
    missingFilesReason = 'Song 2: Merge ke liye audio file import karo.';
  }

  return (
    <div className="min-h-screen flex flex-col bg-black text-[#E0E0E0]">
      {/* Clean single-row Top Bar on pure black background */}
      <header className="bg-black border-b border-[#2A2A2A] px-4 sm:px-6 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
          <span className="text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0">
            Song Merger
          </span>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                setHealthCheckDismissed(false);
                executeHealthCheck(true);
              }}
              className="min-h-[38px] px-2.5 sm:px-3 py-1.5 text-xs font-medium text-white bg-[#222222] border border-[#2A2A2A] hover:bg-[#2C2C2C] rounded-lg transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-white shrink-0" />
              <span>Health check</span>
            </button>

            <InstallAppButton />

            <button
              type="button"
              disabled={
                phase === 'mixing' ||
                phase === 'mastering' ||
                phase === 'encoding'
              }
              onClick={() => {
                cancelPendingLoopRender();
                setLoopErrorMessage(null);
                playback.stopAll();
                playback.resetSlot('song1');
                playback.resetSlot('song2');
                playback.resetSlot('mix');
                setSlot1(createEmptySlotState());
                setSlot2(createEmptySlotState());
                setPreviewBuffer(null);
                setExportBlob(null);
                setMixSummary(null);
                setDownloadStatus(null);
                setIsStaleMix(false);
                setMergeError(null);
                setPhase('idle');
              }}
              className="min-h-[38px] px-3 py-1.5 text-xs font-medium text-white bg-[#222222] border border-[#2A2A2A] hover:bg-[#2C2C2C] disabled:opacity-45 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Naya Mix
            </button>
          </div>
        </div>
      </header>

      {/* Main Single-Screen Workspace */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-5 sm:py-8">
        <div className="mb-5 sm:mb-6">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white [text-wrap:balance]">
            Do gaanon ko ek seamless track mein merge karo
          </h1>
          <p className="text-sm text-[#E0E0E0] mt-1 max-w-2xl leading-relaxed">
            Equal-power crossfade, loudness match aur auto tempo sync ke saath — bina kisi cut, gap ya sudden volume jump ke. Sab kuch aapke phone/device par hota hai.
          </p>
        </div>

        {/* Offline Assurance Banner: dark surface + Retry */}
        {!isOnline && (
          <div
            role="status"
            className="mb-5 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-4 py-3 text-xs text-[#E0E0E0] flex items-center justify-between gap-3"
          >
            <div className="flex items-start gap-2.5 min-w-0">
              <WifiOff className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong className="font-semibold text-white">Internet nahi hai</strong> — YouTube info aur player abhi nahi chalega, lekin{' '}
                <strong className="font-semibold text-white">
                  File chuno, Trim, Merge, Preview aur 320 kbps MP3 Export
                </strong>{' '}
                bina internet ke poora kaam karenge.
              </div>
            </div>
            <button
              type="button"
              disabled={isChecking}
              onClick={recheckInternet}
              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
            >
              {isChecking ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
              ) : (
                <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              )}
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Global Unexpected Error Notice (never silent failure, dark surface) */}
        {globalErrorNotice && (
          <div
            role="alert"
            className="mb-5 rounded-2xl border border-red-500/45 bg-[#111111] px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3"
          >
            <span className="inline-flex items-start gap-2 min-w-0">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{globalErrorNotice}</span>
            </span>
            <button
              type="button"
              onClick={() => setGlobalErrorNotice(null)}
              aria-label="Dismiss error"
              className="min-h-[34px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] shrink-0 inline-flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Band karo</span>
            </button>
          </div>
        )}

        {/* First-run & Re-runnable Real Health Check */}
        <HealthCheckPanel
          isOpen={healthOpen}
          isRunning={healthRunning}
          items={healthItems}
          onRerun={() => executeHealthCheck(true)}
          onDismiss={() => {
            setHealthCheckDismissed(true);
            setHealthOpen(false);
          }}
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-6 items-start">
          {/* Left Column: Song 1 & Song 2 Slots */}
          <div className="lg:col-span-7 space-y-5">
            <SongSlotCard
              slotNumber={1}
              slotState={slot1}
              isOnline={isOnline}
              isCheckingInternet={isChecking}
              webAudioSupported={webAudioSupported}
              filePickerSupported={filePickerSupported}
              isPlaying={playback.playingId === 'song1'}
              currentTimeSec={playback.positions.song1}
              getLiveSlotPosition={() => playback.getLivePosition('song1')}
              onYtUrlChange={(url) =>
                setSlot1((prev) => ({ ...prev, ytUrl: url, ytError: null }))
              }
              onFetchYtInfo={() => handleFetchYtInfo(1)}
              onClearYtInfo={() => handleClearYtInfo(1)}
              onRecheckInternet={recheckInternet}
              onSelectFile={(file) => handleSelectFile(1, file)}
              onFilePermissionError={() => handleFilePermissionError(1)}
              onTrimChange={(start, end, preservePlay) =>
                handleTrimChange(1, start, end, preservePlay)
              }
              onTogglePreview={() => handleToggleSlotPreview(1)}
              onSeekPreview={(t) => {
                playback.seek('song1', slot1.fullAudioBuffer, t).catch(() => {});
              }}
            />

            <SongSlotCard
              slotNumber={2}
              slotState={slot2}
              isOnline={isOnline}
              isCheckingInternet={isChecking}
              webAudioSupported={webAudioSupported}
              filePickerSupported={filePickerSupported}
              isPlaying={playback.playingId === 'song2'}
              currentTimeSec={playback.positions.song2}
              getLiveSlotPosition={() => playback.getLivePosition('song2')}
              onYtUrlChange={(url) =>
                setSlot2((prev) => ({ ...prev, ytUrl: url, ytError: null }))
              }
              onFetchYtInfo={() => handleFetchYtInfo(2)}
              onClearYtInfo={() => handleClearYtInfo(2)}
              onRecheckInternet={recheckInternet}
              onSelectFile={(file) => handleSelectFile(2, file)}
              onFilePermissionError={() => handleFilePermissionError(2)}
              onTrimChange={(start, end, preservePlay) =>
                handleTrimChange(2, start, end, preservePlay)
              }
              onTogglePreview={() => handleToggleSlotPreview(2)}
              onSeekPreview={(t) => {
                playback.seek('song2', slot2.fullAudioBuffer, t).catch(() => {});
              }}
            />
          </div>

          {/* Right Column: Mix Controls + Overlap Loop + Render & MP3 Download */}
          <div className="lg:col-span-5 space-y-5">
            <MergeControlsCard
              settings={settings}
              song1Analysis={slot1.analysis}
              song2Analysis={slot2.analysis}
              webAudioSupported={webAudioSupported}
              audioLibsReady={audioLibsReady}
              disabled={
                phase === 'mixing' ||
                phase === 'mastering' ||
                phase === 'encoding'
              }
              onChange={handleSettingsChange}
              onControlSettled={handleControlSettled}
              onUserAudioGesture={playback.unlockAudio}
            />

            <MixOutputCard
              canMerge={canMerge}
              webAudioSupported={webAudioSupported}
              audioLibsReady={audioLibsReady}
              isCheckingLibs={isCheckingLibs}
              onRetryLoadLibraries={handleRetryLoadLibraries}
              missingFilesReason={missingFilesReason}
              phase={phase}
              dspStageText={dspStageText}
              dspPercent={dspPercent}
              mp3Percent={mp3Percent}
              showLongEncodeHint={showLongEncodeHint}
              errorMessage={mergeError}
              previewBuffer={previewBuffer}
              summary={mixSummary}
              isStaleMix={isStaleMix}
              isPlayingMix={playback.playingId === 'mix'}
              mixCurrentTimeSec={playback.positions.mix}
              isLoopPlaying={playback.isLoopPlaying}
              isLoopRendering={isLoopRendering}
              loopErrorMessage={loopErrorMessage}
              loopPositionSec={playback.loopPosition}
              loopDurationSec={playback.loopDuration}
              loopXfadeStartSec={loopXfadeStartSec}
              loopXfadeEndSec={loopXfadeEndSec}
              onStartOverlapLoop={() => {
                playback.unlockAudio();
                startOrUpdateOverlapLoop();
              }}
              onStopOverlapLoop={handleStopOverlapLoop}
              onMergeClick={() => runMergePipeline(false)}
              onToggleMixPlay={handleToggleMixPreview}
              onSeekMix={(t) => {
                playback.seek('mix', previewBuffer, t).catch(() => {});
              }}
              onJumpToJoin={handleJumpToJoin}
              onDownloadClick={handleDownload}
              canShareExportFile={canShareCurrentExport}
              onShareFileClick={handleShareExportFile}
              downloadStatus={downloadStatus}
            />
          </div>
        </div>
      </main>

      {/* Quiet, clean personal-use footer */}
      <footer className="py-4 px-4 sm:px-6 text-center text-xs text-[#AAAAAA] border-t border-[#2A2A2A]">
        Personal use only · Sirf Internet (YouTube info) aur File Picker (gaana import/MP3 save) use hota hai — saari audio processing phone par offline hoti hai.
      </footer>
    </div>
  );
}
