import { SoundTouch } from 'soundtouch-ts';
import lameMinSource from 'lamejs/lame.min.js?raw';
import { SpeedMode, TrackAnalysis } from '../types/audio';
import {
  encodeWav16BitStereo,
  estimateBpmAndPhase,
  estimateSubtleHarmonicShift,
  findActiveSpliceBounds,
  measureGatedRms,
  softLimitSample,
} from './dspHelpers';

interface LameEncoderInstance {
  encodeBuffer(left: Int16Array, right: Int16Array): Int8Array;
  flush(): Int8Array;
}

interface LameModule {
  Mp3Encoder: new (
    channels: number,
    sampleRate: number,
    kbps: number
  ) => LameEncoderInstance;
}

let cachedLameModule: LameModule | null = null;

export function getLameModule(): LameModule {
  if (cachedLameModule) return cachedLameModule;
  const factory = new Function(
    `${lameMinSource}\nreturn lamejs;`
  ) as () => LameModule;
  const mod = factory();
  if (!mod || typeof mod.Mp3Encoder !== 'function') {
    throw new Error('Mp3Encoder constructor unavailable');
  }
  cachedLameModule = mod;
  return mod;
}

export interface LibraryProbeReport {
  soundTouchOk: boolean;
  lameMp3Ok: boolean;
  error?: string;
}

/**
 * Real runtime verification of SoundTouch time-stretcher and lamejs 320 kbps MP3 encoder.
 * Never returns hardcoded values — actually instantiates and processes real audio samples.
 */
export function probeAudioLibrariesCore(): LibraryProbeReport {
  let soundTouchOk = false;
  let lameMp3Ok = false;
  const errors: string[] = [];

  try {
    const st = new SoundTouch(44100);
    st.tempo = 1.05;
    st.pitchSemitones = 1;
    st.clear();
    const testIn = new Float32Array(1024 * 2);
    for (let i = 0; i < 1024; i++) {
      const s = Math.sin((2 * Math.PI * 440 * i) / 44100) * 0.25;
      testIn[i * 2] = s;
      testIn[i * 2 + 1] = s;
    }
    st.inputBuffer.putSamples(testIn, 0, 1024);
    st.process();
    soundTouchOk = typeof st.outputBuffer.frameCount === 'number';
  } catch (err) {
    errors.push(
      `SoundTouch error: ${err instanceof Error ? err.message : 'failed'}`
    );
  }

  try {
    const lame = getLameModule();
    const encoder = new lame.Mp3Encoder(2, 44100, 320);
    const pcmL = new Int16Array(1152);
    const pcmR = new Int16Array(1152);
    for (let i = 0; i < 1152; i++) {
      const v = Math.round(Math.sin((2 * Math.PI * 440 * i) / 44100) * 8000);
      pcmL[i] = v;
      pcmR[i] = v;
    }
    const b1 = encoder.encodeBuffer(pcmL, pcmR);
    const b2 = encoder.flush();
    lameMp3Ok = (b1?.length || 0) + (b2?.length || 0) > 0;
  } catch (err) {
    errors.push(`MP3 encoder error: ${err instanceof Error ? err.message : 'failed'}`);
  }

  return {
    soundTouchOk,
    lameMp3Ok,
    error: errors.length > 0 ? errors.join('; ') : undefined,
  };
}

/**
 * Independent time-stretching and pitch-shifting using SoundTouch WSOLA + RateTransposer.
 * Processes in bounded chunks so mobile devices never run out of memory or freeze.
 */
export function processWithSoundTouch(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  tempo: number,
  pitchSemitones: number,
  onProgress?: (fraction: number) => void
): { left: Float32Array; right: Float32Array } {
  const numFrames = left.length;
  if (Math.abs(tempo - 1.0) < 0.002 && Math.abs(pitchSemitones) < 0.01) {
    onProgress?.(1);
    return { left, right };
  }

  const st = new SoundTouch(sampleRate);
  st.tempo = tempo;
  st.pitchSemitones = pitchSemitones;
  st.clear();

  const expectedOutFrames = Math.max(1, Math.round(numFrames / tempo));
  const outCapacity = expectedOutFrames + 8192;
  const outLeft = new Float32Array(outCapacity);
  const outRight = new Float32Array(outCapacity);

  const CHUNK_FRAMES = 16384;
  const interleavedIn = new Float32Array(CHUNK_FRAMES * 2);
  const maxDrainFrames = CHUNK_FRAMES * 4;
  const interleavedOut = new Float32Array(maxDrainFrames * 2);

  let writePos = 0;
  let chunkIndex = 0;

  for (let readPos = 0; readPos < numFrames; readPos += CHUNK_FRAMES) {
    const count = Math.min(CHUNK_FRAMES, numFrames - readPos);
    for (let i = 0; i < count; i++) {
      interleavedIn[i * 2] = left[readPos + i];
      interleavedIn[i * 2 + 1] = right[readPos + i];
    }

    st.inputBuffer.putSamples(interleavedIn, 0, count);
    st.process();

    while (st.outputBuffer.frameCount > 0) {
      const avail = Math.min(st.outputBuffer.frameCount, maxDrainFrames);
      st.outputBuffer.receiveSamples(interleavedOut, avail);
      const safeCopy = Math.min(avail, outCapacity - writePos);
      for (let i = 0; i < safeCopy; i++) {
        outLeft[writePos + i] = interleavedOut[i * 2];
        outRight[writePos + i] = interleavedOut[i * 2 + 1];
      }
      writePos += safeCopy;
      if (avail > safeCopy) break;
    }

    chunkIndex++;
    if (onProgress && chunkIndex % 3 === 0) {
      onProgress(Math.min(0.98, readPos / numFrames));
    }
  }

  const flushFrames = 8192;
  const zeroTail = new Float32Array(flushFrames * 2);
  st.inputBuffer.putSamples(zeroTail, 0, flushFrames);
  st.process();

  while (st.outputBuffer.frameCount > 0 && writePos < expectedOutFrames) {
    const avail = Math.min(
      st.outputBuffer.frameCount,
      maxDrainFrames,
      expectedOutFrames - writePos
    );
    if (avail <= 0) break;
    st.outputBuffer.receiveSamples(interleavedOut, avail);
    for (let i = 0; i < avail; i++) {
      outLeft[writePos + i] = interleavedOut[i * 2];
      outRight[writePos + i] = interleavedOut[i * 2 + 1];
    }
    writePos += avail;
  }

  const finalLen = Math.min(expectedOutFrames, Math.max(1, writePos));
  const trimmedL = outLeft.slice(0, finalLen);
  const trimmedR = outRight.slice(0, finalLen);

  const fadeTail = Math.min(
    Math.round(sampleRate * 0.01),
    Math.floor(finalLen / 4)
  );
  for (let i = 0; i < fadeTail; i++) {
    const g = i / Math.max(1, fadeTail);
    const idx = finalLen - 1 - i;
    trimmedL[idx] *= g;
    trimmedR[idx] *= g;
  }

  onProgress?.(1);
  return { left: trimmedL, right: trimmedR };
}

/**
 * Tape / vinyl playbackRate-style cubic Catmull-Rom resampler:
 * Changes tempo AND pitch together smoothly (faster = pitch up, slower = pitch down).
 */
export function resampleTapeStereo(
  left: Float32Array,
  right: Float32Array,
  rate: number,
  onProgress?: (fraction: number) => void
): { left: Float32Array; right: Float32Array } {
  const inLen = left.length;
  if (Math.abs(rate - 1.0) < 0.002 || inLen < 4) {
    onProgress?.(1);
    return { left, right };
  }

  const outLen = Math.max(1, Math.round(inLen / rate));
  const outL = new Float32Array(outLen);
  const outR = new Float32Array(outLen);
  const maxIdx = inLen - 1;
  const reportStep = Math.max(16384, Math.floor(outLen / 12));

  for (let i = 0; i < outLen; i++) {
    const srcPos = i * rate;
    const idx1 = Math.min(maxIdx, Math.floor(srcPos));
    const frac = srcPos - idx1;

    const idx0 = idx1 > 0 ? idx1 - 1 : 0;
    const idx2 = idx1 < maxIdx ? idx1 + 1 : maxIdx;
    const idx3 = idx1 + 1 < maxIdx ? idx1 + 2 : maxIdx;

    const l0 = left[idx0];
    const l1 = left[idx1];
    const l2 = left[idx2];
    const l3 = left[idx3];
    const cL0 = l1;
    const cL1 = 0.5 * (l2 - l0);
    const cL2 = l0 - 2.5 * l1 + 2 * l2 - 0.5 * l3;
    const cL3 = 0.5 * (l3 - l0) + 1.5 * (l1 - l2);
    outL[i] = ((cL3 * frac + cL2) * frac + cL1) * frac + cL0;

    const r0 = right[idx0];
    const r1 = right[idx1];
    const r2 = right[idx2];
    const r3 = right[idx3];
    const cR0 = r1;
    const cR1 = 0.5 * (r2 - r0);
    const cR2 = r0 - 2.5 * r1 + 2 * r2 - 0.5 * r3;
    const cR3 = 0.5 * (r3 - r0) + 1.5 * (r1 - r2);
    outR[i] = ((cR3 * frac + cR2) * frac + cR1) * frac + cR0;

    if (onProgress && i > 0 && i % reportStep === 0) {
      onProgress(i / outLen);
    }
  }

  onProgress?.(1);
  return { left: outL, right: outR };
}

export function applyFinalSpeedPitchAndLofi(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  speed: number,
  speedMode: SpeedMode,
  pitchSemitones: number,
  lofi: boolean,
  onProgress?: (fraction: number) => void
): { left: Float32Array; right: Float32Array } {
  if (speedMode === 'tape-pitch') {
    const needsTapeResample = Math.abs(speed - 1.0) >= 0.002;
    const postStretchTempo = lofi ? 0.85 : 1.0;
    const needsPostStretch =
      Math.abs(postStretchTempo - 1.0) >= 0.002 ||
      Math.abs(pitchSemitones) >= 0.01;

    let curL = left;
    let curR = right;

    if (needsTapeResample) {
      const resampled = resampleTapeStereo(
        curL,
        curR,
        speed,
        onProgress
          ? (f) => onProgress(needsPostStretch ? f * 0.45 : f)
          : undefined
      );
      curL = resampled.left;
      curR = resampled.right;
    }

    if (needsPostStretch) {
      const stretched = processWithSoundTouch(
        curL,
        curR,
        sampleRate,
        postStretchTempo,
        pitchSemitones,
        onProgress
          ? (f) => onProgress(needsTapeResample ? 0.45 + f * 0.55 : f)
          : undefined
      );
      curL = stretched.left;
      curR = stretched.right;
    } else {
      onProgress?.(1);
    }

    return { left: curL, right: curR };
  }

  const finalTempo = speed * (lofi ? 0.85 : 1.0);
  if (Math.abs(finalTempo - 1.0) >= 0.002 || Math.abs(pitchSemitones) >= 0.01) {
    return processWithSoundTouch(
      left,
      right,
      sampleRate,
      finalTempo,
      pitchSemitones,
      onProgress
    );
  }

  onProgress?.(1);
  return { left, right };
}

export function analyzeTrackCore(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  preferEndSection: boolean
): TrackAnalysis {
  const bpmRes = estimateBpmAndPhase(left, right, sampleRate, preferEndSection);
  const rms = measureGatedRms(left, right, sampleRate);
  const rmsDb = rms > 1e-6 ? Math.round(20 * Math.log10(rms) * 10) / 10 : -60;
  return {
    bpm: bpmRes.bpm,
    bpmConfidence: bpmRes.confidence,
    rmsDb,
  };
}

export interface MixDspCoreParams {
  s1Left: Float32Array;
  s1Right: Float32Array;
  s2Left: Float32Array;
  s2Right: Float32Array;
  sampleRate: number;
  crossfadeSec: number;
  autoMatch: boolean;
  speedMode: SpeedMode;
  speed: number;
  pitchSemitones: number;
  lofi: boolean;
  userTrimmedEnd1?: boolean;
  userTrimmedStart2?: boolean;
  onProgress?: (percent: number, stage: string) => void;
}

export interface MixDspCoreOutput {
  left: Float32Array;
  right: Float32Array;
  stats: {
    song1Bpm: number | null;
    song2Bpm: number | null;
    song2MatchedTempoRatio: number;
    song2PitchShiftSemitones: number;
    autoMatchApplied: boolean;
    effectiveCrossfadeSec: number;
    transitionStartSec: number;
    transitionEndSec: number;
    expectedDurationSec: number;
  };
}

export function renderMixDspCore(params: MixDspCoreParams): MixDspCoreOutput {
  const sr = params.sampleRate;
  const postProgress = (pct: number, stage: string) => {
    params.onProgress?.(Math.round(pct), stage);
  };

  postProgress(4, 'Loudness aur beat analyze ho raha hai...');

  const bounds1 = findActiveSpliceBounds(
    params.s1Left,
    params.s1Right,
    sr,
    false,
    !params.userTrimmedEnd1
  );
  const bounds2 = findActiveSpliceBounds(
    params.s2Left,
    params.s2Right,
    sr,
    !params.userTrimmedStart2,
    false
  );

  const s1LenRaw = bounds1.end - bounds1.start;
  const s2LenRaw = bounds2.end - bounds2.start;

  const s1L = params.s1Left.subarray(bounds1.start, bounds1.end);
  const s1R = params.s1Right.subarray(bounds1.start, bounds1.end);
  let s2L: Float32Array = params.s2Left.subarray(bounds2.start, bounds2.end);
  let s2R: Float32Array = params.s2Right.subarray(bounds2.start, bounds2.end);

  const rms1 = measureGatedRms(s1L, s1R, sr);
  const rms2 = measureGatedRms(s2L, s2R, sr);
  const targetRms = 0.195;
  const gain1 = Math.max(0.25, Math.min(3.8, targetRms / Math.max(0.015, rms1)));
  const gain2 = Math.max(0.25, Math.min(3.8, targetRms / Math.max(0.015, rms2)));

  const norm1L = new Float32Array(s1LenRaw);
  const norm1R = new Float32Array(s1LenRaw);
  for (let i = 0; i < s1LenRaw; i++) {
    norm1L[i] = softLimitSample(s1L[i] * gain1, 0.96);
    norm1R[i] = softLimitSample(s1R[i] * gain1, 0.96);
  }

  const norm2L = new Float32Array(s2LenRaw);
  const norm2R = new Float32Array(s2LenRaw);
  for (let i = 0; i < s2LenRaw; i++) {
    norm2L[i] = softLimitSample(s2L[i] * gain2, 0.96);
    norm2R[i] = softLimitSample(s2R[i] * gain2, 0.96);
  }

  const boundaryWin = Math.min(
    Math.round(sr * 12),
    Math.floor(s1LenRaw * 0.5),
    Math.floor(s2LenRaw * 0.5)
  );
  if (boundaryWin > sr * 2) {
    const outroRms1 = measureGatedRms(
      norm1L,
      norm1R,
      sr,
      s1LenRaw - boundaryWin,
      s1LenRaw
    );
    const introRms2 = measureGatedRms(norm2L, norm2R, sr, 0, boundaryWin);
    if (outroRms1 > 0.03 && introRms2 > 0.03) {
      const boundaryRatio = Math.max(0.74, Math.min(1.36, outroRms1 / introRms2));
      if (Math.abs(boundaryRatio - 1.0) > 0.06) {
        const glideFrames = Math.min(norm2L.length, Math.round(sr * 14));
        for (let i = 0; i < glideFrames; i++) {
          const t = i / glideFrames;
          const envGain =
            boundaryRatio + (1.0 - boundaryRatio) * (t * t * (3 - 2 * t));
          norm2L[i] = softLimitSample(norm2L[i] * envGain, 0.96);
          norm2R[i] = softLimitSample(norm2R[i] * envGain, 0.96);
        }
      }
    }
  }

  postProgress(14, 'Tempo aur beat match check ho raha hai...');

  const bpm1Info = estimateBpmAndPhase(norm1L, norm1R, sr, true);
  const bpm2Info = estimateBpmAndPhase(norm2L, norm2R, sr, false);

  let song2MatchedTempoRatio = 1.0;
  let song2PitchShiftSemitones = 0;
  let autoMatchApplied = false;

  if (params.autoMatch && bpm1Info.bpm && bpm2Info.bpm) {
    const candidates = [bpm2Info.bpm * 0.5, bpm2Info.bpm, bpm2Info.bpm * 2.0];
    let closestBpm2 = bpm2Info.bpm;
    let smallestRelDiff = Infinity;
    for (const cand of candidates) {
      const relDiff = Math.abs(cand - bpm1Info.bpm) / bpm1Info.bpm;
      if (relDiff < smallestRelDiff) {
        smallestRelDiff = relDiff;
        closestBpm2 = cand;
      }
    }

    const rawTempoRatio = bpm1Info.bpm / closestBpm2;
    if (rawTempoRatio >= 0.78 && rawTempoRatio <= 1.28) {
      song2MatchedTempoRatio = Math.max(0.84, Math.min(1.2, rawTempoRatio));
      song2PitchShiftSemitones = estimateSubtleHarmonicShift(
        norm1L,
        norm1R,
        norm2L,
        norm2R,
        sr
      );
      autoMatchApplied =
        Math.abs(song2MatchedTempoRatio - 1.0) > 0.004 ||
        song2PitchShiftSemitones !== 0;
    }
  }

  s2L = norm2L;
  s2R = norm2R;

  if (autoMatchApplied) {
    postProgress(20, 'Song 2 ko Song 1 ke tempo se match kiya ja raha hai...');
    const stretchedS2 = processWithSoundTouch(
      norm2L,
      norm2R,
      sr,
      song2MatchedTempoRatio,
      song2PitchShiftSemitones,
      (frac) => postProgress(20 + frac * 28, 'Song 2 tempo match ho raha hai...')
    );
    s2L = stretchedS2.left;
    s2R = stretchedS2.right;
  } else {
    postProgress(48, 'Loudness normalize ho gaya...');
  }

  const minMicroFadeFrames = Math.round(sr * 0.018);
  const requestedXfadeFrames = Math.round(params.crossfadeSec * sr);
  const maxAllowedXfade = Math.min(
    Math.floor(norm1L.length * 0.48),
    Math.floor(s2L.length * 0.48)
  );
  const xfadeFrames = Math.max(
    Math.min(minMicroFadeFrames, maxAllowedXfade),
    Math.min(requestedXfadeFrames, maxAllowedXfade)
  );

  if (params.autoMatch && bpm1Info.bpm && xfadeFrames > sr) {
    const beatPeriodSec = 60 / bpm1Info.bpm;
    const entryTime1Sec = (norm1L.length - xfadeFrames) / sr;
    const s1BeatPhaseAtEntry =
      (((entryTime1Sec - bpm1Info.beatPhaseSec) % beatPeriodSec) + beatPeriodSec) %
      beatPeriodSec;
    const s2ScaledBeatPhase =
      (bpm2Info.beatPhaseSec / song2MatchedTempoRatio) % beatPeriodSec;
    const phaseDeltaSec =
      (((s2ScaledBeatPhase - s1BeatPhaseAtEntry) % beatPeriodSec) + beatPeriodSec) %
      beatPeriodSec;

    if (
      phaseDeltaSec < beatPeriodSec * 0.45 &&
      phaseDeltaSec * sr < s2L.length * 0.05
    ) {
      const phaseTrimFrames = Math.round(phaseDeltaSec * sr);
      if (phaseTrimFrames > 0 && s2L.length - phaseTrimFrames > xfadeFrames * 2) {
        s2L = s2L.subarray(phaseTrimFrames);
        s2R = s2R.subarray(phaseTrimFrames);
      }
    }
  }

  postProgress(54, 'Equal-power seamless crossfade ban raha hai...');

  const s1FinalLen = norm1L.length;
  const s2FinalLen = s2L.length;
  const actualXfade = Math.min(
    xfadeFrames,
    Math.floor(s1FinalLen * 0.48),
    Math.floor(s2FinalLen * 0.48)
  );
  const preXfadeEnd = s1FinalLen - actualXfade;
  const mergedLen = s1FinalLen + s2FinalLen - actualXfade;

  const mergedL = new Float32Array(mergedLen);
  const mergedR = new Float32Array(mergedLen);

  mergedL.set(norm1L.subarray(0, preXfadeEnd), 0);
  mergedR.set(norm1R.subarray(0, preXfadeEnd), 0);

  const alphaSub = 1 - Math.exp((-2 * Math.PI * 135) / sr);
  let low1L = 0;
  let low1R = 0;
  let low2L = 0;
  let low2R = 0;

  const warmStart = Math.max(0, preXfadeEnd - Math.round(sr * 0.02));
  for (let w = warmStart; w < preXfadeEnd; w++) {
    low1L += alphaSub * (norm1L[w] - low1L);
    low1R += alphaSub * (norm1R[w] - low1R);
  }

  const denomXfade = Math.max(1, actualXfade - 1);
  for (let i = 0; i < actualXfade; i++) {
    const t = i / denomXfade;
    const angle = t * Math.PI * 0.5;
    const g1 = Math.cos(angle);
    const g2 = Math.sin(angle);

    const x1L = norm1L[preXfadeEnd + i];
    const x1R = norm1R[preXfadeEnd + i];
    const x2L = s2L[i];
    const x2R = s2R[i];

    low1L += alphaSub * (x1L - low1L);
    low1R += alphaSub * (x1R - low1R);
    low2L += alphaSub * (x2L - low2L);
    low2R += alphaSub * (x2R - low2R);

    const high1L = x1L - low1L;
    const high1R = x1R - low1R;
    const high2L = x2L - low2L;
    const high2R = x2R - low2R;

    const subWeight1 = g1 * (1 - 0.22 * Math.sin(Math.PI * t));
    const subWeight2 = g2 * (1 - 0.22 * Math.sin(Math.PI * t));

    const outSampleL =
      high1L * g1 + high2L * g2 + low1L * subWeight1 + low2L * subWeight2;
    const outSampleR =
      high1R * g1 + high2R * g2 + low1R * subWeight1 + low2R * subWeight2;

    mergedL[preXfadeEnd + i] = softLimitSample(outSampleL, 0.97);
    mergedR[preXfadeEnd + i] = softLimitSample(outSampleR, 0.97);
  }

  mergedL.set(s2L.subarray(actualXfade), s1FinalLen);
  mergedR.set(s2R.subarray(actualXfade), s1FinalLen);

  const edgeFade = Math.min(Math.round(sr * 0.015), Math.floor(mergedLen / 8));
  for (let i = 0; i < edgeFade; i++) {
    const g = i / Math.max(1, edgeFade);
    mergedL[i] *= g;
    mergedR[i] *= g;
    mergedL[mergedLen - 1 - i] *= g;
    mergedR[mergedLen - 1 - i] *= g;
  }

  const finalTempo = params.speed * (params.lofi ? 0.85 : 1.0);
  const speedMode: SpeedMode = params.speedMode ?? 'preserve-pitch';

  postProgress(62, 'Speed aur pitch apply ho raha hai...');
  const processedMix = applyFinalSpeedPitchAndLofi(
    mergedL,
    mergedR,
    sr,
    params.speed,
    speedMode,
    params.pitchSemitones,
    params.lofi,
    (frac) => postProgress(62 + frac * 36, 'Speed aur pitch apply ho raha hai...')
  );

  const effectiveCrossfadeSec = actualXfade / sr;
  const transitionStartSec = preXfadeEnd / sr / finalTempo;
  const transitionEndSec = s1FinalLen / sr / finalTempo;
  const expectedDurationSec = mergedLen / sr / finalTempo;

  postProgress(100, 'Mix DSP ready!');

  return {
    left: processedMix.left,
    right: processedMix.right,
    stats: {
      song1Bpm: bpm1Info.bpm,
      song2Bpm: bpm2Info.bpm,
      song2MatchedTempoRatio,
      song2PitchShiftSemitones,
      autoMatchApplied,
      effectiveCrossfadeSec,
      transitionStartSec,
      transitionEndSec,
      expectedDurationSec,
    },
  };
}

export interface OverlapLoopDspOutput {
  left: Float32Array;
  right: Float32Array;
  loopStartOutFrame: number;
  loopEndOutFrame: number;
  xfadeStartInLoopSec: number;
  xfadeEndInLoopSec: number;
}

export function renderOverlapLoopDspCore(
  params: Omit<MixDspCoreParams, 'onProgress'>
): OverlapLoopDspOutput {
  const sr = params.sampleRate;

  const bounds1 = findActiveSpliceBounds(
    params.s1Left,
    params.s1Right,
    sr,
    false,
    !params.userTrimmedEnd1
  );
  const bounds2 = findActiveSpliceBounds(
    params.s2Left,
    params.s2Right,
    sr,
    !params.userTrimmedStart2,
    false
  );

  const s1LenRaw = bounds1.end - bounds1.start;
  const s2LenRaw = bounds2.end - bounds2.start;

  const s1FullL = params.s1Left.subarray(bounds1.start, bounds1.end);
  const s1FullR = params.s1Right.subarray(bounds1.start, bounds1.end);
  const s2FullL = params.s2Left.subarray(bounds2.start, bounds2.end);
  const s2FullR = params.s2Right.subarray(bounds2.start, bounds2.end);

  const rms1 = measureGatedRms(s1FullL, s1FullR, sr);
  const rms2 = measureGatedRms(s2FullL, s2FullR, sr);
  const targetRms = 0.195;
  const gain1 = Math.max(0.25, Math.min(3.8, targetRms / Math.max(0.015, rms1)));
  const gain2 = Math.max(0.25, Math.min(3.8, targetRms / Math.max(0.015, rms2)));

  let boundaryRatio = 1.0;
  const boundaryWin = Math.min(
    Math.round(sr * 12),
    Math.floor(s1LenRaw * 0.5),
    Math.floor(s2LenRaw * 0.5)
  );
  if (boundaryWin > sr * 2) {
    const outroRms1 =
      measureGatedRms(s1FullL, s1FullR, sr, s1LenRaw - boundaryWin, s1LenRaw) *
      gain1;
    const introRms2 =
      measureGatedRms(s2FullL, s2FullR, sr, 0, boundaryWin) * gain2;
    if (outroRms1 > 0.03 && introRms2 > 0.03) {
      const candRatio = Math.max(0.74, Math.min(1.36, outroRms1 / introRms2));
      if (Math.abs(candRatio - 1.0) > 0.06) {
        boundaryRatio = candRatio;
      }
    }
  }

  const bpm1Info = estimateBpmAndPhase(s1FullL, s1FullR, sr, true);
  const bpm2Info = estimateBpmAndPhase(s2FullL, s2FullR, sr, false);

  let song2MatchedTempoRatio = 1.0;
  let song2PitchShiftSemitones = 0;
  let autoMatchApplied = false;

  if (params.autoMatch && bpm1Info.bpm && bpm2Info.bpm) {
    const candidates = [bpm2Info.bpm * 0.5, bpm2Info.bpm, bpm2Info.bpm * 2.0];
    let closestBpm2 = bpm2Info.bpm;
    let smallestRelDiff = Infinity;
    for (const cand of candidates) {
      const relDiff = Math.abs(cand - bpm1Info.bpm) / bpm1Info.bpm;
      if (relDiff < smallestRelDiff) {
        smallestRelDiff = relDiff;
        closestBpm2 = cand;
      }
    }
    const rawTempoRatio = bpm1Info.bpm / closestBpm2;
    if (rawTempoRatio >= 0.78 && rawTempoRatio <= 1.28) {
      song2MatchedTempoRatio = Math.max(0.84, Math.min(1.2, rawTempoRatio));
      song2PitchShiftSemitones = estimateSubtleHarmonicShift(
        s1FullL,
        s1FullR,
        s2FullL,
        s2FullR,
        sr
      );
      autoMatchApplied =
        Math.abs(song2MatchedTempoRatio - 1.0) > 0.004 ||
        song2PitchShiftSemitones !== 0;
    }
  }

  const finalTempo = params.speed * (params.lofi ? 0.85 : 1.0);
  const finalPitch = params.pitchSemitones;

  const marginPrePostFrames = Math.round(3.0 * finalTempo * sr);
  const warmupFrames = Math.round(1.2 * finalTempo * sr);

  const estS2StretchedTotal = Math.max(
    1,
    Math.round(s2LenRaw / song2MatchedTempoRatio)
  );
  const minMicroFadeFrames = Math.round(sr * 0.018);
  const requestedXfadeFrames = Math.round(params.crossfadeSec * sr);
  const maxAllowedXfade = Math.min(
    Math.floor(s1LenRaw * 0.48),
    Math.floor(estS2StretchedTotal * 0.48)
  );
  const xfadeFramesEst = Math.max(
    Math.min(minMicroFadeFrames, maxAllowedXfade),
    Math.min(requestedXfadeFrames, maxAllowedXfade)
  );

  const maxPhaseFrames = sr;
  const neededS2Stretched =
    xfadeFramesEst + marginPrePostFrames + warmupFrames + maxPhaseFrames + sr;
  const s2RawExcerptLen = Math.min(
    s2LenRaw,
    Math.ceil(neededS2Stretched * song2MatchedTempoRatio) + sr
  );

  const norm2ExL = new Float32Array(s2RawExcerptLen);
  const norm2ExR = new Float32Array(s2RawExcerptLen);
  const glideFramesFull = Math.min(s2LenRaw, Math.round(sr * 14));

  for (let i = 0; i < s2RawExcerptLen; i++) {
    let g = gain2;
    if (boundaryRatio !== 1.0 && i < glideFramesFull) {
      const t = i / glideFramesFull;
      const env = boundaryRatio + (1.0 - boundaryRatio) * (t * t * (3 - 2 * t));
      g *= env;
    }
    norm2ExL[i] = softLimitSample(s2FullL[i] * g, 0.96);
    norm2ExR[i] = softLimitSample(s2FullR[i] * g, 0.96);
  }

  let s2ExL: Float32Array = norm2ExL;
  let s2ExR: Float32Array = norm2ExR;

  if (autoMatchApplied) {
    const stretchedS2 = processWithSoundTouch(
      norm2ExL,
      norm2ExR,
      sr,
      song2MatchedTempoRatio,
      song2PitchShiftSemitones
    );
    s2ExL = stretchedS2.left;
    s2ExR = stretchedS2.right;
  }

  if (params.autoMatch && bpm1Info.bpm && xfadeFramesEst > sr) {
    const beatPeriodSec = 60 / bpm1Info.bpm;
    const entryTime1Sec = (s1LenRaw - xfadeFramesEst) / sr;
    const s1BeatPhaseAtEntry =
      (((entryTime1Sec - bpm1Info.beatPhaseSec) % beatPeriodSec) + beatPeriodSec) %
      beatPeriodSec;
    const s2ScaledBeatPhase =
      (bpm2Info.beatPhaseSec / song2MatchedTempoRatio) % beatPeriodSec;
    const phaseDeltaSec =
      (((s2ScaledBeatPhase - s1BeatPhaseAtEntry) % beatPeriodSec) + beatPeriodSec) %
      beatPeriodSec;

    if (
      phaseDeltaSec < beatPeriodSec * 0.45 &&
      phaseDeltaSec * sr < estS2StretchedTotal * 0.05
    ) {
      const phaseTrim = Math.round(phaseDeltaSec * sr);
      if (phaseTrim > 0 && s2ExL.length - phaseTrim > xfadeFramesEst + sr) {
        s2ExL = s2ExL.subarray(phaseTrim);
        s2ExR = s2ExR.subarray(phaseTrim);
      }
    }
  }

  const actualXfade = Math.min(
    xfadeFramesEst,
    Math.floor(s1LenRaw * 0.48),
    Math.floor(s2ExL.length * 0.85)
  );
  const preXfadeEndFull = s1LenRaw - actualXfade;
  const desiredLoopStartFull = Math.max(0, preXfadeEndFull - marginPrePostFrames);
  const excerpt1Start = Math.max(0, desiredLoopStartFull - warmupFrames);
  const s1ExLen = s1LenRaw - excerpt1Start;

  const norm1ExL = new Float32Array(s1ExLen);
  const norm1ExR = new Float32Array(s1ExLen);
  for (let i = 0; i < s1ExLen; i++) {
    norm1ExL[i] = softLimitSample(s1FullL[excerpt1Start + i] * gain1, 0.96);
    norm1ExR[i] = softLimitSample(s1FullR[excerpt1Start + i] * gain1, 0.96);
  }

  const xfadeStartInEx = preXfadeEndFull - excerpt1Start;
  const xfadeEndInEx = xfadeStartInEx + actualXfade;
  const loopStartInEx = desiredLoopStartFull - excerpt1Start;
  const maxExMergedLen = xfadeStartInEx + s2ExL.length;
  const wrapExtraFrames = Math.round(0.045 * finalTempo * sr);
  const loopEndInEx = Math.min(
    maxExMergedLen,
    xfadeEndInEx + marginPrePostFrames
  );
  const exMergedLen = Math.min(
    maxExMergedLen,
    loopEndInEx + wrapExtraFrames + Math.round(0.35 * finalTempo * sr)
  );

  const mergedExL = new Float32Array(exMergedLen);
  const mergedExR = new Float32Array(exMergedLen);

  mergedExL.set(norm1ExL.subarray(0, xfadeStartInEx), 0);
  mergedExR.set(norm1ExR.subarray(0, xfadeStartInEx), 0);

  const alphaSub = 1 - Math.exp((-2 * Math.PI * 135) / sr);
  let low1L = 0;
  let low1R = 0;
  let low2L = 0;
  let low2R = 0;

  const warmStart = Math.max(0, xfadeStartInEx - Math.round(sr * 0.02));
  for (let w = warmStart; w < xfadeStartInEx; w++) {
    low1L += alphaSub * (norm1ExL[w] - low1L);
    low1R += alphaSub * (norm1ExR[w] - low1R);
  }

  const denomXfade = Math.max(1, actualXfade - 1);
  for (let i = 0; i < actualXfade && xfadeStartInEx + i < exMergedLen; i++) {
    const t = i / denomXfade;
    const angle = t * Math.PI * 0.5;
    const g1 = Math.cos(angle);
    const g2 = Math.sin(angle);

    const x1L = norm1ExL[xfadeStartInEx + i];
    const x1R = norm1ExR[xfadeStartInEx + i];
    const x2L = s2ExL[i];
    const x2R = s2ExR[i];

    low1L += alphaSub * (x1L - low1L);
    low1R += alphaSub * (x1R - low1R);
    low2L += alphaSub * (x2L - low2L);
    low2R += alphaSub * (x2R - low2R);

    const high1L = x1L - low1L;
    const high1R = x1R - low1R;
    const high2L = x2L - low2L;
    const high2R = x2R - low2R;

    const subWeight1 = g1 * (1 - 0.22 * Math.sin(Math.PI * t));
    const subWeight2 = g2 * (1 - 0.22 * Math.sin(Math.PI * t));

    mergedExL[xfadeStartInEx + i] = softLimitSample(
      high1L * g1 + high2L * g2 + low1L * subWeight1 + low2L * subWeight2,
      0.97
    );
    mergedExR[xfadeStartInEx + i] = softLimitSample(
      high1R * g1 + high2R * g2 + low1R * subWeight1 + low2R * subWeight2,
      0.97
    );
  }

  const postCount = Math.max(0, exMergedLen - xfadeEndInEx);
  if (postCount > 0) {
    mergedExL.set(
      s2ExL.subarray(actualXfade, actualXfade + postCount),
      xfadeEndInEx
    );
    mergedExR.set(
      s2ExR.subarray(actualXfade, actualXfade + postCount),
      xfadeEndInEx
    );
  }

  const speedMode: SpeedMode = params.speedMode ?? 'preserve-pitch';
  const processedEx = applyFinalSpeedPitchAndLofi(
    mergedExL,
    mergedExR,
    sr,
    params.speed,
    speedMode,
    finalPitch,
    params.lofi
  );

  const outL = processedEx.left;
  const outR = processedEx.right;

  const loopStartOutFrame = Math.max(
    0,
    Math.min(outL.length - 1, Math.round(loopStartInEx / finalTempo))
  );
  const loopEndOutFrame = Math.max(
    loopStartOutFrame + 1,
    Math.min(outL.length, Math.round(loopEndInEx / finalTempo))
  );
  const xfadeStartInLoopSec = Math.max(
    0,
    (xfadeStartInEx - loopStartInEx) / sr / finalTempo
  );
  const xfadeEndInLoopSec = Math.max(
    xfadeStartInLoopSec,
    (xfadeEndInEx - loopStartInEx) / sr / finalTempo
  );

  return {
    left: outL,
    right: outR,
    loopStartOutFrame,
    loopEndOutFrame,
    xfadeStartInLoopSec,
    xfadeEndInLoopSec,
  };
}

export interface EncodeAudioCoreOutput {
  buffer: ArrayBuffer;
  format: 'mp3' | 'wav';
  wavFallbackUsed: boolean;
}

export function encodeMp3OrWavCore(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  onProgress?: (pct: number) => void
): EncodeAudioCoreOutput {
  const numFrames = left.length;
  if (numFrames === 0) {
    throw new Error('Rendered audio buffer khali hai.');
  }

  let maxAbsPeak = 0;
  for (let i = 0; i < numFrames; i += 8) {
    const aL = Math.abs(left[i]);
    const aR = Math.abs(right[i]);
    if (aL > maxAbsPeak) maxAbsPeak = aL;
    if (aR > maxAbsPeak) maxAbsPeak = aR;
  }

  if (maxAbsPeak < 0.0005) {
    for (let i = 0; i < numFrames; i++) {
      const a = Math.max(Math.abs(left[i]), Math.abs(right[i]));
      if (a > maxAbsPeak) maxAbsPeak = a;
    }
  }

  if (maxAbsPeak < 0.0001) {
    throw new Error('Rendered mix silent hai — kripya audio files check karein.');
  }

  const ceilingGain =
    maxAbsPeak > 0.98
      ? 0.96 / maxAbsPeak
      : maxAbsPeak < 0.25
        ? Math.min(2.5, 0.75 / maxAbsPeak)
        : 1.0;

  try {
    const lame = getLameModule();
    const mp3Encoder = new lame.Mp3Encoder(2, sampleRate, 320);

    const MP3_CHUNK = 1152 * 32;
    const leftInt16 = new Int16Array(MP3_CHUNK);
    const rightInt16 = new Int16Array(MP3_CHUNK);
    const mp3Parts: Uint8Array[] = [];
    let totalBytes = 0;
    let lastReportedPct = -1;

    for (let pos = 0; pos < numFrames; pos += MP3_CHUNK) {
      const count = Math.min(MP3_CHUNK, numFrames - pos);
      for (let i = 0; i < count; i++) {
        const sL = softLimitSample(left[pos + i] * ceilingGain, 0.97);
        const sR = softLimitSample(right[pos + i] * ceilingGain, 0.97);
        leftInt16[i] =
          sL < 0
            ? Math.max(-32768, Math.round(sL * 32768))
            : Math.min(32767, Math.round(sL * 32767));
        rightInt16[i] =
          sR < 0
            ? Math.max(-32768, Math.round(sR * 32768))
            : Math.min(32767, Math.round(sR * 32767));
      }

      const subL = count === MP3_CHUNK ? leftInt16 : leftInt16.subarray(0, count);
      const subR =
        count === MP3_CHUNK ? rightInt16 : rightInt16.subarray(0, count);

      const encodedChunk = mp3Encoder.encodeBuffer(subL, subR);
      if (encodedChunk && encodedChunk.length > 0) {
        const copy = new Uint8Array(encodedChunk.length);
        copy.set(
          new Uint8Array(
            encodedChunk.buffer,
            encodedChunk.byteOffset,
            encodedChunk.byteLength
          )
        );
        mp3Parts.push(copy);
        totalBytes += copy.byteLength;
      }

      const pct = Math.min(99, Math.round(((pos + count) / numFrames) * 100));
      if (pct !== lastReportedPct) {
        lastReportedPct = pct;
        onProgress?.(pct);
      }
    }

    const tail = mp3Encoder.flush();
    if (tail && tail.length > 0) {
      const copy = new Uint8Array(tail.length);
      copy.set(new Uint8Array(tail.buffer, tail.byteOffset, tail.byteLength));
      mp3Parts.push(copy);
      totalBytes += copy.byteLength;
    }

    if (totalBytes <= 0) {
      throw new Error('MP3 encoder returned empty output');
    }

    const finalMp3 = new Uint8Array(totalBytes);
    let offset = 0;
    for (const part of mp3Parts) {
      finalMp3.set(part, offset);
      offset += part.byteLength;
    }

    onProgress?.(100);
    return {
      buffer: finalMp3.buffer as ArrayBuffer,
      format: 'mp3',
      wavFallbackUsed: false,
    };
  } catch {
    const wavBuffer = encodeWav16BitStereo(left, right, sampleRate);
    onProgress?.(100);
    return {
      buffer: wavBuffer,
      format: 'wav',
      wavFallbackUsed: true,
    };
  }
}
