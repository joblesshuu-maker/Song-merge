import { MergeSettings, SpeedMode } from '../types/audio';

const SETTINGS_STORAGE_KEY = 'song_merger_settings_v1';
const HEALTH_DISMISSED_KEY = 'song_merger_health_dismissed_v1';

export const DEFAULT_MERGE_SETTINGS: MergeSettings = {
  crossfadeSec: 8,
  autoMatch: true,
  speedMode: 'preserve-pitch',
  speed: 1.0,
  pitchSemitones: 0,
  lofi: false,
};

function clampNumber(val: unknown, min: number, max: number, fallback: number): number {
  if (typeof val !== 'number' || !Number.isFinite(val)) return fallback;
  return Math.max(min, Math.min(max, val));
}

function parseSpeedMode(val: unknown): SpeedMode {
  return val === 'tape-pitch' ? 'tape-pitch' : 'preserve-pitch';
}

export function loadPersistedSettings(): MergeSettings {
  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      return { ...DEFAULT_MERGE_SETTINGS };
    }
    const raw = window.localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_MERGE_SETTINGS };

    const parsed = JSON.parse(raw) as Partial<MergeSettings>;
    if (!parsed || typeof parsed !== 'object') {
      return { ...DEFAULT_MERGE_SETTINGS };
    }

    return {
      crossfadeSec: clampNumber(
        parsed.crossfadeSec,
        0,
        15,
        DEFAULT_MERGE_SETTINGS.crossfadeSec
      ),
      autoMatch:
        typeof parsed.autoMatch === 'boolean'
          ? parsed.autoMatch
          : DEFAULT_MERGE_SETTINGS.autoMatch,
      speedMode: parseSpeedMode(parsed.speedMode),
      speed: clampNumber(parsed.speed, 0.5, 1.5, DEFAULT_MERGE_SETTINGS.speed),
      pitchSemitones: Math.round(
        clampNumber(
          parsed.pitchSemitones,
          -6,
          6,
          DEFAULT_MERGE_SETTINGS.pitchSemitones
        )
      ),
      lofi:
        typeof parsed.lofi === 'boolean'
          ? parsed.lofi
          : DEFAULT_MERGE_SETTINGS.lofi,
    };
  } catch {
    return { ...DEFAULT_MERGE_SETTINGS };
  }
}

export function savePersistedSettings(settings: MergeSettings): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota or restricted WebView private-mode exceptions
  }
}

export function isHealthCheckDismissed(): boolean {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return false;
    return window.localStorage.getItem(HEALTH_DISMISSED_KEY) === '1';
  } catch {
    return false;
  }
}

export function setHealthCheckDismissed(dismissed: boolean): void {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return;
    if (dismissed) {
      window.localStorage.setItem(HEALTH_DISMISSED_KEY, '1');
    } else {
      window.localStorage.removeItem(HEALTH_DISMISSED_KEY);
    }
  } catch {
    // Ignore storage errors in restricted WebViews
  }
}
