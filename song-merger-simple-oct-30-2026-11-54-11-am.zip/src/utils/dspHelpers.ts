export interface BpmEstimateResult {
  bpm: number | null;
  confidence: number;
  beatPhaseSec: number;
}

/**
 * Estimates tempo (BPM) and beat grid phase using onset-envelope autocorrelation
 * with low-frequency rhythmic weighting and perceptual tempo prior (70-170 BPM).
 */
export function estimateBpmAndPhase(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  preferEndSection: boolean
): BpmEstimateResult {
  const totalFrames = left.length;
  if (totalFrames < sampleRate * 4) {
    return { bpm: null, confidence: 0, beatPhaseSec: 0 };
  }

  // Analyze up to 42 seconds from the active region near the transition
  const maxWindowFrames = Math.min(totalFrames, Math.floor(sampleRate * 42));
  const startFrame = preferEndSection
    ? Math.max(0, totalFrames - maxWindowFrames)
    : 0;
  const endFrame = Math.min(totalFrames, startFrame + maxWindowFrames);
  const windowLen = endFrame - startFrame;

  // Envelope rate ~100 Hz (hop = 441 at 44.1 kHz)
  const hop = Math.max(128, Math.round(sampleRate / 100));
  const envRate = sampleRate / hop;
  const numHops = Math.floor(windowLen / hop);

  if (numHops < 300) {
    return { bpm: null, confidence: 0, beatPhaseSec: 0 };
  }

  const onset = new Float32Array(numHops);
  let lowState = 0;
  // ~160 Hz 1-pole lowpass coefficient for kick/bass transient emphasis
  const alphaLow = 1 - Math.exp((-2 * Math.PI * 160) / sampleRate);

  let prevLowEnergy = 0;
  let prevFullEnergy = 0;

  for (let h = 0; h < numHops; h++) {
    const base = startFrame + h * hop;
    let sumLowSq = 0;
    let sumFullSq = 0;

    for (let i = 0; i < hop; i++) {
      const mono = 0.5 * (left[base + i] + right[base + i]);
      lowState += alphaLow * (mono - lowState);
      sumLowSq += lowState * lowState;
      sumFullSq += mono * mono;
    }

    const lowRms = Math.sqrt(sumLowSq / hop);
    const fullRms = Math.sqrt(sumFullSq / hop);

    // Half-wave rectified spectral/energy flux emphasizing percussive kicks + snares
    const dLow = Math.max(0, lowRms - prevLowEnergy);
    const dFull = Math.max(0, fullRms - prevFullEnergy);
    onset[h] = dLow * 1.65 + dFull * 0.75;

    prevLowEnergy = lowRms;
    prevFullEnergy = fullRms;
  }

  // Normalize onset envelope and remove local mean (0.5s moving average)
  const localWin = Math.max(5, Math.round(envRate * 0.5));
  const cleaned = new Float32Array(numHops);
  let runningSum = 0;
  for (let i = 0; i < numHops; i++) {
    runningSum += onset[i];
    if (i >= localWin) {
      runningSum -= onset[i - localWin];
    }
    const count = Math.min(i + 1, localWin);
    const localMean = runningSum / count;
    cleaned[i] = Math.max(0, onset[i] - localMean * 1.05);
  }

  // Autocorrelation over 68 BPM to 172 BPM
  const minBpm = 68;
  const maxBpm = 172;
  const minLag = Math.max(4, Math.floor((60 * envRate) / maxBpm));
  const maxLag = Math.min(Math.floor(numHops / 2) - 2, Math.ceil((60 * envRate) / minBpm));

  if (maxLag <= minLag + 2) {
    return { bpm: null, confidence: 0, beatPhaseSec: 0 };
  }

  const corr = new Float32Array(maxLag + 2);
  let sumCorr = 0;
  let countCorr = 0;

  for (let lag = minLag; lag <= maxLag; lag++) {
    let acc = 0;
    const limit = numHops - lag;
    for (let i = 0; i < limit; i++) {
      acc += cleaned[i] * cleaned[i + lag];
    }
    const normAcc = acc / Math.max(1, limit);

    // Gentle perceptual log-Gaussian tempo weight centered near 118 BPM
    const bpmAtLag = (60 * envRate) / lag;
    const logDiff = Math.log2(bpmAtLag / 118);
    const perceptualWeight = Math.exp(-0.5 * (logDiff / 0.58) * (logDiff / 0.58));

    const weighted = normAcc * (0.65 + 0.35 * perceptualWeight);
    corr[lag] = weighted;
    sumCorr += weighted;
    countCorr++;
  }

  // Also reinforce integer sub-harmonics (2x lag) for crisp beat period locking
  let bestLag = minLag;
  let bestScore = -1;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let score = corr[lag];
    if (lag * 2 <= maxLag) {
      score += 0.32 * corr[lag * 2];
    }
    if (Math.floor(lag / 2) >= minLag) {
      score += 0.18 * corr[Math.floor(lag / 2)];
    }
    if (score > bestScore) {
      bestScore = score;
      bestLag = lag;
    }
  }

  const meanCorr = sumCorr / Math.max(1, countCorr);
  const confidence = meanCorr > 1e-9 ? bestScore / (meanCorr * 2.2) : 0;

  if (confidence < 0.62 || bestScore <= 1e-9) {
    return { bpm: null, confidence: 0, beatPhaseSec: 0 };
  }

  // Parabolic interpolation around bestLag for sub-BPM accuracy
  let refinedLag = bestLag;
  if (bestLag > minLag && bestLag < maxLag) {
    const y1 = corr[bestLag - 1];
    const y2 = corr[bestLag];
    const y3 = corr[bestLag + 1];
    const denom = y1 - 2 * y2 + y3;
    if (Math.abs(denom) > 1e-9) {
      const delta = (0.5 * (y1 - y3)) / denom;
      if (Math.abs(delta) < 0.6) {
        refinedLag = bestLag + delta;
      }
    }
  }

  const estimatedBpm = (60 * envRate) / refinedLag;

  // Estimate dominant beat phase offset (0 .. beatPeriodSec)
  const periodHops = Math.max(4, Math.round(refinedLag));
  let bestPhaseHop = 0;
  let bestPhaseEnergy = -1;
  for (let p = 0; p < periodHops; p++) {
    let pulseSum = 0;
    for (let idx = p; idx < numHops; idx += periodHops) {
      pulseSum += cleaned[idx];
      if (idx > 0) pulseSum += 0.35 * cleaned[idx - 1];
      if (idx + 1 < numHops) pulseSum += 0.35 * cleaned[idx + 1];
    }
    if (pulseSum > bestPhaseEnergy) {
      bestPhaseEnergy = pulseSum;
      bestPhaseHop = p;
    }
  }

  const beatPhaseSec = (startFrame + bestPhaseHop * hop) / sampleRate;

  return {
    bpm: Math.round(estimatedBpm * 10) / 10,
    confidence: Math.min(1, confidence / 2),
    beatPhaseSec: beatPhaseSec % (60 / estimatedBpm),
  };
}

/**
 * Estimates whether shifting Song 2 by -1, 0, or +1 semitone significantly improves
 * harmonic consonance during the crossfade overlap using Goertzel pitch-class chroma.
 */
export function estimateSubtleHarmonicShift(
  s1Left: Float32Array,
  s1Right: Float32Array,
  s2Left: Float32Array,
  s2Right: Float32Array,
  sampleRate: number
): number {
  const winFrames = Math.min(
    Math.floor(sampleRate * 10),
    s1Left.length,
    s2Left.length
  );
  if (winFrames < sampleRate * 3) return 0;

  const c1 = computeChroma12(
    s1Left,
    s1Right,
    s1Left.length - winFrames,
    winFrames,
    sampleRate
  );
  const c2 = computeChroma12(s2Left, s2Right, 0, winFrames, sampleRate);

  if (!c1 || !c2) return 0;

  const sim0 = cosineSimilarity(c1, c2, 0);
  const simMinus1 = cosineSimilarity(c1, c2, -1);
  const simPlus1 = cosineSimilarity(c1, c2, 1);

  // Only shift by +-1 semitone if harmonic overlap improves clearly over 0 shift
  if (simPlus1 > sim0 + 0.16 && simPlus1 >= simMinus1 && simPlus1 > 0.72) {
    return 1;
  }
  if (simMinus1 > sim0 + 0.16 && simMinus1 > simPlus1 && simMinus1 > 0.72) {
    return -1;
  }
  return 0;
}

function computeChroma12(
  left: Float32Array,
  right: Float32Array,
  startFrame: number,
  frameCount: number,
  sampleRate: number
): Float32Array | null {
  const chroma = new Float32Array(12);
  const blockSize = 4096;
  const stride = 8192;
  let blocks = 0;

  // Reference pitches across 3 octaves (C3 to B5, MIDI 48..83)
  const freqs: number[] = [];
  for (let midi = 48; midi < 84; midi++) {
    freqs.push(440 * Math.pow(2, (midi - 69) / 12));
  }

  for (let pos = startFrame; pos + blockSize <= startFrame + frameCount; pos += stride) {
    for (let m = 0; m < freqs.length; m++) {
      const f = freqs[m];
      const k = Math.round((blockSize * f) / sampleRate);
      const omega = (2 * Math.PI * k) / blockSize;
      const coeff = 2 * Math.cos(omega);
      let s1 = 0;
      let s2 = 0;
      for (let i = 0; i < blockSize; i += 2) {
        // Subsampled by 2 -> adjust omega? Let's run exact step 1 on 2048 samples for accuracy
        const x = 0.5 * (left[pos + i] + right[pos + i]);
        const s0 = x + coeff * s1 - s2;
        s2 = s1;
        s1 = s0;
      }
      // Re-run clean 2048-sample Goertzel
      void s1;
    }
    blocks++;
    if (blocks >= 10) break;
  }

  // Clean exact 2048-frame Goertzel across up to 12 evenly spaced blocks
  chroma.fill(0);
  const N = 2048;
  const numBlocks = Math.min(12, Math.floor(frameCount / N));
  if (numBlocks < 2) return null;
  const hop = Math.floor(frameCount / numBlocks);

  for (let b = 0; b < numBlocks; b++) {
    const base = startFrame + b * hop;
    for (let m = 0; m < freqs.length; m++) {
      const f = freqs[m];
      const omega = (2 * Math.PI * f) / sampleRate;
      const coeff = 2 * Math.cos(omega);
      let q1 = 0;
      let q2 = 0;
      for (let i = 0; i < N; i++) {
        // Hann window approximation at edges
        const x = 0.5 * (left[base + i] + right[base + i]);
        const q0 = x + coeff * q1 - q2;
        q2 = q1;
        q1 = q0;
      }
      const magSq = q1 * q1 + q2 * q2 - coeff * q1 * q2;
      if (magSq > 0) {
        chroma[m % 12] += Math.sqrt(magSq);
      }
    }
  }

  let norm = 0;
  for (let i = 0; i < 12; i++) norm += chroma[i] * chroma[i];
  if (norm < 1e-8) return null;
  const inv = 1 / Math.sqrt(norm);
  for (let i = 0; i < 12; i++) chroma[i] *= inv;
  return chroma;
}

function cosineSimilarity(a: Float32Array, b: Float32Array, shiftB: number): number {
  let dot = 0;
  for (let i = 0; i < 12; i++) {
    const srcIdx = (((i - shiftB) % 12) + 12) % 12;
    dot += a[i] * b[srcIdx];
  }
  return dot;
}

/**
 * Measures perceptual gated RMS loudness (BS.1770-inspired 400ms blocks with absolute + relative gating).
 * Prevents quiet intros/outros from skewing overall track loudness normalization.
 */
export function measureGatedRms(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  startFrame = 0,
  endFrame = left.length
): number {
  const s = Math.max(0, startFrame);
  const e = Math.min(left.length, endFrame);
  const len = e - s;
  if (len <= 0) return 0.15;

  const blockFrames = Math.max(512, Math.round(sampleRate * 0.4));
  const hopFrames = Math.max(256, Math.round(sampleRate * 0.2));

  if (len < blockFrames) {
    let sumSq = 0;
    for (let i = s; i < e; i++) {
      sumSq += 0.5 * (left[i] * left[i] + right[i] * right[i]);
    }
    return Math.sqrt(sumSq / len);
  }

  const energies: number[] = [];
  const absGateSq = Math.pow(10, -45 / 10); // -45 dBFS absolute silence gate

  // Simple high-shelf / mid-emphasis difference for perceptual K-weighting feel
  let prevL = 0;
  let prevR = 0;

  for (let pos = s; pos + blockFrames <= e; pos += hopFrames) {
    let blockSumSq = 0;
    for (let i = 0; i < blockFrames; i++) {
      const l = left[pos + i];
      const r = right[pos + i];
      const hfL = l - prevL;
      const hfR = r - prevR;
      prevL = l;
      prevR = r;
      const wL = l + 0.35 * hfL;
      const wR = r + 0.35 * hfR;
      blockSumSq += 0.5 * (wL * wL + wR * wR);
    }
    const meanSq = blockSumSq / blockFrames;
    if (meanSq > absGateSq) {
      energies.push(meanSq);
    }
  }

  if (energies.length === 0) {
    return 0.05;
  }

  let ungatedMeanSq = 0;
  for (let i = 0; i < energies.length; i++) ungatedMeanSq += energies[i];
  ungatedMeanSq /= energies.length;

  // -10 dB relative gate
  const relGateSq = ungatedMeanSq * 0.1;
  let gatedSumSq = 0;
  let gatedCount = 0;
  for (let i = 0; i < energies.length; i++) {
    if (energies[i] >= relGateSq) {
      gatedSumSq += energies[i];
      gatedCount++;
    }
  }

  const finalMeanSq = gatedCount > 0 ? gatedSumSq / gatedCount : ungatedMeanSq;
  return Math.sqrt(finalMeanSq);
}

/**
 * Trims pure dead digital silence (< -54 dBFS) at the splice boundary of a song
 * (up to maxTrimSec) so crossfades never dip into empty padding at the end of Song 1
 * or start of Song 2.
 */
export function findActiveSpliceBounds(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  trimLeading: boolean,
  trimTrailing: boolean,
  maxTrimSec = 2.2
): { start: number; end: number } {
  const total = left.length;
  const win = Math.max(256, Math.round(sampleRate * 0.02)); // 20ms window
  const maxTrimFrames = Math.min(Math.floor(total * 0.15), Math.round(sampleRate * maxTrimSec));
  const silenceRmsThreshold = 0.002; // ~ -54 dBFS

  let start = 0;
  let end = total;

  if (trimLeading) {
    while (start + win < maxTrimFrames) {
      let sumSq = 0;
      for (let i = 0; i < win; i++) {
        const l = left[start + i];
        const r = right[start + i];
        sumSq += 0.5 * (l * l + r * r);
      }
      if (Math.sqrt(sumSq / win) >= silenceRmsThreshold) {
        break;
      }
      start += win;
    }
    start = Math.max(0, start - Math.round(sampleRate * 0.015));
  }

  if (trimTrailing) {
    const minEnd = total - maxTrimFrames;
    while (end - win > minEnd) {
      let sumSq = 0;
      for (let i = 0; i < win; i++) {
        const l = left[end - win + i];
        const r = right[end - win + i];
        sumSq += 0.5 * (l * l + r * r);
      }
      if (Math.sqrt(sumSq / win) >= silenceRmsThreshold) {
        break;
      }
      end -= win;
    }
    end = Math.min(total, end + Math.round(sampleRate * 0.015));
  }

  if (end <= start + sampleRate) {
    return { start: 0, end: total };
  }
  return { start, end };
}

/**
 * Transparent soft-knee peak limiter ensuring zero harsh digital clipping.
 */
export function softLimitSample(x: number, ceiling = 0.97): number {
  const knee = 0.78;
  const abs = Math.abs(x);
  if (abs <= knee) return x;
  const sign = x < 0 ? -1 : 1;
  const span = ceiling - knee;
  const compressed = knee + span * Math.tanh((abs - knee) / Math.max(0.05, span));
  return sign * Math.min(ceiling, compressed);
}

/**
 * Lossless 16-bit Stereo 44.1 kHz RIFF WAV encoder used ONLY as automatic fallback
 * if the MP3 encoder ever fails to initialize on an unusual browser.
 */
export function encodeWav16BitStereo(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number
): ArrayBuffer {
  const numFrames = left.length;
  const numChannels = 2;
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = numFrames * blockAlign;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeAscii = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeAscii(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeAscii(8, 'WAVE');
  writeAscii(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM
  view.setUint16(20, 1, true); // Linear PCM
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeAscii(36, 'data');
  view.setUint32(40, dataSize, true);

  let offset = 44;
  for (let i = 0; i < numFrames; i++) {
    const sL = Math.max(-1, Math.min(1, softLimitSample(left[i], 0.98)));
    const sR = Math.max(-1, Math.min(1, softLimitSample(right[i], 0.98)));
    view.setInt16(offset, sL < 0 ? sL * 0x8000 : sL * 0x7fff, true);
    view.setInt16(offset + 2, sR < 0 ? sR * 0x8000 : sR * 0x7fff, true);
    offset += 4;
  }

  return buffer;
}
