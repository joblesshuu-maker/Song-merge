import {
  MergeSettings,
  MixRenderSummary,
  TrackAnalysis,
} from '../types/audio';
import {
  analyzeTrackCore,
  encodeMp3OrWavCore,
  MixDspCoreOutput,
  OverlapLoopDspOutput,
  probeAudioLibrariesCore,
  renderMixDspCore,
  renderOverlapLoopDspCore,
} from './audioProcessorCore';
import { encodeWav16BitStereo } from './dspHelpers';

const TARGET_SAMPLE_RATE = 44100;

export class FilePermissionError extends Error {
  public readonly isPermissionDenied = true;
  constructor(message: string) {
    super(message);
    this.name = 'FilePermissionError';
  }
}

let sharedDecodeCtx: AudioContext | null = null;

function getAudioContextConstructor(): typeof AudioContext | null {
  if (typeof window === 'undefined') return null;
  return (
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext ||
    null
  );
}

function getOfflineAudioContextConstructor(): typeof OfflineAudioContext | null {
  if (typeof window === 'undefined') return null;
  return (
    window.OfflineAudioContext ||
    (
      window as unknown as {
        webkitOfflineAudioContext?: typeof OfflineAudioContext;
      }
    ).webkitOfflineAudioContext ||
    null
  );
}

export function isWebAudioAvailable(): boolean {
  return Boolean(
    getAudioContextConstructor() && getOfflineAudioContextConstructor()
  );
}

/**
 * Real Web Audio health check: creates a 128-frame 44.1 kHz stereo OfflineAudioContext
 * and verifies actual rendered output samples.
 */
export async function verifyWebAudioSupport(): Promise<boolean> {
  try {
    const AudioCtx = getAudioContextConstructor();
    const OfflineCtx = getOfflineAudioContextConstructor();
    if (!AudioCtx || !OfflineCtx) return false;

    const offline = new OfflineCtx(2, 128, TARGET_SAMPLE_RATE);
    const buf = offline.createBuffer(2, 128, TARGET_SAMPLE_RATE);
    const ch0 = buf.getChannelData(0);
    for (let i = 0; i < 128; i++) {
      ch0[i] = 0.25;
    }
    const src = offline.createBufferSource();
    src.buffer = buf;
    src.connect(offline.destination);
    src.start(0);
    const rendered = await offline.startRendering();
    return (
      rendered.length === 128 &&
      Number.isFinite(rendered.getChannelData(0)[0]) &&
      rendered.getChannelData(0)[0] > 0.1
    );
  } catch {
    return false;
  }
}

export interface AudioLibrariesCheckResult {
  ready: boolean;
  soundTouchOk: boolean;
  lameMp3Ok: boolean;
  mode: 'worker' | 'main-thread';
  error?: string;
}

function createAudioWorkerSafely(): Worker | null {
  try {
    if (typeof Worker === 'undefined') return null;
    return new Worker(new URL('../workers/audioWorker.ts', import.meta.url), {
      type: 'module',
    });
  } catch {
    return null;
  }
}

/**
 * Real runtime check of SoundTouchJS + lamejs MP3 encoder.
 * Probes Worker first; if strict mobile WebView blocks module Workers, falls back cleanly to main-thread pure-JS engine.
 */
export async function verifyAudioLibrariesReady(): Promise<AudioLibrariesCheckResult> {
  const worker = createAudioWorkerSafely();
  if (worker) {
    try {
      const workerProbe = await new Promise<{
        soundTouchOk: boolean;
        lameMp3Ok: boolean;
        error?: string;
      }>((resolve, reject) => {
        const id = `probe-${Date.now()}`;
        const timer = window.setTimeout(() => {
          reject(new Error('Worker probe timeout'));
        }, 2500);

        worker.onmessage = (e) => {
          const data = e.data;
          if (data?.id !== id) return;
          window.clearTimeout(timer);
          if (data.type === 'HEALTH_PROBE_DONE') {
            resolve(data.report);
          } else {
            reject(new Error(data.error || 'Worker probe failed'));
          }
        };

        worker.onerror = () => {
          window.clearTimeout(timer);
          reject(new Error('Worker startup error'));
        };

        worker.postMessage({ type: 'HEALTH_PROBE', id });
      });

      worker.terminate();
      return {
        ready: workerProbe.soundTouchOk && workerProbe.lameMp3Ok,
        soundTouchOk: workerProbe.soundTouchOk,
        lameMp3Ok: workerProbe.lameMp3Ok,
        mode: 'worker',
        error: workerProbe.error,
      };
    } catch {
      worker.terminate();
      // Fall through to pure-JS main-thread verification for restricted WebViews
    }
  }

  const fallbackReport = probeAudioLibrariesCore();
  return {
    ready: fallbackReport.soundTouchOk && fallbackReport.lameMp3Ok,
    soundTouchOk: fallbackReport.soundTouchOk,
    lameMp3Ok: fallbackReport.lameMp3Ok,
    mode: 'main-thread',
    error: fallbackReport.error,
  };
}

function getDecodeContext(): AudioContext {
  const AudioCtx = getAudioContextConstructor();
  if (!AudioCtx) {
    throw new Error(
      'Aapke phone ka browser/WebView Web Audio support nahi karta. Chrome ya System WebView update karein.'
    );
  }
  if (!sharedDecodeCtx || sharedDecodeCtx.state === 'closed') {
    sharedDecodeCtx = new AudioCtx();
  }
  return sharedDecodeCtx;
}

function isLikelyPermissionError(err: unknown): boolean {
  if (!err || typeof err !== 'object') return false;
  const name = (err as { name?: string }).name || '';
  const msg = ((err as { message?: string }).message || '').toLowerCase();
  return (
    name === 'NotAllowedError' ||
    name === 'SecurityError' ||
    name === 'PermissionDeniedError' ||
    msg.includes('permission') ||
    msg.includes('not allowed') ||
    msg.includes('access denied')
  );
}

/**
 * Decodes an imported audio file (MP3/WAV/M4A/AAC/OGG/FLAC) on-device
 * and resamples cleanly to 44.1 kHz Stereo using native OfflineAudioContext.
 */
export async function decodeAudioFileTo44kStereo(file: File): Promise<AudioBuffer> {
  let arrayBuffer: ArrayBuffer;
  try {
    arrayBuffer = await file.arrayBuffer();
  } catch (err) {
    if (isLikelyPermissionError(err)) {
      throw new FilePermissionError(
        'Permission nahi mili — File chuno kaam nahi karega'
      );
    }
    throw new Error(
      'File read nahi ho payi. Permission ya storage check karke Retry dabao.'
    );
  }

  if (arrayBuffer.byteLength === 0) {
    throw new Error('Yeh file khali hai. Sahi MP3, WAV, ya M4A audio file chuno.');
  }

  const ctx = getDecodeContext();
  let decoded: AudioBuffer;
  try {
    decoded = await ctx.decodeAudioData(arrayBuffer.slice(0));
  } catch {
    throw new Error(
      'Audio file decode nahi ho payi. Kripya sahi MP3, WAV, ya M4A file chuno.'
    );
  }

  if (decoded.duration < 0.5) {
    throw new Error(
      'Audio file bahut chhoti hai (kam se kam 1 second honi chahiye).'
    );
  }

  if (
    decoded.sampleRate === TARGET_SAMPLE_RATE &&
    decoded.numberOfChannels === 2
  ) {
    return decoded;
  }

  const OfflineCtx = getOfflineAudioContextConstructor();
  if (!OfflineCtx) {
    return decoded;
  }

  const targetFrames = Math.max(
    1,
    Math.ceil(decoded.duration * TARGET_SAMPLE_RATE)
  );
  const offline = new OfflineCtx(2, targetFrames, TARGET_SAMPLE_RATE);
  const src = offline.createBufferSource();
  src.buffer = decoded;
  src.connect(offline.destination);
  src.start(0);

  return await offline.startRendering();
}

/**
 * Extracts the selected [trimStartSec, trimEndSec] portion of an imported AudioBuffer
 * with an 8ms micro-fade at cut boundaries so mid-waveform cuts never click.
 */
export function sliceAudioBuffer(
  fullBuffer: AudioBuffer,
  trimStartSec: number,
  trimEndSec: number
): AudioBuffer {
  const sr = fullBuffer.sampleRate;
  const totalFrames = fullBuffer.length;
  const startFrame = Math.max(
    0,
    Math.min(totalFrames - 1, Math.round(trimStartSec * sr))
  );
  const endFrame = Math.max(
    startFrame + 1,
    Math.min(totalFrames, Math.round(trimEndSec * sr))
  );

  if (startFrame === 0 && endFrame === totalFrames) {
    return fullBuffer;
  }

  const length = endFrame - startFrame;
  const sliced = getDecodeContext().createBuffer(
    fullBuffer.numberOfChannels,
    length,
    sr
  );

  const fadeFrames = Math.min(Math.round(sr * 0.008), Math.floor(length / 4));
  for (let ch = 0; ch < fullBuffer.numberOfChannels; ch++) {
    const src = fullBuffer.getChannelData(ch);
    const dst = sliced.getChannelData(ch);
    dst.set(src.subarray(startFrame, endFrame));

    if (startFrame > 0) {
      for (let i = 0; i < fadeFrames; i++) {
        dst[i] *= i / Math.max(1, fadeFrames);
      }
    }
    if (endFrame < totalFrames) {
      for (let i = 0; i < fadeFrames; i++) {
        dst[length - 1 - i] *= i / Math.max(1, fadeFrames);
      }
    }
  }

  return sliced;
}

/**
 * Runs BPM and gated loudness analysis in a background Web Worker (with main-thread WebView fallback).
 */
export async function analyzeTrackInWorker(
  buffer: AudioBuffer,
  preferEndSection: boolean
): Promise<TrackAnalysis> {
  const worker = createAudioWorkerSafely();
  if (worker) {
    try {
      return await new Promise<TrackAnalysis>((resolve, reject) => {
        const id = `analyze-${Date.now()}-${Math.random()}`;
        const leftCopy = new Float32Array(buffer.getChannelData(0));
        const rightCopy = new Float32Array(
          buffer.numberOfChannels > 1
            ? buffer.getChannelData(1)
            : buffer.getChannelData(0)
        );

        const cleanup = () => {
          worker.terminate();
        };

        worker.onmessage = (e) => {
          const data = e.data;
          if (data?.id !== id) return;
          if (data.type === 'ANALYZE_DONE') {
            cleanup();
            resolve(data.analysis as TrackAnalysis);
          } else if (data.type === 'WORKER_ERROR') {
            cleanup();
            resolve({ bpm: null, bpmConfidence: 0, rmsDb: -16 });
          }
        };

        worker.onerror = () => {
          cleanup();
          reject(new Error('Worker fallback'));
        };

        worker.postMessage(
          {
            type: 'ANALYZE_TRACK',
            id,
            left: leftCopy,
            right: rightCopy,
            sampleRate: buffer.sampleRate,
            preferEndSection,
          },
          [leftCopy.buffer, rightCopy.buffer]
        );
      });
    } catch {
      // Fall back to main-thread analysis in strict WebViews
    }
  }

  await new Promise((r) => window.setTimeout(r, 0));
  try {
    const ch0 = buffer.getChannelData(0);
    const ch1 =
      buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : ch0;
    return analyzeTrackCore(ch0, ch1, buffer.sampleRate, preferEndSection);
  } catch {
    return { bpm: null, bpmConfidence: 0, rmsDb: -16 };
  }
}

function createSoftVinylCrackleBuffer(
  ctx: BaseAudioContext,
  durationSec: number,
  sampleRate: number
): AudioBuffer {
  const loopSeconds = Math.min(Math.max(2, durationSec), 6);
  const frames = Math.max(1, Math.floor(loopSeconds * sampleRate));
  const crackleBuf = ctx.createBuffer(2, frames, sampleRate);
  const chL = crackleBuf.getChannelData(0);
  const chR = crackleBuf.getChannelData(1);

  let pinkStateL = 0;
  let pinkStateR = 0;
  let seed = 0x5f3759df;
  const nextRand = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 0xffffffff;
  };

  for (let i = 0; i < frames; i++) {
    const whiteL = nextRand() * 2 - 1;
    const whiteR = nextRand() * 2 - 1;
    pinkStateL = 0.92 * pinkStateL + 0.08 * whiteL;
    pinkStateR = 0.92 * pinkStateR + 0.08 * whiteR;

    let popL = 0;
    let popR = 0;
    const rTick = nextRand();
    if (rTick > 0.99945) {
      const amp = (0.18 + nextRand() * 0.35) * (nextRand() > 0.5 ? 1 : -1);
      popL = amp;
      popR = amp * (0.65 + nextRand() * 0.35);
    }

    const edge = Math.min(i, frames - 1 - i);
    const loopEnv = edge < 1024 ? edge / 1024 : 1;

    chL[i] = (pinkStateL * 0.16 + popL * 0.45) * loopEnv;
    chR[i] = (pinkStateR * 0.16 + popR * 0.45) * loopEnv;
  }

  return crackleBuf;
}

async function renderMasteringOfflineGraph(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number,
  lofi: boolean
): Promise<AudioBuffer> {
  const OfflineCtx = getOfflineAudioContextConstructor();
  if (!OfflineCtx) {
    throw new Error('OfflineAudioContext uplabdh nahi hai.');
  }

  const numFrames = left.length;
  const offline = new OfflineCtx(2, numFrames, sampleRate);

  const rawBuf = offline.createBuffer(2, numFrames, sampleRate);
  rawBuf.getChannelData(0).set(left);
  rawBuf.getChannelData(1).set(right);

  const source = offline.createBufferSource();
  source.buffer = rawBuf;

  let currentNode: AudioNode = source;

  if (lofi) {
    const hpFilter = offline.createBiquadFilter();
    hpFilter.type = 'highpass';
    hpFilter.frequency.value = 55;
    hpFilter.Q.value = 0.65;

    const lpFilter = offline.createBiquadFilter();
    lpFilter.type = 'lowpass';
    lpFilter.frequency.value = 3500;
    lpFilter.Q.value = 0.72;

    const warmEq = offline.createBiquadFilter();
    warmEq.type = 'peaking';
    warmEq.frequency.value = 320;
    warmEq.Q.value = 0.85;
    warmEq.gain.value = 1.8;

    const lofiComp = offline.createDynamicsCompressor();
    lofiComp.threshold.value = -20;
    lofiComp.knee.value = 24;
    lofiComp.ratio.value = 3.0;
    lofiComp.attack.value = 0.015;
    lofiComp.release.value = 0.22;

    const lofiMakeup = offline.createGain();
    lofiMakeup.gain.value = 1.14;

    currentNode.connect(hpFilter);
    hpFilter.connect(lpFilter);
    lpFilter.connect(warmEq);
    warmEq.connect(lofiComp);
    lofiComp.connect(lofiMakeup);
    currentNode = lofiMakeup;

    const durationSec = numFrames / sampleRate;
    const crackleBuffer = createSoftVinylCrackleBuffer(
      offline,
      durationSec,
      sampleRate
    );
    const crackleSrc = offline.createBufferSource();
    crackleSrc.buffer = crackleBuffer;
    crackleSrc.loop = true;

    const crackleBand = offline.createBiquadFilter();
    crackleBand.type = 'bandpass';
    crackleBand.frequency.value = 1900;
    crackleBand.Q.value = 0.65;

    const crackleGain = offline.createGain();
    const softLevel = 0.022;
    crackleGain.gain.setValueAtTime(0, 0);
    crackleGain.gain.linearRampToValueAtTime(
      softLevel,
      Math.min(0.8, durationSec * 0.1)
    );
    if (durationSec > 1.6) {
      crackleGain.gain.setValueAtTime(softLevel, durationSec - 0.8);
      crackleGain.gain.linearRampToValueAtTime(0, durationSec);
    }

    crackleSrc.connect(crackleBand);
    crackleBand.connect(crackleGain);
    crackleGain.connect(lofiComp);
    crackleSrc.start(0);
    crackleSrc.stop(durationSec);
  }

  const masterComp = offline.createDynamicsCompressor();
  masterComp.threshold.value = -12;
  masterComp.knee.value = 15;
  masterComp.ratio.value = 2.1;
  masterComp.attack.value = 0.006;
  masterComp.release.value = 0.16;

  const masterGain = offline.createGain();
  masterGain.gain.value = 1.04;

  currentNode.connect(masterComp);
  masterComp.connect(masterGain);
  masterGain.connect(offline.destination);

  source.start(0);
  return await offline.startRendering();
}

export interface OverlapLoopRenderResult {
  loopBuffer: AudioBuffer;
  xfadeStartInLoopSec: number;
  xfadeEndInLoopSec: number;
}

export async function renderOverlapLoopBuffer(
  song1Buffer: AudioBuffer,
  song2Buffer: AudioBuffer,
  settings: MergeSettings,
  options?: {
    userTrimmedEnd1?: boolean;
    userTrimmedStart2?: boolean;
    signal?: AbortSignal;
  }
): Promise<OverlapLoopRenderResult> {
  if (options?.signal?.aborted) {
    throw new DOMException('Aborted', 'AbortError');
  }

  let dspOut: OverlapLoopDspOutput | null = null;
  const worker = createAudioWorkerSafely();

  if (worker) {
    const onAbort = () => {
      worker.terminate();
    };
    options?.signal?.addEventListener('abort', onAbort, { once: true });

    try {
      const jobId = `loop-${Date.now()}-${Math.random()}`;
      const s1Left = new Float32Array(song1Buffer.getChannelData(0));
      const s1Right = new Float32Array(
        song1Buffer.numberOfChannels > 1
          ? song1Buffer.getChannelData(1)
          : song1Buffer.getChannelData(0)
      );
      const s2Left = new Float32Array(song2Buffer.getChannelData(0));
      const s2Right = new Float32Array(
        song2Buffer.numberOfChannels > 1
          ? song2Buffer.getChannelData(1)
          : song2Buffer.getChannelData(0)
      );

      dspOut = await new Promise<OverlapLoopDspOutput>((resolve, reject) => {
        if (options?.signal?.aborted) {
          reject(new DOMException('Aborted', 'AbortError'));
          return;
        }

        worker.onmessage = (e) => {
          const data = e.data;
          if (data?.id !== jobId) return;
          if (data.type === 'RENDER_OVERLAP_LOOP_DONE') {
            resolve({
              left: data.left,
              right: data.right,
              loopStartOutFrame: data.loopStartOutFrame,
              loopEndOutFrame: data.loopEndOutFrame,
              xfadeStartInLoopSec: data.xfadeStartInLoopSec,
              xfadeEndInLoopSec: data.xfadeEndInLoopSec,
            });
          } else if (data.type === 'WORKER_ERROR') {
            reject(new Error(data.error || 'Overlap loop DSP failed'));
          }
        };

        worker.onerror = () => {
          reject(new Error('WORKER_LOAD_FAIL'));
        };

        worker.postMessage(
          {
            type: 'RENDER_OVERLAP_LOOP_DSP',
            id: jobId,
            s1Left,
            s1Right,
            s2Left,
            s2Right,
            sampleRate: TARGET_SAMPLE_RATE,
            crossfadeSec: settings.crossfadeSec,
            autoMatch: settings.autoMatch,
            speedMode: settings.speedMode,
            speed: settings.speed,
            pitchSemitones: settings.pitchSemitones,
            lofi: settings.lofi,
            userTrimmedEnd1: options?.userTrimmedEnd1 ?? false,
            userTrimmedStart2: options?.userTrimmedStart2 ?? false,
          },
          [s1Left.buffer, s1Right.buffer, s2Left.buffer, s2Right.buffer]
        );
      });
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        throw err;
      }
      if (!(err instanceof Error && err.message === 'WORKER_LOAD_FAIL')) {
        throw err;
      }
      // If module worker was blocked by a custom WebView, fall through to main-thread DSP
    } finally {
      options?.signal?.removeEventListener('abort', onAbort);
      worker.terminate();
    }
  }

  if (!dspOut) {
    await new Promise((r) => window.setTimeout(r, 0));
    if (options?.signal?.aborted) {
      throw new DOMException('Aborted', 'AbortError');
    }
    dspOut = renderOverlapLoopDspCore({
      s1Left: song1Buffer.getChannelData(0),
      s1Right:
        song1Buffer.numberOfChannels > 1
          ? song1Buffer.getChannelData(1)
          : song1Buffer.getChannelData(0),
      s2Left: song2Buffer.getChannelData(0),
      s2Right:
        song2Buffer.numberOfChannels > 1
          ? song2Buffer.getChannelData(1)
          : song2Buffer.getChannelData(0),
      sampleRate: TARGET_SAMPLE_RATE,
      crossfadeSec: settings.crossfadeSec,
      autoMatch: settings.autoMatch,
      speedMode: settings.speedMode,
      speed: settings.speed,
      pitchSemitones: settings.pitchSemitones,
      lofi: settings.lofi,
      userTrimmedEnd1: options?.userTrimmedEnd1 ?? false,
      userTrimmedStart2: options?.userTrimmedStart2 ?? false,
    });
  }

  if (options?.signal?.aborted) {
    throw new DOMException('Aborted', 'AbortError');
  }

  const masteredExcerpt = await renderMasteringOfflineGraph(
    dspOut.left,
    dspOut.right,
    TARGET_SAMPLE_RATE,
    settings.lofi
  );

  if (options?.signal?.aborted) {
    throw new DOMException('Aborted', 'AbortError');
  }

  const sFrame = Math.max(
    0,
    Math.min(masteredExcerpt.length - 1, dspOut.loopStartOutFrame)
  );
  const eFrame = Math.max(
    sFrame + 1,
    Math.min(masteredExcerpt.length, dspOut.loopEndOutFrame)
  );
  const loopFrames = eFrame - sFrame;

  const loopBuf = getDecodeContext().createBuffer(
    2,
    loopFrames,
    TARGET_SAMPLE_RATE
  );

  const wrapAvail = Math.min(
    Math.round(TARGET_SAMPLE_RATE * 0.03),
    masteredExcerpt.length - eFrame,
    Math.floor(loopFrames / 6)
  );

  for (let ch = 0; ch < 2; ch++) {
    const src = masteredExcerpt.getChannelData(ch);
    const dst = loopBuf.getChannelData(ch);
    dst.set(src.subarray(sFrame, eFrame));

    if (wrapAvail > 16) {
      for (let i = 0; i < wrapAvail; i++) {
        const t = i / wrapAvail;
        const gHead = Math.sin(t * Math.PI * 0.5);
        const gTail = Math.cos(t * Math.PI * 0.5);
        dst[i] = dst[i] * gHead + src[eFrame + i] * gTail;
      }
    } else {
      const micro = Math.min(
        Math.round(TARGET_SAMPLE_RATE * 0.012),
        Math.floor(loopFrames / 6)
      );
      for (let i = 0; i < micro; i++) {
        const g = i / Math.max(1, micro);
        dst[i] *= g;
        dst[loopFrames - 1 - i] *= g;
      }
    }
  }

  return {
    loopBuffer: loopBuf,
    xfadeStartInLoopSec: dspOut.xfadeStartInLoopSec,
    xfadeEndInLoopSec: Math.min(loopBuf.duration, dspOut.xfadeEndInLoopSec),
  };
}

export interface FullMixPipelineCallbacks {
  onDspProgress: (percent: number, stageText: string) => void;
  onPreviewBufferReady: (buffer: AudioBuffer) => void;
  onMp3Progress: (percent: number) => void;
}

export interface FullMixPipelineResult {
  previewBuffer: AudioBuffer;
  exportBlob: Blob;
  summary: MixRenderSummary;
}

export async function renderAndEncodeSeamlessMix(
  song1Buffer: AudioBuffer,
  song2Buffer: AudioBuffer,
  settings: MergeSettings,
  callbacks: FullMixPipelineCallbacks,
  options?: { userTrimmedEnd1?: boolean; userTrimmedStart2?: boolean }
): Promise<FullMixPipelineResult> {
  const worker = createAudioWorkerSafely();
  let useMainThreadFallback = !worker;
  let dspResult: MixDspCoreOutput | null = null;

  try {
    if (worker) {
      try {
        const dspJobId = `dsp-${Date.now()}`;
        const s1Left = new Float32Array(song1Buffer.getChannelData(0));
        const s1Right = new Float32Array(
          song1Buffer.numberOfChannels > 1
            ? song1Buffer.getChannelData(1)
            : song1Buffer.getChannelData(0)
        );
        const s2Left = new Float32Array(song2Buffer.getChannelData(0));
        const s2Right = new Float32Array(
          song2Buffer.numberOfChannels > 1
            ? song2Buffer.getChannelData(1)
            : song2Buffer.getChannelData(0)
        );

        dspResult = await new Promise<MixDspCoreOutput>((resolve, reject) => {
          worker.onmessage = (e) => {
            const data = e.data;
            if (data?.id !== dspJobId) return;
            if (data.type === 'DSP_PROGRESS') {
              callbacks.onDspProgress(data.percent, data.stage);
            } else if (data.type === 'RENDER_MIX_DSP_DONE') {
              resolve({
                left: data.left,
                right: data.right,
                stats: data.stats,
              });
            } else if (data.type === 'WORKER_ERROR') {
              reject(new Error(data.error || 'Mix DSP failed'));
            }
          };
          worker.onerror = () => {
            reject(new Error('WORKER_LOAD_FAIL'));
          };

          worker.postMessage(
            {
              type: 'RENDER_MIX_DSP',
              id: dspJobId,
              s1Left,
              s1Right,
              s2Left,
              s2Right,
              sampleRate: TARGET_SAMPLE_RATE,
              crossfadeSec: settings.crossfadeSec,
              autoMatch: settings.autoMatch,
              speedMode: settings.speedMode,
              speed: settings.speed,
              pitchSemitones: settings.pitchSemitones,
              lofi: settings.lofi,
              userTrimmedEnd1: options?.userTrimmedEnd1 ?? false,
              userTrimmedStart2: options?.userTrimmedStart2 ?? false,
            },
            [s1Left.buffer, s1Right.buffer, s2Left.buffer, s2Right.buffer]
          );
        });
      } catch (err) {
        if (err instanceof Error && err.message === 'WORKER_LOAD_FAIL') {
          useMainThreadFallback = true;
        } else {
          throw err;
        }
      }
    }

    if (useMainThreadFallback || !dspResult) {
      await new Promise((r) => window.setTimeout(r, 20));
      dspResult = renderMixDspCore({
        s1Left: song1Buffer.getChannelData(0),
        s1Right:
          song1Buffer.numberOfChannels > 1
            ? song1Buffer.getChannelData(1)
            : song1Buffer.getChannelData(0),
        s2Left: song2Buffer.getChannelData(0),
        s2Right:
          song2Buffer.numberOfChannels > 1
            ? song2Buffer.getChannelData(1)
            : song2Buffer.getChannelData(0),
        sampleRate: TARGET_SAMPLE_RATE,
        crossfadeSec: settings.crossfadeSec,
        autoMatch: settings.autoMatch,
        speedMode: settings.speedMode,
        speed: settings.speed,
        pitchSemitones: settings.pitchSemitones,
        lofi: settings.lofi,
        userTrimmedEnd1: options?.userTrimmedEnd1 ?? false,
        userTrimmedStart2: options?.userTrimmedStart2 ?? false,
        onProgress: callbacks.onDspProgress,
      });
    }

    callbacks.onDspProgress(100, 'Final studio mastering apply ho raha hai...');
    const finalMixBuffer = await renderMasteringOfflineGraph(
      dspResult.left,
      dspResult.right,
      TARGET_SAMPLE_RATE,
      settings.lofi
    );

    callbacks.onPreviewBufferReady(finalMixBuffer);

    const finalDurationSec = finalMixBuffer.duration;
    const expectedDur = dspResult.stats.expectedDurationSec;
    const finalTempo = settings.speed * (settings.lofi ? 0.85 : 1.0);
    const trimmedFormulaDur =
      (song1Buffer.duration +
        song2Buffer.duration / dspResult.stats.song2MatchedTempoRatio -
        dspResult.stats.effectiveCrossfadeSec) /
      finalTempo;

    const durationDiff = Math.abs(finalDurationSec - expectedDur);
    const trimmedFormulaDiff = Math.abs(finalDurationSec - trimmedFormulaDur);
    if (
      finalDurationSec <= 0.2 ||
      durationDiff > Math.max(3.0, expectedDur * 0.08) ||
      trimmedFormulaDiff > Math.max(5.5, trimmedFormulaDur * 0.12)
    ) {
      throw new Error(
        'Rendered mix duration verify nahi ho paya. Kripya Retry / Merge karo dabayein.'
      );
    }

    callbacks.onMp3Progress(0);
    let encodeOutput: {
      buffer: ArrayBuffer;
      format: 'mp3' | 'wav';
      wavFallbackUsed: boolean;
    };

    if (!useMainThreadFallback && worker) {
      const encodeJobId = `mp3-${Date.now()}`;
      const encLeft = new Float32Array(finalMixBuffer.getChannelData(0));
      const encRight = new Float32Array(finalMixBuffer.getChannelData(1));

      encodeOutput = await new Promise<{
        buffer: ArrayBuffer;
        format: 'mp3' | 'wav';
        wavFallbackUsed: boolean;
      }>((resolve, reject) => {
        worker.onmessage = (e) => {
          const data = e.data;
          if (data?.id !== encodeJobId) return;
          if (data.type === 'MP3_PROGRESS') {
            callbacks.onMp3Progress(data.percent);
          } else if (data.type === 'ENCODE_DONE') {
            resolve({
              buffer: data.buffer,
              format: data.format,
              wavFallbackUsed: data.wavFallbackUsed,
            });
          } else if (data.type === 'WORKER_ERROR') {
            reject(new Error(data.error || 'MP3 encoding failed'));
          }
        };
        worker.onerror = (err) => {
          reject(new Error(err.message || 'MP3 worker error'));
        };

        worker.postMessage(
          {
            type: 'ENCODE_MP3',
            id: encodeJobId,
            left: encLeft,
            right: encRight,
            sampleRate: TARGET_SAMPLE_RATE,
          },
          [encLeft.buffer, encRight.buffer]
        );
      });
    } else {
      await new Promise((r) => window.setTimeout(r, 20));
      encodeOutput = encodeMp3OrWavCore(
        finalMixBuffer.getChannelData(0),
        finalMixBuffer.getChannelData(1),
        TARGET_SAMPLE_RATE,
        callbacks.onMp3Progress
      );
    }

    let finalBlob: Blob;
    let finalFormat: 'mp3' | 'wav' = encodeOutput.format;
    let wavFallbackUsed = encodeOutput.wavFallbackUsed;

    if (finalFormat === 'mp3') {
      const minExpectedMp3Bytes = Math.max(
        1024,
        Math.floor(finalDurationSec * 30000)
      );
      if (encodeOutput.buffer.byteLength < minExpectedMp3Bytes) {
        const wavBuf = encodeWav16BitStereo(
          finalMixBuffer.getChannelData(0),
          finalMixBuffer.getChannelData(1),
          TARGET_SAMPLE_RATE
        );
        finalBlob = new Blob([wavBuf], { type: 'audio/wav' });
        finalFormat = 'wav';
        wavFallbackUsed = true;
      } else {
        finalBlob = new Blob([encodeOutput.buffer], { type: 'audio/mpeg' });
      }
    } else {
      finalBlob = new Blob([encodeOutput.buffer], { type: 'audio/wav' });
    }

    if (finalBlob.size <= 0) {
      throw new Error('Export file size 0 aaya — kripya Retry dabayein.');
    }

    return {
      previewBuffer: finalMixBuffer,
      exportBlob: finalBlob,
      summary: {
        song1Bpm: dspResult.stats.song1Bpm,
        song2Bpm: dspResult.stats.song2Bpm,
        song2MatchedTempoRatio: dspResult.stats.song2MatchedTempoRatio,
        song2PitchShiftSemitones: dspResult.stats.song2PitchShiftSemitones,
        autoMatchApplied: dspResult.stats.autoMatchApplied,
        effectiveCrossfadeSec: dspResult.stats.effectiveCrossfadeSec,
        transitionStartSec: dspResult.stats.transitionStartSec,
        transitionEndSec: dspResult.stats.transitionEndSec,
        finalDurationSec,
        expectedDurationSec: expectedDur,
        fileSizeBytes: finalBlob.size,
        format: finalFormat,
        wavFallbackUsed,
      },
    };
  } finally {
    worker?.terminate();
  }
}
