import { YouTubeSongInfo } from '../types/audio';

/**
 * Extracts the 11-character YouTube video ID from common YouTube URL formats
 * (youtu.be, youtube.com/watch, m.youtube.com, music.youtube.com, shorts, embed, live).
 */
export function extractYouTubeVideoId(rawInput: string): string | null {
  const trimmed = rawInput.trim();
  if (!trimmed) return null;

  let candidate = trimmed;
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = `https://${candidate}`;
  }

  try {
    const parsed = new URL(candidate);
    const host = parsed.hostname
      .replace(/^(www\.|m\.|music\.)/i, '')
      .toLowerCase();

    let videoId: string | null = null;

    if (host === 'youtu.be') {
      const seg = parsed.pathname.split('/').filter(Boolean)[0];
      if (seg) videoId = seg;
    } else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
      if (parsed.pathname === '/watch') {
        videoId = parsed.searchParams.get('v');
      } else if (
        parsed.pathname.startsWith('/shorts/') ||
        parsed.pathname.startsWith('/embed/') ||
        parsed.pathname.startsWith('/live/')
      ) {
        const seg = parsed.pathname.split('/').filter(Boolean)[1];
        if (seg) videoId = seg;
      }
    }

    if (videoId && /^[a-zA-Z0-9_-]{6,15}$/.test(videoId)) {
      return videoId;
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * Extracts a canonical YouTube watch URL from common mobile & desktop YouTube link formats.
 */
export function normalizeYouTubeUrl(rawInput: string): string | null {
  const videoId = extractYouTubeVideoId(rawInput);
  if (videoId) {
    return `https://www.youtube.com/watch?v=${videoId}`;
  }

  const trimmed = rawInput.trim();
  if (!trimmed) return null;
  let candidate = trimmed;
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = `https://${candidate}`;
  }

  try {
    const parsed = new URL(candidate);
    const host = parsed.hostname
      .replace(/^(www\.|m\.|music\.)/i, '')
      .toLowerCase();
    if (host === 'youtube.com' || host === 'youtu.be') {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export class OfflineNetworkError extends Error {
  public readonly isOfflineError = true;
  constructor(
    message = 'Internet nahi hai — YouTube info ke liye Wi-Fi ya mobile data on karke Retry dabao.'
  ) {
    super(message);
    this.name = 'OfflineNetworkError';
  }
}

/**
 * Fetches song metadata (title, channel, thumbnail) using YouTube's public oEmbed endpoint.
 * Never downloads or claims to download YouTube audio.
 */
export async function fetchYouTubeSongInfo(
  rawUrl: string
): Promise<YouTubeSongInfo> {
  const canonicalUrl = normalizeYouTubeUrl(rawUrl);
  if (!canonicalUrl) {
    throw new Error(
      'Sahi YouTube link daalo (jaise youtube.com/watch?v=... ya youtu.be/...)'
    );
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    throw new OfflineNetworkError();
  }

  const ytOembedEndpoint = `https://www.youtube.com/oembed?url=${encodeURIComponent(
    canonicalUrl
  )}&format=json`;

  let primaryHttpStatus: number | null = null;

  try {
    const res = await fetch(ytOembedEndpoint);
    primaryHttpStatus = res.status;
    if (!res.ok) {
      throw new Error(`Status ${res.status}`);
    }
    const data = await res.json();
    if (!data || typeof data.title !== 'string') {
      throw new Error('Invalid oEmbed payload');
    }
    return {
      title: data.title,
      authorName:
        typeof data.author_name === 'string'
          ? data.author_name
          : 'YouTube Channel',
      thumbnailUrl:
        typeof data.thumbnail_url === 'string' ? data.thumbnail_url : '',
      canonicalUrl,
    };
  } catch {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      throw new OfflineNetworkError();
    }

    let fallbackRes: Response;
    try {
      fallbackRes = await fetch(
        `https://noembed.com/embed?url=${encodeURIComponent(canonicalUrl)}`
      );
    } catch {
      // Both endpoints failed at network level -> no internet / blocked connection
      if (primaryHttpStatus === null) {
        throw new OfflineNetworkError();
      }
      throw new Error(
        'YouTube se song info nahi mil paya. Link check karke Retry dabao.'
      );
    }

    if (!fallbackRes.ok) {
      throw new Error(
        'YouTube se song info nahi mil paya. Link check karke Retry dabao.'
      );
    }

    const fallbackData = await fallbackRes.json();
    if (fallbackData.error || typeof fallbackData.title !== 'string') {
      throw new Error('Is YouTube link ka info available nahi hai.');
    }
    return {
      title: fallbackData.title,
      authorName:
        typeof fallbackData.author_name === 'string'
          ? fallbackData.author_name
          : 'YouTube',
      thumbnailUrl:
        typeof fallbackData.thumbnail_url === 'string'
          ? fallbackData.thumbnail_url
          : '',
      canonicalUrl,
    };
  }
}
