export interface SaveAudioResult {
  ok: boolean;
  method: 'anchor' | 'share' | 'cancelled' | 'none';
  message: string;
}

function isIOSStandaloneWebKit(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') {
    return false;
  }
  const ua = navigator.userAgent.toLowerCase();
  const isIOS = /iphone|ipad|ipod/.test(ua);
  const isStandalone =
    (navigator as unknown as { standalone?: boolean }).standalone === true ||
    (typeof window.matchMedia === 'function' &&
      window.matchMedia('(display-mode: standalone)').matches);
  return isIOS && isStandalone;
}

function isAndroidCustomWebView(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /;\s*wv\)/i.test(navigator.userAgent || '');
}

export function canShareAudioFile(blob: Blob, filename: string, mimeType: string): boolean {
  try {
    if (
      typeof navigator === 'undefined' ||
      typeof navigator.share !== 'function' ||
      typeof File !== 'function'
    ) {
      return false;
    }
    const testFile = new File([blob], filename, { type: mimeType });
    if (typeof navigator.canShare === 'function') {
      return navigator.canShare({ files: [testFile] });
    }
    return true;
  } catch {
    return false;
  }
}

export async function shareAudioFileWithSystem(
  blob: Blob,
  filename: string,
  mimeType: string
): Promise<SaveAudioResult> {
  if (!(blob instanceof Blob) || blob.size <= 0) {
    return {
      ok: false,
      method: 'none',
      message: 'Exported file khali hai — kripya dobara Merge karo dabayein.',
    };
  }

  try {
    if (typeof navigator === 'undefined' || typeof navigator.share !== 'function') {
      return {
        ok: false,
        method: 'none',
        message: 'Is phone/browser me Share feature uplabdh nahi hai.',
      };
    }

    const file = new File([blob], filename, { type: mimeType });
    if (typeof navigator.canShare === 'function' && !navigator.canShare({ files: [file] })) {
      return {
        ok: false,
        method: 'none',
        message: 'Ye WebView/browser audio file share support nahi karta.',
      };
    }

    await navigator.share({
      files: [file],
      title: filename,
    });

    return {
      ok: true,
      method: 'share',
      message: `${filename} phone me share/save ho gayi.`,
    };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return {
        ok: false,
        method: 'cancelled',
        message: 'Save cancel kiya gaya — dobara save karne ke liye Download ya Retry dabao.',
      };
    }
    return {
      ok: false,
      method: 'none',
      message:
        'MP3 file save nahi ho payi. Phone storage ya permission check karke Retry dabao.',
    };
  }
}

/**
 * Saves the exported MP3/WAV file reliably in both phone browsers and installed apps/WebViews:
 * 1. Anchor <a download> (skipped on iOS standalone WebKit / Android wv if blob anchor download is unsupported)
 * 2. Fallback to navigator.share({ files: [file] })
 * 3. Clear plain-words failure message + Retry (never falsely shows "Download complete" without a real file)
 */
export async function saveExportedAudioFile(
  blob: Blob | null,
  filename: string,
  mimeType: string
): Promise<SaveAudioResult> {
  if (!blob || !(blob instanceof Blob) || blob.size <= 0) {
    return {
      ok: false,
      method: 'none',
      message: 'MP3 file abhi taiyaar nahi hai. Pehle Merge karo dabayein.',
    };
  }

  const anchorSupported =
    typeof document !== 'undefined' &&
    'download' in HTMLAnchorElement.prototype &&
    typeof URL !== 'undefined' &&
    typeof URL.createObjectURL === 'function';

  // In iOS standalone PWA or Android custom WebView where blob: <a download> often fails when Web Share is supported:
  // Note: Per strict cascade, try anchor download first whenever supported (except iOS standalone where WebKit ignores <a download> on blob:),
  // and if anchor throws or fails, fall back immediately to navigator.share with the File.
  if (anchorSupported && !isIOSStandaloneWebKit()) {
    try {
      // On Android custom WebView (; wv), some wrappers throw or block blob: downloads without a DownloadListener;
      // if navigator.share with file is available on wv and anchor fails, we fall through cleanly.
      const url = URL.createObjectURL(blob);
      if (!url || !url.startsWith('blob:')) {
        throw new Error('Blob URL creation failed');
      }

      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      anchor.rel = 'noopener';
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);

      window.setTimeout(() => {
        try {
          URL.revokeObjectURL(url);
        } catch {
          // ignore
        }
      }, 20000);

      // In Android WebView (; wv), inform honestly in case the host APK lacked a blob DownloadListener
      const extraHint =
        isAndroidCustomWebView() && canShareAudioFile(blob, filename, mimeType)
          ? ` Agar Downloads folder me ${filename} na dikhe, to niche "Phone me Save / Share" dabao.`
          : '';

      return {
        ok: true,
        method: 'anchor',
        message: `${filename} download shuru ho gaya (${Math.max(
          1,
          Math.round(blob.size / 1024)
        )} KB).${extraHint}`,
      };
    } catch {
      // Anchor download failed -> proceed immediately to Step 2: navigator.share with File
    }
  }

  // Step 2: Fallback to navigator.share with the exported File
  const shareRes = await shareAudioFileWithSystem(blob, filename, mimeType);
  if (shareRes.ok || shareRes.method === 'cancelled') {
    return shareRes;
  }

  // Step 3: Clear failure message so UI shows Retry
  return {
    ok: false,
    method: 'none',
    message:
      'MP3 file download nahi ho payi. Phone storage space ya permission check karke Retry dabao.',
  };
}
