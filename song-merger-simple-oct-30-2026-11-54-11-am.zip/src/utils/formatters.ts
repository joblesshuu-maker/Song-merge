export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const totalSec = Math.round(seconds);
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Parses a user-entered MM:SS (or H:MM:SS or plain seconds) string into seconds.
 * Returns null if the format is incomplete or invalid.
 */
export function parseMmSsToSeconds(raw: string): number | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;

  if (/^\d+(\.\d+)?$/.test(trimmed)) {
    const val = parseFloat(trimmed);
    return Number.isFinite(val) && val >= 0 ? val : null;
  }

  const parts = trimmed.split(':');
  if (parts.length === 2) {
    const [mStr, sStr] = parts;
    if (!/^\d+$/.test(mStr) || !/^\d+(\.\d+)?$/.test(sStr)) return null;
    const mins = parseInt(mStr, 10);
    const secs = parseFloat(sStr);
    if (secs >= 60 || mins < 0 || secs < 0) return null;
    return mins * 60 + secs;
  }

  if (parts.length === 3) {
    const [hStr, mStr, sStr] = parts;
    if (!/^\d+$/.test(hStr) || !/^\d+$/.test(mStr) || !/^\d+(\.\d+)?$/.test(sStr)) {
      return null;
    }
    const hrs = parseInt(hStr, 10);
    const mins = parseInt(mStr, 10);
    const secs = parseFloat(sStr);
    if (mins >= 60 || secs >= 60) return null;
    return hrs * 3600 + mins * 60 + secs;
  }

  return null;
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 MB';
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) {
    return `${mb.toFixed(1)} MB`;
  }
  const kb = Math.max(1, Math.round(bytes / 1024));
  return `${kb} KB`;
}

export function stripFileExtension(filename: string): string {
  return filename.replace(/\.[^/.]+$/, '').replace(/[_-]+/g, ' ').trim() || filename;
}
