import { probeRealInternet } from '../hooks/useOnlineStatus';
import {
  verifyAudioLibrariesReady,
  verifyWebAudioSupport,
} from './audioEngine';

export type HealthItemStatus = 'checking' | 'pass' | 'fail';

export interface HealthCheckItem {
  key: 'internet' | 'webAudio' | 'filePicker' | 'audioLibs' | 'download';
  label: string;
  status: HealthItemStatus;
  detail: string;
  fixHint?: string;
}

export interface FullHealthReport {
  items: HealthCheckItem[];
  webAudioOk: boolean;
  audioLibsOk: boolean;
  filePickerOk: boolean;
  internetOk: boolean;
  downloadOk: boolean;
}

function testRealFilePickerSupport(): {
  ok: boolean;
  detail: string;
  fixHint?: string;
} {
  try {
    if (typeof document === 'undefined' || typeof File === 'undefined') {
      return {
        ok: false,
        detail: 'System file picker support nahi mila',
        fixHint:
          'App Settings > Permissions me file access allow karo ya phone ke Chrome browser me kholo.',
      };
    }

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'audio/*,.mp3,.wav,.m4a';
    const hasClick = typeof input.click === 'function';
    const hasArrayBuffer = typeof Blob.prototype.arrayBuffer === 'function';
    const isSupported = input.type === 'file' && hasClick && hasArrayBuffer;

    if (!isSupported) {
      return {
        ok: false,
        detail: 'Is WebView me file chooser band hai',
        fixHint:
          'Settings > Apps > Song Merger > Permissions me allow karo ya Chrome browser use karo.',
      };
    }

    return {
      ok: true,
      detail: 'System file picker ready (permission sirf File chuno par mangi jayegi)',
    };
  } catch {
    return {
      ok: false,
      detail: 'File picker test fail hua',
      fixHint:
        'Settings > Apps > Song Merger > Permissions me allow karo aur Retry dabao.',
    };
  }
}

function testRealDownloadCapability(): {
  ok: boolean;
  detail: string;
  fixHint?: string;
} {
  try {
    if (typeof Blob === 'undefined' || typeof URL === 'undefined') {
      return {
        ok: false,
        detail: 'Blob / download support nahi mila',
        fixHint:
          'Phone ke Chrome browser me kholo ya Android System WebView update karo.',
      };
    }

    // Create a real 4-byte MP3 frame header test Blob and verify ObjectURL creation
    const testBytes = new Uint8Array([0xff, 0xfb, 0xe0, 0x64]);
    const testBlob = new Blob([testBytes], { type: 'audio/mpeg' });
    if (testBlob.size !== 4) {
      throw new Error('Blob empty');
    }

    let objectUrlOk = false;
    if (typeof URL.createObjectURL === 'function') {
      const testUrl = URL.createObjectURL(testBlob);
      objectUrlOk = typeof testUrl === 'string' && testUrl.startsWith('blob:');
      URL.revokeObjectURL(testUrl);
    }

    const anchorDownloadOk =
      typeof document !== 'undefined' &&
      'download' in document.createElement('a') &&
      objectUrlOk;

    let fileShareOk = false;
    if (
      typeof navigator !== 'undefined' &&
      typeof navigator.share === 'function' &&
      typeof File === 'function'
    ) {
      const testFile = new File([testBlob], 'health-test.mp3', {
        type: 'audio/mpeg',
      });
      fileShareOk =
        typeof navigator.canShare === 'function'
          ? navigator.canShare({ files: [testFile] })
          : true;
    }

    if (!anchorDownloadOk && !fileShareOk) {
      return {
        ok: false,
        detail: 'Download aur file share dono is WebView me blocked hain',
        fixHint:
          'Settings > Apps > Song Merger > Permissions me storage allow karo ya Chrome browser me kholo.',
      };
    }

    return {
      ok: true,
      detail:
        anchorDownloadOk && fileShareOk
          ? 'Direct MP3 download + Share fallback ready'
          : anchorDownloadOk
            ? 'Direct MP3 download ready'
            : 'System Share save ready',
    };
  } catch {
    return {
      ok: false,
      detail: 'MP3 download test fail hua',
      fixHint:
        'App storage permission check karo ya phone ke Chrome browser me kholo.',
    };
  }
}

/**
 * Executes all 5 REAL runtime checks (Internet, Web Audio, File picker, Audio libraries loaded, Download test).
 */
export async function runRealHealthChecks(): Promise<FullHealthReport> {
  const [internetOk, webAudioOk, libsResult] = await Promise.all([
    probeRealInternet(3800),
    verifyWebAudioSupport(),
    verifyAudioLibrariesReady(),
  ]);

  const filePickerRes = testRealFilePickerSupport();
  const downloadRes = testRealDownloadCapability();

  const items: HealthCheckItem[] = [
    {
      key: 'internet',
      label: 'Internet',
      status: internetOk ? 'pass' : 'fail',
      detail: internetOk
        ? 'Connected (YouTube info aur player ready)'
        : 'Internet nahi hai',
      fixHint: internetOk
        ? undefined
        : 'YouTube info/player ke liye Wi-Fi ya mobile data on karo. Bina internet ke bhi File chuno, Trim, Merge aur MP3 Export kaam karenge.',
    },
    {
      key: 'webAudio',
      label: 'Web Audio',
      status: webAudioOk ? 'pass' : 'fail',
      detail: webAudioOk
        ? '44.1 kHz stereo audio engine ready'
        : 'Web Audio kaam nahi kar raha',
      fixHint: webAudioOk
        ? undefined
        : 'Play Store se Android System WebView ya Chrome browser update karke Retry dabao.',
    },
    {
      key: 'filePicker',
      label: 'File picker',
      status: filePickerRes.ok ? 'pass' : 'fail',
      detail: filePickerRes.detail,
      fixHint: filePickerRes.fixHint,
    },
    {
      key: 'audioLibs',
      label: 'Audio libraries loaded',
      status: libsResult.ready ? 'pass' : 'fail',
      detail: libsResult.ready
        ? `SoundTouch + MP3 320 kbps encoder ready (${
            libsResult.mode === 'worker' ? 'background worker' : 'on-device JS'
          })`
        : 'Merge / MP3 library load nahi ho payi',
      fixHint: libsResult.ready
        ? undefined
        : 'Internet on karke Retry dabao ya app ko ek baar reload karo. Tab tak core file import aur preview kaam karega.',
    },
    {
      key: 'download',
      label: 'Download test',
      status: downloadRes.ok ? 'pass' : 'fail',
      detail: downloadRes.detail,
      fixHint: downloadRes.fixHint,
    },
  ];

  return {
    items,
    webAudioOk,
    audioLibsOk: libsResult.ready,
    filePickerOk: filePickerRes.ok,
    internetOk,
    downloadOk: downloadRes.ok,
  };
}
