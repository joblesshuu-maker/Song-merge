import { useCallback, useEffect, useState } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

// Capture beforeinstallprompt immediately at module load so early Chromium events are never missed
let earlyDeferredPrompt: BeforeInstallPromptEvent | null = null;
const promptListeners = new Set<(ev: BeforeInstallPromptEvent | null) => void>();

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    earlyDeferredPrompt = e as BeforeInstallPromptEvent;
    promptListeners.forEach((fn) => fn(earlyDeferredPrompt));
  });

  window.addEventListener('appinstalled', () => {
    earlyDeferredPrompt = null;
    promptListeners.forEach((fn) => fn(null));
  });
}

function detectStandaloneOrInstalledWebView(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const standaloneMedia =
      typeof window.matchMedia === 'function' &&
      (window.matchMedia('(display-mode: standalone)').matches ||
        window.matchMedia('(display-mode: fullscreen)').matches ||
        window.matchMedia('(display-mode: minimal-ui)').matches);

    const iosStandalone =
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;

    const twaReferrer =
      typeof document !== 'undefined' &&
      typeof document.referrer === 'string' &&
      document.referrer.startsWith('android-app://');

    // Android installed WebView wrapper detection (; wv) when NOT inside a desktop preview iframe
    const ua = window.navigator.userAgent || '';
    const isAndroidWebView = /;\s*wv\)/i.test(ua);

    return Boolean(standaloneMedia || iosStandalone || twaReferrer || isAndroidWebView);
  } catch {
    return false;
  }
}

/**
 * Verifies whether a real Android .apk package binary is hosted (magic ZIP/APK header PK\x03\x04),
 * ensuring SPA HTML fallbacks are never treated as an APK file.
 */
async function probeRealHostedApkUrl(): Promise<string | null> {
  const configuredUrl = (
    import.meta.env.VITE_APK_URL as string | undefined
  )?.trim();
  const candidates = configuredUrl
    ? [configuredUrl, '/song-merger.apk']
    : ['/song-merger.apk'];

  for (const url of candidates) {
    try {
      const res = await fetch(url, {
        method: 'GET',
        headers: { Range: 'bytes=0-3' },
        cache: 'no-store',
      });
      if (!res.ok && res.status !== 206) continue;
      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      if (contentType.includes('text/html')) continue;

      const buf = new Uint8Array(await res.arrayBuffer());
      // Valid APK (ZIP archive) starts with 0x50 0x4B 0x03 0x04 ("PK\x03\x04")
      if (
        buf.byteLength >= 4 &&
        buf[0] === 0x50 &&
        buf[1] === 0x4b &&
        buf[2] === 0x03 &&
        buf[3] === 0x04
      ) {
        return url;
      }
    } catch {
      // Ignore if offline or no .apk file hosted
    }
  }
  return null;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] =
    useState<BeforeInstallPromptEvent | null>(() => earlyDeferredPrompt);
  const [isInstalled, setIsInstalled] = useState<boolean>(() =>
    detectStandaloneOrInstalledWebView()
  );
  const [verifiedApkUrl, setVerifiedApkUrl] = useState<string | null>(null);

  const ua =
    typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase() : '';
  const isIOS = /iphone|ipad|ipod/.test(ua);
  const isAndroid = /android/.test(ua);

  const isInIframe = (() => {
    try {
      return typeof window !== 'undefined' && window.self !== window.top;
    } catch {
      return true;
    }
  })();

  useEffect(() => {
    setIsInstalled(detectStandaloneOrInstalledWebView());

    const syncPrompt = (ev: BeforeInstallPromptEvent | null) => {
      setDeferredPrompt(ev);
    };
    promptListeners.add(syncPrompt);

    const handleInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener('appinstalled', handleInstalled);

    let mql: MediaQueryList | null = null;
    const onDisplayModeChange = (e: MediaQueryListEvent) => {
      if (e.matches) setIsInstalled(true);
    };
    if (typeof window.matchMedia === 'function') {
      mql = window.matchMedia('(display-mode: standalone)');
      mql.addEventListener?.('change', onDisplayModeChange);
    }

    let cancelled = false;
    probeRealHostedApkUrl().then((apkUrl) => {
      if (!cancelled && apkUrl) {
        setVerifiedApkUrl(apkUrl);
      }
    });

    return () => {
      cancelled = true;
      promptListeners.delete(syncPrompt);
      window.removeEventListener('appinstalled', handleInstalled);
      mql?.removeEventListener?.('change', onDisplayModeChange);
    };
  }, []);

  const triggerNativeInstall = useCallback(async (): Promise<
    'installed' | 'dismissed' | 'apk-download' | 'unavailable'
  > => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        if (choice.outcome === 'accepted') {
          earlyDeferredPrompt = null;
          setDeferredPrompt(null);
          setIsInstalled(true);
          return 'installed';
        }
        return 'dismissed';
      } catch {
        return 'unavailable';
      }
    }

    if (verifiedApkUrl) {
      const a = document.createElement('a');
      a.href = verifiedApkUrl;
      a.download = 'song-merger.apk';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      return 'apk-download';
    }

    return 'unavailable';
  }, [deferredPrompt, verifiedApkUrl]);

  return {
    canDirectInstall: Boolean(deferredPrompt || verifiedApkUrl),
    hasNativePrompt: Boolean(deferredPrompt),
    verifiedApkUrl,
    isInstalled,
    isIOS,
    isAndroid,
    isInIframe,
    triggerNativeInstall,
  };
}
