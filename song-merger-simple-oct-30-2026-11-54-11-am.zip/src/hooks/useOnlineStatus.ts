import { useCallback, useEffect, useState } from 'react';

/**
 * Performs a real external network probe (not cached by service worker)
 * to confirm genuine internet reachability for YouTube oEmbed / player.
 */
export async function probeRealInternet(timeoutMs = 3800): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return false;
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const probeUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(
      'https://www.youtube.com/watch?v=jNQXAC9IVRw'
    )}&format=json&_t=${Date.now()}`;
    const res = await fetch(probeUrl, {
      method: 'GET',
      cache: 'no-store',
      signal: controller.signal,
    });
    if (res.ok) return true;
  } catch {
    // Try secondary public endpoint in case youtube.com oEmbed CORS was temporarily blocked
  }

  try {
    const fallbackUrl = `https://noembed.com/embed?url=${encodeURIComponent(
      'https://www.youtube.com/watch?v=jNQXAC9IVRw'
    )}&_t=${Date.now()}`;
    const res2 = await fetch(fallbackUrl, {
      method: 'GET',
      cache: 'no-store',
      signal: controller.signal,
    });
    return res2.ok;
  } catch {
    return false;
  } finally {
    window.clearTimeout(timer);
  }
}

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine !== false : true
  );
  const [isChecking, setIsChecking] = useState<boolean>(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const recheckInternet = useCallback(async (): Promise<boolean> => {
    setIsChecking(true);
    try {
      const ok = await probeRealInternet();
      setIsOnline(ok);
      return ok;
    } finally {
      setIsChecking(false);
    }
  }, []);

  const markOffline = useCallback(() => {
    setIsOnline(false);
  }, []);

  return {
    isOnline,
    isChecking,
    recheckInternet,
    markOffline,
  };
}
