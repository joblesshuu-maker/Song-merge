import { useCallback, useEffect, useRef, useState } from 'react';

export type PlayerSlotId = 'song1' | 'song2' | 'mix';

interface ActivePlaybackRef {
  id: PlayerSlotId;
  source: AudioBufferSourceNode;
  buffer: AudioBuffer;
  startedAtCtxTime: number;
  startOffsetSec: number;
}

interface ActiveLoopRef {
  source: AudioBufferSourceNode;
  gainNode: GainNode;
  buffer: AudioBuffer;
  startedAtCtxTime: number;
}

export function useAudioPlayback() {
  const ctxRef = useRef<AudioContext | null>(null);
  const activeRef = useRef<ActivePlaybackRef | null>(null);
  const activeLoopRef = useRef<ActiveLoopRef | null>(null);
  const rafRef = useRef<number | null>(null);
  const loopRafRef = useRef<number | null>(null);
  const pausedOffsetsRef = useRef<Record<PlayerSlotId, number>>({
    song1: 0,
    song2: 0,
    mix: 0,
  });

  const [playingId, setPlayingId] = useState<PlayerSlotId | null>(null);
  const [positions, setPositions] = useState<Record<PlayerSlotId, number>>({
    song1: 0,
    song2: 0,
    mix: 0,
  });

  const [isLoopPlaying, setIsLoopPlaying] = useState<boolean>(false);
  const [loopPosition, setLoopPosition] = useState<number>(0);
  const [loopDuration, setLoopDuration] = useState<number>(0);

  const ensureContext = useCallback(async () => {
    if (!ctxRef.current || ctxRef.current.state === 'closed') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctxRef.current = new AudioCtx();
    }
    if (ctxRef.current.state === 'suspended') {
      await ctxRef.current.resume();
    }
    return ctxRef.current;
  }, []);

  const unlockAudio = useCallback(() => {
    ensureContext().catch(() => {});
  }, [ensureContext]);

  const stopRaf = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, []);

  const stopLoopRaf = useCallback(() => {
    if (loopRafRef.current !== null) {
      cancelAnimationFrame(loopRafRef.current);
      loopRafRef.current = null;
    }
  }, []);

  const stopOverlapLoop = useCallback(() => {
    stopLoopRaf();
    const loopObj = activeLoopRef.current;
    if (loopObj) {
      try {
        loopObj.source.stop();
      } catch {
        // Ignore
      }
      try {
        loopObj.source.disconnect();
        loopObj.gainNode.disconnect();
      } catch {
        // Ignore
      }
      activeLoopRef.current = null;
    }
    setIsLoopPlaying(false);
    setLoopPosition(0);
  }, [stopLoopRaf]);

  const stopCurrentInternal = useCallback(
    (saveOffset: boolean) => {
      stopRaf();
      const active = activeRef.current;
      if (!active) {
        setPlayingId(null);
        return;
      }

      const ctx = ctxRef.current;
      if (saveOffset && ctx) {
        const elapsed = Math.max(0, ctx.currentTime - active.startedAtCtxTime);
        const nextPos = Math.min(active.buffer.duration, active.startOffsetSec + elapsed);
        pausedOffsetsRef.current[active.id] =
          nextPos >= active.buffer.duration - 0.05 ? 0 : nextPos;
        setPositions((prev) => ({
          ...prev,
          [active.id]: pausedOffsetsRef.current[active.id],
        }));
      }

      active.source.onended = null;
      try {
        active.source.stop();
      } catch {
        // Already stopped
      }
      try {
        active.source.disconnect();
      } catch {
        // Ignore
      }

      activeRef.current = null;
      setPlayingId(null);
    },
    [stopRaf]
  );

  /**
   * Returns exact instantaneous playback position for a slot (sub-millisecond accurate while playing).
   */
  const getLivePosition = useCallback((id: PlayerSlotId): number => {
    const active = activeRef.current;
    const ctx = ctxRef.current;
    if (active && active.id === id && ctx) {
      const elapsed = Math.max(0, ctx.currentTime - active.startedAtCtxTime);
      return Math.min(active.buffer.duration, active.startOffsetSec + elapsed);
    }
    return pausedOffsetsRef.current[id] || 0;
  }, []);

  const startLoop = useCallback(() => {
    stopRaf();
    const tick = () => {
      const active = activeRef.current;
      const ctx = ctxRef.current;
      if (!active || !ctx) return;

      const elapsed = Math.max(0, ctx.currentTime - active.startedAtCtxTime);
      const pos = Math.min(active.buffer.duration, active.startOffsetSec + elapsed);
      setPositions((prev) => ({
        ...prev,
        [active.id]: pos,
      }));

      if (pos < active.buffer.duration) {
        rafRef.current = requestAnimationFrame(tick);
      }
    };
    rafRef.current = requestAnimationFrame(tick);
  }, [stopRaf]);

  const startOverlapLoopRaf = useCallback(() => {
    stopLoopRaf();
    const tick = () => {
      const loopObj = activeLoopRef.current;
      const ctx = ctxRef.current;
      if (!loopObj || !ctx) return;

      const dur = Math.max(0.01, loopObj.buffer.duration);
      const elapsed = Math.max(0, ctx.currentTime - loopObj.startedAtCtxTime);
      setLoopPosition(elapsed % dur);
      loopRafRef.current = requestAnimationFrame(tick);
    };
    loopRafRef.current = requestAnimationFrame(tick);
  }, [stopLoopRaf]);

  const playFromOffset = useCallback(
    async (id: PlayerSlotId, buffer: AudioBuffer, offsetSec: number) => {
      stopOverlapLoop();
      stopCurrentInternal(true);
      const ctx = await ensureContext();

      const clampedOffset = Math.max(0, Math.min(buffer.duration - 0.05, offsetSec));
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);

      const playbackObj: ActivePlaybackRef = {
        id,
        source,
        buffer,
        startedAtCtxTime: ctx.currentTime,
        startOffsetSec: clampedOffset,
      };

      source.onended = () => {
        if (activeRef.current === playbackObj) {
          stopRaf();
          activeRef.current = null;
          pausedOffsetsRef.current[id] = 0;
          setPositions((prev) => ({ ...prev, [id]: 0 }));
          setPlayingId(null);
        }
      };

      activeRef.current = playbackObj;
      pausedOffsetsRef.current[id] = clampedOffset;
      setPositions((prev) => ({ ...prev, [id]: clampedOffset }));
      setPlayingId(id);

      source.start(0, clampedOffset);
      startLoop();
    },
    [ensureContext, startLoop, stopCurrentInternal, stopOverlapLoop, stopRaf]
  );

  /**
   * Starts or seamlessly hot-swaps the Overlap Loop buffer without stopping playback.
   * When already looping, performs a 35ms crossfade into the updated buffer so slider
   * changes feel completely continuous with zero audio gap.
   */
  const playOverlapLoop = useCallback(
    async (buffer: AudioBuffer) => {
      stopCurrentInternal(true);
      const ctx = await ensureContext();
      const now = ctx.currentTime;

      const prevLoop = activeLoopRef.current;

      const newSource = ctx.createBufferSource();
      newSource.buffer = buffer;
      newSource.loop = true;
      newSource.loopStart = 0;
      newSource.loopEnd = buffer.duration;

      const newGain = ctx.createGain();
      newSource.connect(newGain);
      newGain.connect(ctx.destination);

      if (prevLoop) {
        // Seamless 35ms crossfade swap from previous loop into updated settings loop
        newGain.gain.setValueAtTime(0, now);
        newGain.gain.linearRampToValueAtTime(1, now + 0.035);

        try {
          prevLoop.gainNode.gain.cancelScheduledValues(now);
          prevLoop.gainNode.gain.setValueAtTime(prevLoop.gainNode.gain.value, now);
          prevLoop.gainNode.gain.linearRampToValueAtTime(0, now + 0.035);
          prevLoop.source.stop(now + 0.045);
          window.setTimeout(() => {
            try {
              prevLoop.source.disconnect();
              prevLoop.gainNode.disconnect();
            } catch {
              // Ignore
            }
          }, 80);
        } catch {
          try {
            prevLoop.source.stop();
          } catch {
            // Ignore
          }
        }
      } else {
        newGain.gain.setValueAtTime(0, now);
        newGain.gain.linearRampToValueAtTime(1, now + 0.015);
      }

      const nextLoopObj: ActiveLoopRef = {
        source: newSource,
        gainNode: newGain,
        buffer,
        startedAtCtxTime: now,
      };

      activeLoopRef.current = nextLoopObj;
      setLoopDuration(buffer.duration);
      setLoopPosition(0);
      setIsLoopPlaying(true);

      newSource.start(now, 0);
      startOverlapLoopRaf();
    },
    [ensureContext, startOverlapLoopRaf, stopCurrentInternal]
  );

  const togglePlay = useCallback(
    async (
      id: PlayerSlotId,
      buffer: AudioBuffer | null,
      defaultStartSec = 0
    ) => {
      if (!buffer) return;
      if (activeRef.current?.id === id) {
        stopCurrentInternal(true);
        return;
      }
      const savedOffset = pausedOffsetsRef.current[id] || 0;
      const startFrom =
        savedOffset > 0.05 && savedOffset < buffer.duration - 0.1
          ? savedOffset
          : Math.max(0, Math.min(buffer.duration - 0.1, defaultStartSec));
      await playFromOffset(id, buffer, startFrom);
    },
    [playFromOffset, stopCurrentInternal]
  );

  const seek = useCallback(
    async (id: PlayerSlotId, buffer: AudioBuffer | null, newTimeSec: number) => {
      if (!buffer) return;
      const clamped = Math.max(0, Math.min(buffer.duration, newTimeSec));
      pausedOffsetsRef.current[id] = clamped;
      setPositions((prev) => ({ ...prev, [id]: clamped }));

      if (activeRef.current?.id === id) {
        await playFromOffset(id, buffer, clamped);
      }
    },
    [playFromOffset]
  );

  const resetSlot = useCallback(
    (id: PlayerSlotId) => {
      if (activeRef.current?.id === id) {
        stopCurrentInternal(false);
      }
      pausedOffsetsRef.current[id] = 0;
      setPositions((prev) => ({ ...prev, [id]: 0 }));
    },
    [stopCurrentInternal]
  );

  const stopAll = useCallback(() => {
    stopCurrentInternal(true);
    stopOverlapLoop();
  }, [stopCurrentInternal, stopOverlapLoop]);

  const stopNonLoopPlayers = useCallback(() => {
    stopCurrentInternal(true);
  }, [stopCurrentInternal]);

  useEffect(() => {
    return () => {
      stopRaf();
      stopLoopRaf();
      if (activeRef.current) {
        try {
          activeRef.current.source.stop();
        } catch {
          // Ignore
        }
      }
      if (activeLoopRef.current) {
        try {
          activeLoopRef.current.source.stop();
        } catch {
          // Ignore
        }
      }
      if (ctxRef.current && ctxRef.current.state !== 'closed') {
        ctxRef.current.close().catch(() => {});
      }
    };
  }, [stopLoopRaf, stopRaf]);

  return {
    playingId,
    positions,
    isLoopPlaying,
    loopPosition,
    loopDuration,
    unlockAudio,
    getLivePosition,
    togglePlay,
    seek,
    playFromOffset,
    playOverlapLoop,
    stopOverlapLoop,
    stopNonLoopPlayers,
    resetSlot,
    stopAll,
  };
}
