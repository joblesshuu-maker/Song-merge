import React from 'react';
import {
  AlertCircle,
  Check,
  Download,
  Headphones,
  Loader2,
  Pause,
  Play,
  Repeat,
  RotateCcw,
  Share2,
  Sliders,
  Square,
} from 'lucide-react';
import { MergePhase, MixRenderSummary } from '../types/audio';
import { SaveAudioResult } from '../utils/downloadHelper';
import { formatDuration, formatFileSize } from '../utils/formatters';

interface MixOutputCardProps {
  canMerge: boolean;
  webAudioSupported?: boolean;
  audioLibsReady?: boolean;
  isCheckingLibs?: boolean;
  onRetryLoadLibraries?: () => void;
  missingFilesReason: string | null;
  phase: MergePhase;
  dspStageText: string;
  dspPercent: number;
  mp3Percent: number;
  showLongEncodeHint: boolean;
  errorMessage: string | null;
  previewBuffer: AudioBuffer | null;
  summary: MixRenderSummary | null;
  isStaleMix: boolean;
  isPlayingMix: boolean;
  mixCurrentTimeSec: number;
  // Overlap Loop props
  isLoopPlaying: boolean;
  isLoopRendering: boolean;
  loopErrorMessage?: string | null;
  loopPositionSec: number;
  loopDurationSec: number;
  loopXfadeStartSec: number;
  loopXfadeEndSec: number;
  onStartOverlapLoop: () => void;
  onStopOverlapLoop: () => void;
  // Full Merge & Export props
  onMergeClick: () => void;
  onToggleMixPlay: () => void;
  onSeekMix: (timeSec: number) => void;
  onJumpToJoin: () => void;
  onDownloadClick: () => void;
  canShareExportFile?: boolean;
  onShareFileClick?: () => void;
  downloadStatus?: SaveAudioResult | null;
}

export const MixOutputCard: React.FC<MixOutputCardProps> = ({
  canMerge,
  webAudioSupported = true,
  audioLibsReady = true,
  isCheckingLibs = false,
  onRetryLoadLibraries,
  missingFilesReason,
  phase,
  dspStageText,
  dspPercent,
  mp3Percent,
  showLongEncodeHint,
  errorMessage,
  previewBuffer,
  summary,
  isStaleMix,
  isPlayingMix,
  mixCurrentTimeSec,
  isLoopPlaying,
  isLoopRendering,
  loopErrorMessage,
  loopPositionSec,
  loopDurationSec,
  loopXfadeStartSec,
  loopXfadeEndSec,
  onStartOverlapLoop,
  onStopOverlapLoop,
  onMergeClick,
  onToggleMixPlay,
  onSeekMix,
  onJumpToJoin,
  onDownloadClick,
  canShareExportFile = false,
  onShareFileClick,
  downloadStatus,
}) => {
  const isBusy =
    phase === 'mixing' || phase === 'mastering' || phase === 'encoding';

  const mixDuration = previewBuffer?.duration || summary?.finalDurationSec || 0;
  const playProgressPct =
    mixDuration > 0
      ? Math.min(100, Math.max(0, (mixCurrentTimeSec / mixDuration) * 100))
      : 0;

  const joinLeftPct =
    summary && mixDuration > 0
      ? Math.max(
          0,
          Math.min(100, (summary.transitionStartSec / mixDuration) * 100)
        )
      : 0;
  const joinWidthPct =
    summary && mixDuration > 0
      ? Math.max(
          1.5,
          Math.min(
            100 - joinLeftPct,
            ((summary.transitionEndSec - summary.transitionStartSec) /
              mixDuration) *
              100
          )
        )
      : 0;

  const loopProgressPct =
    loopDurationSec > 0
      ? Math.min(100, Math.max(0, (loopPositionSec / loopDurationSec) * 100))
      : 0;
  const loopXfadeLeftPct =
    loopDurationSec > 0
      ? Math.max(0, Math.min(100, (loopXfadeStartSec / loopDurationSec) * 100))
      : 0;
  const loopXfadeWidthPct =
    loopDurationSec > 0
      ? Math.max(
          2,
          Math.min(
            100 - loopXfadeLeftPct,
            ((loopXfadeEndSec - loopXfadeStartSec) / loopDurationSec) * 100
          )
        )
      : 0;

  if (!webAudioSupported) {
    return (
      <section className="bg-[#111111] rounded-2xl border border-[#2A2A2A] p-5 sm:p-6 space-y-3">
        <h2 className="text-base sm:text-lg font-semibold text-white tracking-tight">
          04. Merge & Export
        </h2>
        <div
          role="alert"
          className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3.5 py-3 text-xs text-[#E0E0E0] space-y-1"
        >
          <p className="font-semibold text-white">
            Merge controls chhupa diye gaye hain kyunki Web Audio uplabdh nahi hai
          </p>
          <p className="text-[#AAAAAA] leading-relaxed">
            Play Store se Android System WebView ya Chrome browser update karke app dobara kholo.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-[#111111] rounded-2xl border border-[#2A2A2A] p-5 sm:p-6 space-y-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-base sm:text-lg font-semibold text-white tracking-tight">
          04. Merge & Export
        </h2>
        <span className="text-xs text-[#AAAAAA] font-mono tabular-nums">
          320 kbps · 44.1 kHz
        </span>
      </div>

      {/* Audio Libraries Gate: if SoundTouch/lamejs failed to load, wait plainly + Retry */}
      {!audioLibsReady ? (
        <div
          role="alert"
          className="rounded-xl border border-amber-500/45 bg-[#1A1A1A] px-3.5 py-3 text-xs text-[#E0E0E0] space-y-2.5"
        >
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-white">
                Merge aur MP3 export ke liye audio library abhi load nahi hui
              </p>
              <p className="text-[#AAAAAA] leading-relaxed">
                Upar Song 1 aur Song 2 ka file import aur preview kaam kar raha hai. Merge karne ke liye internet check karke Retry dabao.
              </p>
            </div>
          </div>
          {onRetryLoadLibraries && (
            <button
              type="button"
              disabled={isCheckingLibs}
              onClick={onRetryLoadLibraries}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] disabled:opacity-50 font-semibold text-xs inline-flex items-center gap-1.5"
            >
              {isCheckingLibs ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
              ) : (
                <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              )}
              <span>Retry</span>
            </button>
          )}
        </div>
      ) : (
        <>
          {/* Overlap Loop Preview Controls */}
          <div className="rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] p-3.5 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white">
                  Merge Region Preview (-3s se +3s)
                </p>
                <p className="text-[11px] text-[#AAAAAA] truncate mt-0.5">
                  {isLoopRendering
                    ? 'Nayi settings ke saath loop update ho raha hai...'
                    : isLoopPlaying
                      ? 'Seamless overlap loop chal raha hai'
                      : 'Sliders chhodte hi ya Overlap Loop dabane par join suno'}
                </p>
              </div>
              {isLoopRendering && (
                <Loader2 className="w-4 h-4 text-white animate-spin shrink-0" />
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={!canMerge || isBusy}
                onClick={onStartOverlapLoop}
                className={`flex-1 min-h-[44px] px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap shrink-0 inline-flex items-center justify-center gap-2 bg-[#222222] text-white border ${
                  isLoopPlaying
                    ? 'border-white'
                    : 'border-[#333333] hover:bg-[#2C2C2C] disabled:opacity-45 disabled:cursor-not-allowed'
                }`}
              >
                <Repeat className="w-4 h-4 shrink-0" />
                <span>Overlap Loop</span>
              </button>

              {(isLoopPlaying || isLoopRendering) && (
                <button
                  type="button"
                  onClick={onStopOverlapLoop}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] text-sm font-semibold transition-colors whitespace-nowrap shrink-0 inline-flex items-center justify-center gap-1.5"
                >
                  <Square className="w-3.5 h-3.5 fill-current shrink-0" />
                  <span>Stop</span>
                </button>
              )}
            </div>

            {loopErrorMessage && (
              <div
                role="alert"
                className="rounded-lg border border-red-500/45 bg-[#111111] px-3 py-2 text-xs text-red-300 flex items-center justify-between gap-2"
              >
                <span className="inline-flex items-start gap-1.5 min-w-0">
                  <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                  <span>{loopErrorMessage}</span>
                </span>
                <button
                  type="button"
                  disabled={!canMerge || isBusy}
                  onClick={onStartOverlapLoop}
                  className="min-h-[32px] px-2.5 py-1 rounded-md bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] whitespace-nowrap shrink-0 inline-flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Retry</span>
                </button>
              </div>
            )}

            {isLoopPlaying && loopDurationSec > 0 && (
              <div className="pt-1 space-y-1">
                <div className="relative w-full h-2 bg-[#333333] rounded-full overflow-hidden">
                  <div
                    title="Crossfade overlap zone"
                    className="absolute top-0 bottom-0 bg-white/25"
                    style={{
                      left: `${loopXfadeLeftPct}%`,
                      width: `${loopXfadeWidthPct}%`,
                    }}
                  />
                  <div
                    className="relative h-full bg-white transition-none"
                    style={{ width: `${loopProgressPct}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#AAAAAA] font-mono tabular-nums">
                  <span>{formatDuration(loopPositionSec)}</span>
                  <span className="font-sans">Crossfade overlap loop</span>
                  <span>{formatDuration(loopDurationSec)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Primary Big CTA: Merge karo — White background with black bold text */}
          <button
            type="button"
            disabled={!canMerge || isBusy}
            onClick={onMergeClick}
            className="w-full min-h-[52px] px-5 py-3.5 rounded-xl bg-white text-black hover:bg-[#E8E8E8] active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed transition-all font-bold text-base flex items-center justify-center gap-2.5 whitespace-nowrap"
          >
            {isBusy ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin shrink-0" />
                <span>
                  {phase === 'encoding'
                    ? `MP3 ban raha hai... ${mp3Percent}%`
                    : `Mix ban raha hai... ${dspPercent}%`}
                </span>
              </>
            ) : (
              <>
                <Sliders className="w-5 h-5 shrink-0" />
                <span>
                  {previewBuffer && isStaleMix
                    ? 'Naya Mix Merge karo'
                    : 'Merge karo'}
                </span>
              </>
            )}
          </button>
        </>
      )}

      {/* Helper message when files aren't both chosen yet */}
      {!canMerge && missingFilesReason && (
        <p className="text-xs text-[#AAAAAA] text-center leading-relaxed">
          {missingFilesReason}
        </p>
      )}

      {/* Real-time Non-Blocking Encoding / Rendering Progress */}
      {isBusy && (
        <div className="rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] p-3.5 space-y-2">
          <div className="flex items-center justify-between text-xs font-medium text-white">
            <span className="truncate pr-2">
              {phase === 'encoding'
                ? `MP3 ban raha hai... ${mp3Percent}%`
                : dspStageText || 'Mix taiyaar ho raha hai...'}
            </span>
            <span className="font-mono tabular-nums font-semibold shrink-0">
              {phase === 'encoding' ? `${mp3Percent}%` : `${dspPercent}%`}
            </span>
          </div>
          <div className="w-full h-2 bg-[#333333] rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-transform duration-150 origin-left"
              style={{
                transform: `scaleX(${
                  (phase === 'encoding' ? mp3Percent : dspPercent) / 100
                })`,
              }}
            />
          </div>
          {phase === 'encoding' && showLongEncodeHint && (
            <p className="text-xs text-[#AAAAAA] leading-relaxed pt-0.5">
              MP3 ban raha hai, thoda waqt lagega — app ko khula rakho.
            </p>
          )}
        </div>
      )}

      {/* Stale full-export notice */}
      {previewBuffer && isStaleMix && !isBusy && (
        <div className="rounded-xl border border-amber-500/45 bg-[#1A1A1A] px-3.5 py-2.5 text-xs text-[#E0E0E0]">
          Settings ya trim badle gaye hain — poora track export karne ke liye{' '}
          <strong className="font-semibold text-white">Naya Mix Merge karo</strong> dabayein.
        </div>
      )}

      {/* Merge / Encode Error State + Explicit Retry */}
      {errorMessage && (
        <div
          role="alert"
          className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3.5 py-3 text-xs text-red-300 space-y-2"
        >
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
          {canMerge && !isBusy && (
            <button
              type="button"
              onClick={onMergeClick}
              className="min-h-[36px] px-3 py-1.5 rounded-lg bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] font-semibold text-xs inline-flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              <span>Retry</span>
            </button>
          )}
        </div>
      )}

      {/* Full Mixed Preview Player (plays exact rendered AudioBuffer!) */}
      {previewBuffer && (
        <div className="pt-2 border-t border-[#2A2A2A] space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-white inline-flex items-center gap-1.5">
              <Headphones className="w-3.5 h-3.5 text-[#AAAAAA]" />
              <span>Full Mixed Preview (exact output)</span>
            </span>
            {summary && !isStaleMix && (
              <button
                type="button"
                onClick={onJumpToJoin}
                className="min-h-[36px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#333333] text-xs font-semibold text-white hover:bg-[#2C2C2C] whitespace-nowrap shrink-0"
              >
                Transition suno
              </button>
            )}
          </div>

          <div className="flex items-center gap-3.5">
            <button
              type="button"
              onClick={onToggleMixPlay}
              disabled={isBusy && !previewBuffer}
              aria-label={
                isPlayingMix ? 'Pause mixed preview' : 'Play mixed preview'
              }
              className="min-h-[48px] min-w-[48px] w-12 h-12 rounded-xl bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] transition-colors flex items-center justify-center shrink-0"
            >
              {isPlayingMix ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-0.5" />
              )}
            </button>

            <div className="flex-1 min-w-0">
              <div className="relative flex items-center">
                <div className="relative w-full h-2 bg-[#333333] rounded-full overflow-hidden pointer-events-none">
                  {summary && !isStaleMix && joinWidthPct > 0 && (
                    <div
                      title="Crossfade transition zone"
                      className="absolute top-0 bottom-0 bg-white/25"
                      style={{
                        left: `${joinLeftPct}%`,
                        width: `${joinWidthPct}%`,
                      }}
                    />
                  )}
                  <div
                    className="relative h-full bg-white"
                    style={{ width: `${playProgressPct}%` }}
                  />
                </div>
                <input
                  type="range"
                  min={0}
                  max={mixDuration || 1}
                  step={0.1}
                  value={Math.min(mixCurrentTimeSec, mixDuration)}
                  onChange={(e) => onSeekMix(parseFloat(e.target.value))}
                  aria-label="Seek mixed preview"
                  className="scrub-slider absolute inset-0 w-full"
                />
              </div>

              <div className="flex items-center justify-between text-xs text-[#AAAAAA] font-mono tabular-nums mt-1">
                <span>{formatDuration(mixCurrentTimeSec)}</span>
                {summary && !isStaleMix && (
                  <span className="font-sans text-[11px] text-[#AAAAAA] truncate px-2">
                    Join @ {formatDuration(summary.transitionStartSec)}
                  </span>
                )}
                <span>{formatDuration(mixDuration)}</span>
              </div>
            </div>
          </div>

          {/* Unboxed clean mix metadata */}
          {summary && !isStaleMix && (
            <div className="text-xs text-[#AAAAAA] flex flex-wrap items-center gap-x-2 gap-y-1 pt-0.5">
              <span>{formatDuration(summary.finalDurationSec)} total</span>
              <span aria-hidden="true">·</span>
              <span>{formatFileSize(summary.fileSizeBytes)}</span>
              <span aria-hidden="true">·</span>
              <span>
                {summary.format === 'mp3' ? 'MP3 320 kbps' : 'WAV 16-bit'}
              </span>
              {summary.autoMatchApplied && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>
                    Auto-matched ({summary.song2MatchedTempoRatio.toFixed(2)}x)
                  </span>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Plain WAV fallback notice if MP3 encoder ever failed to load */}
      {phase === 'ready' && summary?.wavFallbackUsed && !isStaleMix && (
        <div className="rounded-xl border border-amber-500/45 bg-[#1A1A1A] px-3.5 py-2.5 text-xs text-[#E0E0E0]">
          MP3 encoder load nahi hua, WAV download diya gaya hai.
        </div>
      )}

      {/* Primary Big Download Button (White bg, black bold text) + Secondary Share + Honest Status/Retry */}
      {phase === 'ready' && summary && !isStaleMix && (
        <div className="space-y-2.5">
          <button
            type="button"
            onClick={onDownloadClick}
            className="w-full min-h-[52px] px-5 py-3.5 rounded-xl bg-white text-black hover:bg-[#E8E8E8] active:scale-[0.99] transition-all font-bold text-base flex items-center justify-center gap-2.5 whitespace-nowrap"
          >
            <Download className="w-5 h-5 shrink-0" />
            <span>
              Download ({summary.format === 'mp3' ? 'MP3' : 'WAV'} ·{' '}
              {formatFileSize(summary.fileSizeBytes)})
            </span>
          </button>

          {canShareExportFile && onShareFileClick && (
            <button
              type="button"
              onClick={onShareFileClick}
              className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#222222] text-white hover:bg-[#2C2C2C] border border-[#333333] text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors"
            >
              <Share2 className="w-4 h-4 shrink-0" />
              <span>Phone me Save / Share karo</span>
            </button>
          )}

          {downloadStatus && (
            <div
              role={downloadStatus.ok ? 'status' : 'alert'}
              className={`rounded-xl border bg-[#1A1A1A] px-3.5 py-2.5 text-xs flex items-center justify-between gap-2 ${
                downloadStatus.ok
                  ? 'border-emerald-500/45 text-[#E0E0E0]'
                  : 'border-red-500/45 text-red-300'
              }`}
            >
              <span className="inline-flex items-start gap-2 min-w-0">
                {downloadStatus.ok ? (
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                )}
                <span>{downloadStatus.message}</span>
              </span>

              {!downloadStatus.ok && (
                <button
                  type="button"
                  onClick={onDownloadClick}
                  className="min-h-[34px] px-3 py-1 rounded-lg bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] whitespace-nowrap shrink-0 inline-flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3 shrink-0" />
                  <span>Retry</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
};
