import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  FileAudio,
  Loader2,
  Music2,
  Pause,
  Play,
  RotateCcw,
  Scissors,
  Search,
  Upload,
  WifiOff,
  X,
} from 'lucide-react';
import { SongSlotState } from '../types/audio';
import {
  formatDuration,
  parseMmSsToSeconds,
  stripFileExtension,
} from '../utils/formatters';
import { extractYouTubeVideoId } from '../utils/youtubeInfo';

interface SongSlotCardProps {
  slotNumber: 1 | 2;
  slotState: SongSlotState;
  isOnline: boolean;
  isCheckingInternet?: boolean;
  webAudioSupported?: boolean;
  filePickerSupported?: boolean;
  isPlaying: boolean;
  currentTimeSec: number;
  getLiveSlotPosition: () => number;
  onYtUrlChange: (url: string) => void;
  onFetchYtInfo: () => void;
  onClearYtInfo: () => void;
  onRecheckInternet: () => void;
  onSelectFile: (file: File) => void;
  onFilePermissionError: () => void;
  onTrimChange: (
    newStartSec: number,
    newEndSec: number,
    preserveSlotPlayback?: boolean
  ) => void;
  onTogglePreview: () => void;
  onSeekPreview: (timeSec: number) => void;
}

const TRIM_ORDER_ERROR_MSG = 'End time, Start time ke baad hona chahiye';

export const SongSlotCard: React.FC<SongSlotCardProps> = ({
  slotNumber,
  slotState,
  isOnline,
  isCheckingInternet = false,
  webAudioSupported = true,
  filePickerSupported = true,
  isPlaying,
  currentTimeSec,
  getLiveSlotPosition,
  onYtUrlChange,
  onFetchYtInfo,
  onClearYtInfo,
  onRecheckInternet,
  onSelectFile,
  onFilePermissionError,
  onTrimChange,
  onTogglePreview,
  onSeekPreview,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [thumbError, setThumbError] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [trimValidationError, setTrimValidationError] = useState<string | null>(
    null
  );
  const [showPickerReason, setShowPickerReason] = useState(false);
  const [ytEmbedRetryKey, setYtEmbedRetryKey] = useState(0);

  const [startInput, setStartInput] = useState(() =>
    formatDuration(slotState.trimStartSec)
  );
  const [endInput, setEndInput] = useState(() =>
    formatDuration(slotState.trimEndSec)
  );

  useEffect(() => {
    setStartInput(formatDuration(slotState.trimStartSec));
  }, [slotState.trimStartSec, slotState.fullDurationSec]);

  useEffect(() => {
    setEndInput(formatDuration(slotState.trimEndSec));
  }, [slotState.trimEndSec, slotState.fullDurationSec]);

  useEffect(() => {
    setTrimValidationError(null);
    if (slotState.audioBuffer) {
      setShowPickerReason(false);
    }
  }, [slotState.file, slotState.audioBuffer]);

  const videoId = extractYouTubeVideoId(slotState.ytUrl);
  const hasLinkOrInfo = Boolean(slotState.ytUrl.trim() || slotState.ytInfo);
  const needsAudioImportWarning =
    hasLinkOrInfo && !slotState.audioBuffer && !slotState.fileLoading;

  const displaySongName =
    slotState.ytInfo?.title ||
    (slotState.fileName ? stripFileExtension(slotState.fileName) : null);

  const fullDur = slotState.fullDurationSec || 0;
  const minClipSec = Math.min(0.5, Math.max(0.1, fullDur * 0.25));
  const isTrimmed =
    Boolean(slotState.fullAudioBuffer) &&
    (slotState.trimStartSec > 0.05 || slotState.trimEndSec < fullDur - 0.05);

  const openSystemFilePicker = () => {
    // Plain-words reason shown ONLY when user taps "File chuno" (never at first launch)
    if (!slotState.audioBuffer) {
      setShowPickerReason(true);
    }
    try {
      if (!fileInputRef.current) {
        onFilePermissionError();
        return;
      }
      fileInputRef.current.click();
    } catch {
      onFilePermissionError();
    }
  };

  // Tap-to-set Start time at current live playback position
  const handleTapSetStartHere = () => {
    if (!slotState.fullAudioBuffer) return;
    const pos = Math.max(0, Math.min(fullDur, getLiveSlotPosition()));
    if (pos >= slotState.trimEndSec - 0.05) {
      setTrimValidationError(TRIM_ORDER_ERROR_MSG);
      return;
    }
    setTrimValidationError(null);
    setStartInput(formatDuration(pos));
    onTrimChange(pos, slotState.trimEndSec, true);
  };

  // Tap-to-set End time at current live playback position
  const handleTapSetEndHere = () => {
    if (!slotState.fullAudioBuffer) return;
    const pos = Math.max(0, Math.min(fullDur, getLiveSlotPosition()));
    if (pos <= slotState.trimStartSec + 0.05) {
      setTrimValidationError(TRIM_ORDER_ERROR_MSG);
      return;
    }
    setTrimValidationError(null);
    setEndInput(formatDuration(pos));
    onTrimChange(slotState.trimStartSec, pos, true);
  };

  const commitStartText = (rawText: string) => {
    if (!slotState.fullAudioBuffer) return;
    const parsed = parseMmSsToSeconds(rawText);
    if (parsed === null) {
      setStartInput(formatDuration(slotState.trimStartSec));
      return;
    }
    const clampedPos = Math.max(0, Math.min(fullDur, parsed));
    if (clampedPos >= slotState.trimEndSec - 0.05) {
      setTrimValidationError(TRIM_ORDER_ERROR_MSG);
      setStartInput(formatDuration(slotState.trimStartSec));
      return;
    }
    setTrimValidationError(null);
    setStartInput(formatDuration(clampedPos));
    if (Math.abs(clampedPos - slotState.trimStartSec) > 0.01) {
      onTrimChange(clampedPos, slotState.trimEndSec, false);
    }
  };

  const commitEndText = (rawText: string) => {
    if (!slotState.fullAudioBuffer) return;
    const parsed = parseMmSsToSeconds(rawText);
    if (parsed === null) {
      setEndInput(formatDuration(slotState.trimEndSec));
      return;
    }
    const clampedPos = Math.max(0, Math.min(fullDur, parsed));
    if (clampedPos <= slotState.trimStartSec + 0.05) {
      setTrimValidationError(TRIM_ORDER_ERROR_MSG);
      setEndInput(formatDuration(slotState.trimEndSec));
      return;
    }
    setTrimValidationError(null);
    setEndInput(formatDuration(clampedPos));
    if (Math.abs(clampedPos - slotState.trimEndSec) > 0.01) {
      onTrimChange(slotState.trimStartSec, clampedPos, false);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const chosen = e.target.files?.[0];
    if (chosen) {
      setShowPickerReason(false);
      onSelectFile(chosen);
    }
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) {
      setShowPickerReason(false);
      onSelectFile(dropped);
    }
  };

  const handleYtKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && slotState.ytUrl.trim() && !slotState.ytLoading) {
      e.preventDefault();
      setThumbError(false);
      onFetchYtInfo();
    }
  };

  const progressPct =
    fullDur > 0 ? Math.min(100, Math.max(0, (currentTimeSec / fullDur) * 100)) : 0;

  const trimStartPct =
    fullDur > 0
      ? Math.min(100, Math.max(0, (slotState.trimStartSec / fullDur) * 100))
      : 0;
  const trimWidthPct =
    fullDur > 0
      ? Math.max(
          0,
          Math.min(
            100 - trimStartPct,
            ((slotState.trimEndSec - slotState.trimStartSec) / fullDur) * 100
          )
        )
      : 100;

  return (
    <section
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      className={`bg-[#111111] rounded-2xl border transition-colors p-5 sm:p-6 ${
        isDragging ? 'border-white bg-[#1A1A1A]' : 'border-[#2A2A2A]'
      }`}
    >
      {/* Header row */}
      <div className="flex items-baseline justify-between gap-3 mb-4">
        <h2 className="text-base sm:text-lg font-semibold text-white tracking-tight">
          0{slotNumber}. Song {slotNumber}
        </h2>
        <div className="text-xs text-[#AAAAAA] font-mono tabular-nums truncate">
          {slotState.audioBuffer ? (
            <span className="inline-flex items-center gap-1.5 text-[#E0E0E0] font-medium">
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Ready</span>
              <span aria-hidden="true">·</span>
              <span>{formatDuration(slotState.durationSec)}</span>
              {slotState.analysis?.bpm ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{Math.round(slotState.analysis.bpm)} BPM</span>
                </>
              ) : null}
            </span>
          ) : (
            <span>MP3 · WAV · M4A</span>
          )}
        </div>
      </div>

      {/* Part A: YouTube link for song info + official listening-only embed */}
      <div className="space-y-2">
        <label
          htmlFor={`yt-link-${slotNumber}`}
          className="block text-xs font-medium text-[#AAAAAA]"
        >
          YouTube link (sirf song info aur sunne ke liye — optional)
        </label>
        <div className="flex items-center gap-2">
          <div className="relative flex-1 min-w-0">
            <input
              id={`yt-link-${slotNumber}`}
              type="url"
              value={slotState.ytUrl}
              onChange={(e) => {
                setThumbError(false);
                onYtUrlChange(e.target.value);
              }}
              onKeyDown={handleYtKeyDown}
              placeholder="https://youtu.be/... paste karo"
              className="w-full min-h-[44px] px-3.5 py-2 text-sm bg-[#1A1A1A] border border-[#333333] rounded-xl text-white placeholder:text-[#777777] focus:outline-none focus:ring-2 focus:ring-white/20 focus:border-white transition-colors pr-9"
            />
            {slotState.ytUrl && (
              <button
                type="button"
                onClick={() => {
                  setThumbError(false);
                  onClearYtInfo();
                }}
                aria-label="Clear YouTube link"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-[#AAAAAA] hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={() => {
              setThumbError(false);
              onFetchYtInfo();
            }}
            disabled={!slotState.ytUrl.trim() || slotState.ytLoading}
            className="min-h-[44px] px-4 py-2 text-sm font-semibold rounded-xl bg-[#222222] text-white border border-[#333333] hover:bg-[#2C2C2C] disabled:opacity-45 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-1.5"
          >
            {slotState.ytLoading ? (
              <Loader2 className="w-4 h-4 animate-spin shrink-0" />
            ) : (
              <Search className="w-4 h-4 shrink-0" />
            )}
            <span>Info lao</span>
          </button>
        </div>

        {/* Offline plain-words notice for YouTube info when internet is off */}
        {!isOnline && !slotState.ytError && slotState.ytUrl.trim() && (
          <div className="rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] px-3 py-2 text-xs text-[#E0E0E0] flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1.5">
              <WifiOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Internet nahi hai — YouTube info ke liye data/Wi-Fi on karo.</span>
            </span>
            <button
              type="button"
              disabled={isCheckingInternet}
              onClick={onRecheckInternet}
              className="min-h-[32px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] whitespace-nowrap shrink-0 inline-flex items-center gap-1"
            >
              {isCheckingInternet ? (
                <Loader2 className="w-3 h-3 animate-spin" />
              ) : (
                <RotateCcw className="w-3 h-3" />
              )}
              <span>Retry</span>
            </button>
          </div>
        )}

        {slotState.ytError && (
          <div
            role="alert"
            className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3 py-2 text-xs text-red-300 flex items-center justify-between gap-2"
          >
            <span className="inline-flex items-start gap-1.5 min-w-0">
              <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
              <span>{slotState.ytError}</span>
            </span>
            <button
              type="button"
              disabled={slotState.ytLoading}
              onClick={() => {
                setThumbError(false);
                onFetchYtInfo();
              }}
              className="min-h-[32px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] whitespace-nowrap shrink-0 inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          </div>
        )}
      </div>

      {/* Official YouTube iframe embed player (listening/preview only) — pure black background */}
      {videoId && (
        <div className="mt-3.5">
          {isOnline ? (
            <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-black border border-[#2A2A2A]">
              <iframe
                key={`${videoId}-${ytEmbedRetryKey}`}
                src={`https://www.youtube.com/embed/${videoId}?playsinline=1&rel=0`}
                title={`Song ${slotNumber} YouTube player`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
                className="w-full h-full border-0 bg-black"
              />
            </div>
          ) : (
            <div className="w-full rounded-xl bg-black border border-[#2A2A2A] px-4 py-5 flex flex-col items-center justify-center text-center space-y-2.5">
              <WifiOff className="w-5 h-5 text-[#AAAAAA]" />
              <div>
                <p className="text-sm font-semibold text-white">
                  Internet nahi hai
                </p>
                <p className="text-xs text-[#AAAAAA] mt-0.5 max-w-sm">
                  YouTube player chalane ke liye internet chahiye. Niche File chuno se offline gaana import aur merge abhi bhi kar sakte ho.
                </p>
              </div>
              <button
                type="button"
                disabled={isCheckingInternet}
                onClick={() => {
                  onRecheckInternet();
                  setYtEmbedRetryKey((k) => k + 1);
                }}
                className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] text-xs font-semibold inline-flex items-center gap-1.5"
              >
                {isCheckingInternet ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <RotateCcw className="w-3.5 h-3.5" />
                )}
                <span>Retry</span>
              </button>
            </div>
          )}
          <p className="text-xs text-[#AAAAAA] mt-1.5 leading-snug">
            Ye player sirf sunne ke liye hai — merge ke liye file import karo.
          </p>
        </div>
      )}

      {/* Fetched YouTube Info Preview */}
      {slotState.ytInfo && (
        <div className="mt-3 flex items-center gap-3 p-2.5 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A]">
          <div className="w-16 h-12 rounded-lg overflow-hidden bg-black border border-[#2A2A2A] shrink-0 flex items-center justify-center">
            {slotState.ytInfo.thumbnailUrl && !thumbError && isOnline ? (
              <img
                src={slotState.ytInfo.thumbnailUrl}
                alt={slotState.ytInfo.title}
                referrerPolicy="no-referrer"
                onError={() => setThumbError(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <Music2 className="w-5 h-5 text-[#AAAAAA]" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-white truncate">
              {slotState.ytInfo.title}
            </p>
            <p className="text-xs text-[#AAAAAA] truncate mt-0.5">
              {slotState.ytInfo.authorName}
              <span aria-hidden="true"> · </span>
              <span>Sirf info pehchaan ke liye</span>
            </p>
          </div>
        </div>
      )}

      {/* Honest YouTube Limit Warning when link exists without imported audio file */}
      {needsAudioImportWarning && (
        <div
          role="status"
          className="mt-3.5 rounded-xl border border-amber-500/45 bg-[#1A1A1A] px-3.5 py-2.5 text-[#E0E0E0]"
        >
          <p className="text-sm font-semibold text-white flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Merge ke liye audio file import karo</span>
          </p>
          <p className="text-xs text-[#AAAAAA] mt-1 leading-relaxed">
            YouTube se audio download nahi hota — link sirf naam aur photo dikhata hai. Niche{' '}
            <strong className="font-semibold text-white">File chuno</strong> dabakar apne phone/device se MP3, WAV, ya M4A chuno.
          </p>
        </div>
      )}

      {/* Hairline divider */}
      <div className="my-4 border-t border-[#2A2A2A]" />

      {/* Part B: Device Audio File Import + Preview Player (with Tap-to-Set Start/End) + Manual MM:SS Trim */}
      <div className="space-y-3.5">
        {!webAudioSupported ? (
          <div
            role="alert"
            className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3.5 py-3 text-xs text-[#E0E0E0] space-y-1"
          >
            <p className="font-semibold text-white">
              Is phone/WebView me Web Audio uplabdh nahi hai
            </p>
            <p className="text-[#AAAAAA] leading-relaxed">
              Audio import aur merge chalane ke liye Play Store se Android System WebView ya Chrome browser update karo.
            </p>
          </div>
        ) : !filePickerSupported ? (
          <div
            role="alert"
            className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3.5 py-3 text-xs text-[#E0E0E0] space-y-1"
          >
            <p className="font-semibold text-white">
              File chuno is WebView me uplabdh nahi hai
            </p>
            <p className="text-[#AAAAAA] leading-relaxed">
              Settings &gt; Apps &gt; Song Merger &gt; Permissions me file access allow karo ya Chrome browser me kholo.
            </p>
          </div>
        ) : (
          <>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
              onChange={handleFileInputChange}
              className="hidden"
            />

            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={openSystemFilePicker}
                disabled={slotState.fileLoading}
                className="min-h-[44px] px-4 py-2.5 rounded-xl text-sm font-semibold bg-[#222222] text-white border border-[#333333] hover:bg-[#2C2C2C] disabled:opacity-45 transition-colors whitespace-nowrap shrink-0 inline-flex items-center gap-2"
              >
                {slotState.fileLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                ) : (
                  <Upload className="w-4 h-4 shrink-0" />
                )}
                <span>{slotState.audioBuffer ? 'File badlo' : 'File chuno'}</span>
              </button>

              {/* Song Name & Duration Display */}
              <div className="min-w-0 flex-1 text-right">
                {slotState.fileLoading ? (
                  <p className="text-xs text-[#E0E0E0] truncate">
                    Audio decode ho raha hai...
                  </p>
                ) : slotState.audioBuffer ? (
                  <div>
                    <p
                      className="text-sm font-medium text-white truncate"
                      title={displaySongName || ''}
                    >
                      {displaySongName}
                    </p>
                    <p className="text-xs text-[#AAAAAA] font-mono tabular-nums truncate mt-0.5">
                      <span>{formatDuration(slotState.durationSec)}</span>
                      {isTrimmed && (
                        <>
                          <span aria-hidden="true"> / </span>
                          <span>{formatDuration(fullDur)} full</span>
                        </>
                      )}
                      {slotState.fileName && slotState.ytInfo ? (
                        <>
                          <span aria-hidden="true"> · </span>
                          <span className="font-sans">{slotState.fileName}</span>
                        </>
                      ) : null}
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-[#AAAAAA]">
                    Device se MP3 / WAV / M4A select karo
                  </p>
                )}
              </div>
            </div>

            {/* Plain-words permission reason shown ONLY when user taps "File chuno" (never at launch) */}
            {showPickerReason &&
              !slotState.audioBuffer &&
              !slotState.filePermissionDenied &&
              !slotState.fileError && (
                <p className="text-xs text-[#AAAAAA] leading-snug">
                  Agar phone permission maange: Gaana import karne ke liye file ki permission chahiye.
                </p>
              )}

            {/* Explicit Permission Denied Card + Settings Guidance + Retry Button */}
            {slotState.filePermissionDenied ? (
              <div
                role="alert"
                className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3.5 py-3 text-xs text-[#E0E0E0] space-y-2.5"
              >
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-semibold text-white">
                      Permission nahi mili — File chuno kaam nahi karega
                    </p>
                    <p className="text-[#E0E0E0] leading-relaxed">
                      Gaana import karne ke liye file ki permission chahiye.{' '}
                      <strong className="font-semibold text-white">
                        Settings &gt; Apps &gt; Song Merger &gt; Permissions me allow karo
                      </strong>
                      , phir niche Retry dabao (dobara install karne ki zaroorat nahi).
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={openSystemFilePicker}
                  className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] font-semibold text-xs inline-flex items-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                  <span>Retry</span>
                </button>
              </div>
            ) : (
              slotState.fileError && (
                <div
                  role="alert"
                  className="rounded-xl border border-red-500/45 bg-[#1A1A1A] px-3.5 py-2.5 text-xs text-red-300 flex items-center justify-between gap-2"
                >
                  <span className="inline-flex items-start gap-1.5 min-w-0">
                    <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                    <span>{slotState.fileError}</span>
                  </span>
                  <button
                    type="button"
                    onClick={openSystemFilePicker}
                    className="min-h-[34px] px-3 py-1 rounded-lg bg-[#222222] border border-[#333333] text-white font-semibold hover:bg-[#2C2C2C] whitespace-nowrap shrink-0 inline-flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3 shrink-0" />
                    <span>Retry</span>
                  </button>
                </div>
              )
            )}
          </>
        )}

        {/* Individual Song Preview Player + Tap-to-Set Start/End Buttons */}
        {webAudioSupported && slotState.fullAudioBuffer && slotState.audioBuffer && (
          <div className="pt-1 space-y-2.5">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onTogglePreview}
                aria-label={
                  isPlaying ? `Pause Song ${slotNumber}` : `Play Song ${slotNumber}`
                }
                className="min-h-[44px] min-w-[44px] w-11 h-11 rounded-xl bg-[#222222] border border-[#333333] text-white hover:bg-[#2C2C2C] transition-colors flex items-center justify-center shrink-0"
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4 fill-current" />
                ) : (
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <div className="relative flex items-center">
                  <div className="relative w-full h-2 bg-[#333333] rounded-full overflow-hidden pointer-events-none">
                    {/* Selected Start..End trim region indicator */}
                    <div
                      className="absolute top-0 bottom-0 bg-white/25"
                      style={{
                        left: `${trimStartPct}%`,
                        width: `${trimWidthPct}%`,
                      }}
                    />
                    <div
                      className="relative h-full bg-white transition-none"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={fullDur || 1}
                    step={0.1}
                    value={Math.min(currentTimeSec, fullDur)}
                    onChange={(e) => onSeekPreview(parseFloat(e.target.value))}
                    aria-label={`Seek Song ${slotNumber}`}
                    className="scrub-slider absolute inset-0 w-full"
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#AAAAAA] font-mono tabular-nums mt-0.5">
                  <span>{formatDuration(currentTimeSec)}</span>
                  <span className="inline-flex items-center gap-1 font-sans text-[#AAAAAA] truncate max-w-[65%]">
                    <FileAudio className="w-3 h-3 shrink-0" />
                    <span className="truncate">{slotState.fileName}</span>
                  </span>
                  <span>{formatDuration(fullDur)}</span>
                </div>
              </div>
            </div>

            {/* Tap-to-Set Start / End While Playing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-0.5">
              <div className="flex items-center justify-between gap-2 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] px-2.5 py-1.5">
                <button
                  type="button"
                  onClick={handleTapSetStartHere}
                  className="min-h-[38px] px-3 py-1.5 rounded-lg bg-[#222222] border border-[#333333] hover:bg-[#2C2C2C] active:scale-[0.98] text-xs font-semibold text-white transition-all whitespace-nowrap shrink-0"
                >
                  Start yahan se
                </button>
                <span className="text-xs font-semibold font-mono tabular-nums text-white pr-1 whitespace-nowrap">
                  {formatDuration(slotState.trimStartSec)}
                </span>
              </div>

              <div className="flex items-center justify-between gap-2 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] px-2.5 py-1.5">
                <button
                  type="button"
                  onClick={handleTapSetEndHere}
                  className="min-h-[38px] px-3 py-1.5 rounded-lg bg-[#222222] border border-[#333333] hover:bg-[#2C2C2C] active:scale-[0.98] text-xs font-semibold text-white transition-all whitespace-nowrap shrink-0"
                >
                  End yahan tak
                </button>
                <span className="text-xs font-semibold font-mono tabular-nums text-white pr-1 whitespace-nowrap">
                  {formatDuration(slotState.trimEndSec)}
                </span>
              </div>
            </div>

            {/* Trim Validation Message */}
            {trimValidationError && (
              <p
                role="alert"
                className="text-xs text-red-400 font-medium flex items-center gap-1.5"
              >
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{trimValidationError}</span>
              </p>
            )}
          </div>
        )}

        {/* Manual Cut / Trim Controls (Start MM:SS & End MM:SS) */}
        {webAudioSupported && slotState.fullAudioBuffer && slotState.audioBuffer && (
          <div className="pt-2.5 border-t border-[#2A2A2A] space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-white inline-flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-[#AAAAAA] shrink-0" />
                <span>Cut / Trim (MM:SS)</span>
              </span>
              {isTrimmed && (
                <button
                  type="button"
                  onClick={() => {
                    setTrimValidationError(null);
                    onTrimChange(0, fullDur, true);
                  }}
                  className="min-h-[32px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#333333] text-xs font-medium text-white hover:bg-[#2C2C2C] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Full song</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor={`trim-start-${slotNumber}`}
                  className="block text-xs font-medium text-[#AAAAAA] mb-1"
                >
                  Start (MM:SS)
                </label>
                <input
                  id={`trim-start-${slotNumber}`}
                  type="text"
                  inputMode="text"
                  value={startInput}
                  onChange={(e) => setStartInput(e.target.value)}
                  onBlur={(e) => commitStartText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      commitStartText(startInput);
                    }
                  }}
                  placeholder="0:00"
                  className="w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums bg-[#1A1A1A] border border-[#333333] rounded-xl text-white placeholder:text-[#777777] focus:outline-none focus:ring-2 focus:ring-white/20 focus:border-white"
                />
                <input
                  type="range"
                  min={0}
                  max={Math.max(0, fullDur - minClipSec)}
                  step={0.5}
                  value={Math.min(
                    slotState.trimStartSec,
                    Math.max(0, fullDur - minClipSec)
                  )}
                  onChange={(e) => {
                    const nextStart = Math.min(
                      parseFloat(e.target.value),
                      Math.max(0, slotState.trimEndSec - minClipSec)
                    );
                    setTrimValidationError(null);
                    onTrimChange(nextStart, slotState.trimEndSec, true);
                  }}
                  aria-label={`Song ${slotNumber} Start time slider`}
                  className="studio-slider mt-0.5"
                />
              </div>

              <div>
                <label
                  htmlFor={`trim-end-${slotNumber}`}
                  className="block text-xs font-medium text-[#AAAAAA] mb-1"
                >
                  End (MM:SS)
                </label>
                <input
                  id={`trim-end-${slotNumber}`}
                  type="text"
                  inputMode="text"
                  value={endInput}
                  onChange={(e) => setEndInput(e.target.value)}
                  onBlur={(e) => commitEndText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      commitEndText(endInput);
                    }
                  }}
                  placeholder={formatDuration(fullDur)}
                  className="w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums bg-[#1A1A1A] border border-[#333333] rounded-xl text-white placeholder:text-[#777777] focus:outline-none focus:ring-2 focus:ring-white/20 focus:border-white"
                />
                <input
                  type="range"
                  min={minClipSec}
                  max={fullDur || 1}
                  step={0.5}
                  value={Math.max(minClipSec, slotState.trimEndSec)}
                  onChange={(e) => {
                    const nextEnd = Math.max(
                      parseFloat(e.target.value),
                      Math.min(fullDur, slotState.trimStartSec + minClipSec)
                    );
                    setTrimValidationError(null);
                    onTrimChange(slotState.trimStartSec, nextEnd, true);
                  }}
                  aria-label={`Song ${slotNumber} End time slider`}
                  className="studio-slider mt-0.5"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-[#AAAAAA] font-mono tabular-nums -mt-1">
              <span>
                Selected: {formatDuration(slotState.trimStartSec)} –{' '}
                {formatDuration(slotState.trimEndSec)}
              </span>
              <span>Cut length: {formatDuration(slotState.durationSec)}</span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
