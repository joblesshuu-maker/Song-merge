import React from 'react';
import {
  AlertCircle,
  Check,
  Loader2,
  RotateCcw,
  ShieldCheck,
  X,
} from 'lucide-react';
import { HealthCheckItem } from '../utils/healthCheck';

interface HealthCheckPanelProps {
  isOpen: boolean;
  isRunning: boolean;
  items: HealthCheckItem[];
  onRerun: () => void;
  onDismiss: () => void;
}

export const HealthCheckPanel: React.FC<HealthCheckPanelProps> = ({
  isOpen,
  isRunning,
  items,
  onRerun,
  onDismiss,
}) => {
  if (!isOpen) return null;

  const failCount = items.filter((i) => i.status === 'fail').length;
  const passCount = items.filter((i) => i.status === 'pass').length;

  return (
    <section
      aria-label="App Health Check"
      className="mb-5 bg-[#111111] rounded-2xl border border-[#2A2A2A] p-4 sm:p-5 space-y-3.5"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <ShieldCheck className="w-4 h-4 text-white shrink-0" />
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-white">
              App Health Check{' '}
              {!isRunning && items.length > 0 && (
                <span className="font-mono tabular-nums text-xs font-medium text-[#AAAAAA] ml-1">
                  ({passCount}/{items.length} pass)
                </span>
              )}
            </h2>
            <p className="text-xs text-[#AAAAAA] mt-0.5">
              {isRunning
                ? 'Device features aur audio libraries check ho rahi hain...'
                : failCount === 0
                  ? 'Sabhi features is phone/browser par ready hain.'
                  : `${failCount} check me dhyan dein — niche plain fix diya hai.`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            disabled={isRunning}
            onClick={onRerun}
            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#2A2A2A] hover:bg-[#2C2C2C] disabled:opacity-50 text-xs font-semibold text-white inline-flex items-center gap-1.5 transition-colors whitespace-nowrap"
          >
            {isRunning ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
            ) : (
              <RotateCcw className="w-3.5 h-3.5 shrink-0" />
            )}
            <span>Retry</span>
          </button>

          <button
            type="button"
            onClick={onDismiss}
            aria-label="Band karo"
            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#2A2A2A] hover:bg-[#2C2C2C] text-xs font-medium text-white inline-flex items-center gap-1 transition-colors whitespace-nowrap"
          >
            <X className="w-3.5 h-3.5 shrink-0" />
            <span>Band karo</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
        {items.map((item) => (
          <div
            key={item.key}
            className={`rounded-xl border px-3 py-2.5 text-xs bg-[#1A1A1A] ${
              item.status === 'fail'
                ? 'border-red-500/45 text-white'
                : 'border-[#2A2A2A] text-[#E0E0E0]'
            }`}
          >
            <div className="flex items-center gap-1.5 font-semibold text-white">
              {item.status === 'checking' ? (
                <Loader2 className="w-3.5 h-3.5 text-white animate-spin shrink-0" />
              ) : item.status === 'pass' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
              )}
              <span className="truncate">{item.label}</span>
            </div>
            <p className="text-[11px] text-[#AAAAAA] mt-1 leading-snug">
              {item.detail}
            </p>
            {item.status === 'fail' && item.fixHint && (
              <p className="text-[11px] text-[#E0E0E0] font-medium mt-1.5 leading-snug border-t border-[#2A2A2A] pt-1.5">
                Fix: {item.fixHint}
              </p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};
