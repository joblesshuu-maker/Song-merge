import React, { useState } from 'react';
import { Check, Copy, Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const InstallAppButton: React.FC = () => {
  const {
    canDirectInstall,
    isInstalled,
    isIOS,
    isInIframe,
    triggerNativeInstall,
  } = usePWAInstall();

  const [showGuide, setShowGuide] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  // Automatically hide once running as an installed phone app / WebAPK / standalone PWA
  if (isInstalled) {
    return null;
  }

  const handleInstallClick = async () => {
    if (canDirectInstall) {
      const outcome = await triggerNativeInstall();
      if (
        outcome === 'installed' ||
        outcome === 'apk-download' ||
        outcome === 'dismissed'
      ) {
        setShowGuide(false);
        return;
      }
    }
    setShowGuide((prev) => !prev);
  };

  const handleCopyPublishedUrl = async () => {
    const shareableUrl = window.location.href;
    try {
      await navigator.clipboard.writeText(shareableUrl);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      try {
        const ta = document.createElement('textarea');
        ta.value = shareableUrl;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        setCopiedUrl(true);
        window.setTimeout(() => setCopiedUrl(false), 2500);
      } catch {
        // Ignore clipboard restriction
      }
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={handleInstallClick}
        className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-[#222222] text-white border border-[#2A2A2A] hover:bg-[#2C2C2C] active:scale-[0.98] text-xs font-semibold transition-all inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
      >
        <Download className="w-3.5 h-3.5 shrink-0" />
        <span>Install APK</span>
      </button>

      {showGuide && (
        <div
          role="dialog"
          aria-label="Phone me app install karein"
          className="fixed inset-x-3 top-16 sm:absolute sm:inset-x-auto sm:right-0 sm:top-full sm:mt-2 sm:w-80 z-40 rounded-2xl bg-[#111111] border border-[#2A2A2A] shadow-2xl p-4 space-y-3 text-left"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-white shrink-0" />
              <h3 className="text-sm font-bold text-white">
                Phone me Direct Install karo
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setShowGuide(false)}
              aria-label="Close install guide"
              className="w-7 h-7 rounded-lg text-[#AAAAAA] hover:text-white hover:bg-[#222222] flex items-center justify-center shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {isIOS ? (
            <div className="text-xs text-[#E0E0E0] space-y-1.5 leading-relaxed">
              <p>
                1. Safari ke niche <strong className="text-white">Share</strong> button dabao.
              </p>
              <p>
                2. <strong className="text-white">Add to Home Screen</strong> chuno — app seedha phone par install ho jayega (offline bhi chalega).
              </p>
            </div>
          ) : isInIframe ? (
            <div className="text-xs text-[#E0E0E0] space-y-2 leading-relaxed">
              <p>
                Abhi aap preview window me ho. App publish hone ke baad phone me seedha APK / App install karne ke liye:
              </p>
              <ol className="list-decimal pl-4 space-y-1">
                <li>
                  Published link ko apne Android phone ke <strong className="text-white">Chrome</strong> browser me kholo.
                </li>
                <li>
                  Wahan upar yahi <strong className="text-white">Install APK</strong> button dabao — Chrome seedha phone me app (WebAPK) install kar dega!
                </li>
              </ol>
              <button
                type="button"
                onClick={handleCopyPublishedUrl}
                className="w-full min-h-[40px] mt-1 px-3 py-2 rounded-xl bg-[#222222] text-white border border-[#333333] hover:bg-[#2C2C2C] text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors"
              >
                {copiedUrl ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>App Link Copy ho gaya</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 shrink-0" />
                    <span>App Link Copy karo (Phone ke liye)</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="text-xs text-[#E0E0E0] space-y-2 leading-relaxed">
              <p>
                Phone me seedha install karne ke liye browser ke upar right corner me{' '}
                <strong className="text-white">⋮ (Menu)</strong> dabao aur{' '}
                <strong className="text-white">Install app</strong> ya{' '}
                <strong className="text-white">Add to Home screen</strong> chuno.
              </p>
              <p className="text-[11px] text-[#AAAAAA]">
                Install hone ke baad bina internet ke bhi File chuno, Trim, Merge aur 320 kbps MP3 export kaam karega.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
