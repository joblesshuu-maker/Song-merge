import React from 'react';
import { AlertCircle, RotateCcw } from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  public state: ErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: unknown): ErrorBoundaryState {
    const msg =
      error instanceof Error && error.message
        ? error.message
        : 'Koi unexpected error aaya hai.';
    return {
      hasError: true,
      errorMessage: msg,
    };
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black text-[#E0E0E0] flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#111111] rounded-2xl border border-[#2A2A2A] p-6 space-y-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div className="min-w-0">
                <h1 className="text-base font-bold text-white">
                  App me ek error aa gaya
                </h1>
                <p className="text-sm text-[#E0E0E0] mt-1 leading-relaxed">
                  Chinta mat karo — aapki settings safe hain. Niche Retry dabakar app ko dobara chalu karo.
                </p>
                {this.state.errorMessage && (
                  <p className="text-xs text-red-300 bg-[#1A1A1A] border border-red-500/40 rounded-xl px-3 py-2 mt-2.5 break-words">
                    {this.state.errorMessage}
                  </p>
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false, errorMessage: '' });
              }}
              className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-white text-black hover:bg-[#E8E8E8] font-bold text-sm inline-flex items-center justify-center gap-2 transition-colors"
            >
              <RotateCcw className="w-4 h-4 shrink-0" />
              <span>Retry</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
