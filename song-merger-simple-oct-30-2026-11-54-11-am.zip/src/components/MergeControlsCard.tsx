import React, { useEffect, useRef } from 'react';
import { RotateCcw } from 'lucide-react';
import { MergeSettings, SpeedMode, TrackAnalysis } from '../types/audio';

interface MergeControlsCardProps {
  settings: MergeSettings;
  song1Analysis: TrackAnalysis | null;
  song2Analysis: TrackAnalysis | null;
  webAudioSupported?: boolean;
  audioLibsReady?: boolean;
  disabled?: boolean;
  onChange: (next: MergeSettings) => void;
  onControlSettled: (settled: MergeSettings, shouldAutoStartLoop: boolean) => void;
  onUserAudioGesture?: () => void;
}

export const MergeControlsCard: React.FC<MergeControlsCardProps> = ({
  settings,
  song1Analysis,
  song2Analysis,
  webAudioSupported = true,
  audioLibsReady = true,
  disabled = false,
  onChange,
  onControlSettled,
  onUserAudioGesture,
}) => {
  const latestSettingsRef = useRef<MergeSettings>(settings);
  const lastSettledSigRef = useRef<string>(JSON.stringify(settings));
  const draggingRef = useRef<boolean>(false);
  const settleTimerRef = useRef<number | null>(null);

  latestSettingsRef.current = settings;

  useEffect(() => {
    if (!draggingRef.current && settleTimerRef.current === null) {
      lastSettledSigRef.current = JSON.stringify(settings);
    }
  }, [settings]);

  useEffect(() => {
    return () => {
      if (settleTimerRef.current !== null) {
        window.clearTimeout(settleTimerRef.current);
      }
    };
  }, []);

  const flushSettled = (shouldAutoStartLoop: boolean) => {
    const current = latestSettingsRef.current;
    const sig = JSON.stringify(current);
    if (sig === lastSettledSigRef.current) return;
    lastSettledSigRef.current = sig;
    onControlSettled(current, shouldAutoStartLoop);
  };

  const scheduleSettleAfterRelease = () => {
    if (settleTimerRef.current !== null) {
      window.clearTimeout(settleTimerRef.current);
    }
    settleTimerRef.current = window.setTimeout(() => {
      settleTimerRef.current = null;
      if (!draggingRef.current) {
        flushSettled(true);
      }
    }, 25);
  };

  const handleSliderPressStart = () => {
    draggingRef.current = true;
    onUserAudioGesture?.();
  };

  const handleSliderRelease = () => {
    draggingRef.current = false;
    onUserAudioGesture?.();
    scheduleSettleAfterRelease();
  };

  const handleSliderChange = <K extends 'crossfadeSec' | 'speed' | 'pitchSemitones'>(
    key: K,
    value: MergeSettings[K]
  ) => {
    const next: MergeSettings = {
      ...latestSettingsRef.current,
      [key]: value,
    };
    latestSettingsRef.current = next;
    if (!draggingRef.current) {
      scheduleSettleAfterRelease();
    }
    onChange(next);
  };

  const handleSpeedModeSelect = (mode: SpeedMode) => {
    if (latestSettingsRef.current.speedMode === mode) return;
    onUserAudioGesture?.();
    const next: MergeSettings = {
      ...latestSettingsRef.current,
      speedMode: mode,
    };
    latestSettingsRef.current = next;
    lastSettledSigRef.current = JSON.stringify(next);
    onChange(next);
    // If speed is non-1.0, switching mode audibly changes pitch immediately -> auto-loop so user hears it right away
    onControlSettled(next, Math.abs(next.speed - 1.0) > 0.002);
  };

  const hasCustomSpeedOrPitch =
    Math.abs(settings.speed - 1.0) > 0.001 || settings.pitchSemitones !== 0;

  // Automatic semitone shift caused by tape speed when in "Speed — Pitch bhi badle" mode
  const tapePitchShiftSemitones =
    settings.speedMode === 'tape-pitch'
      ? Math.round(12 * Math.log2(settings.speed) * 10) / 10
      : 0;

  let autoMatchDetail = 'Song 2 ka tempo Song 1 se smooth match hoga';
  if (settings.autoMatch && song1Analysis?.bpm && song2Analysis?.bpm) {
    autoMatchDetail = `${Math.round(song2Analysis.bpm)} BPM → ${Math.round(
      song1Analysis.bpm
    )} BPM par match hoga`;
  } else if (!settings.autoMatch) {
    autoMatchDetail = 'Band hai — sirf niche ke manual sliders chalenge';
  }

  if (!webAudioSupported || !audioLibsReady) {
    return (
      <section className="bg-[#111111] rounded-2xl border border-[#2A2A2A] p-5 sm:p-6 space-y-2.5">
        <h2 className="text-base sm:text-lg font-semibold text-white tracking-tight">
          03. Mix Controls
        </h2>
        <p className="text-xs text-[#AAAAAA] leading-relaxed">
          {!webAudioSupported
            ? 'Is phone/WebView me Web Audio support nahi mila, isliye mix controls chhupa diye gaye hain. Android System WebView ya Chrome update karo.'
            : 'Audio processing library load hone ka intezaar hai — niche Merge & Export card me Retry dabao.'}
        </p>
      </section>
    );
  }

  return (
    <section className="bg-[#111111] rounded-2xl border border-[#2A2A2A] p-5 sm:p-6 space-y-5">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-base sm:text-lg font-semibold text-white tracking-tight">
          03. Mix Controls
        </h2>
        {hasCustomSpeedOrPitch && (
          <button
            type="button"
            disabled={disabled}
            onClick={() => {
              onUserAudioGesture?.();
              const next: MergeSettings = {
                ...latestSettingsRef.current,
                speed: 1.0,
                pitchSemitones: 0,
              };
              latestSettingsRef.current = next;
              lastSettledSigRef.current = JSON.stringify(next);
              onChange(next);
              onControlSettled(next, true);
            }}
            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-[#222222] border border-[#333333] text-xs font-medium text-white hover:bg-[#2C2C2C] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Speed/Pitch reset</span>
          </button>
        )}
      </div>

      {/* Crossfade Duration Slider (0 - 15s, default 8s) */}
      <div>
        <div className="flex items-baseline justify-between gap-2">
          <label
            htmlFor="crossfade-slider"
            className="text-sm font-medium text-[#E0E0E0]"
          >
            Crossfade (smooth overlap)
          </label>
          <span className="text-sm font-semibold font-mono tabular-nums text-white">
            {settings.crossfadeSec.toFixed(1).replace(/\.0$/, '')}s
          </span>
        </div>
        <input
          id="crossfade-slider"
          type="range"
          min={0}
          max={15}
          step={0.5}
          disabled={disabled}
          value={settings.crossfadeSec}
          onPointerDown={handleSliderPressStart}
          onTouchStart={handleSliderPressStart}
          onMouseDown={handleSliderPressStart}
          onPointerUp={handleSliderRelease}
          onPointerCancel={handleSliderRelease}
          onTouchEnd={handleSliderRelease}
          onMouseUp={handleSliderRelease}
          onKeyUp={handleSliderRelease}
          onChange={(e) =>
            handleSliderChange('crossfadeSec', parseFloat(e.target.value))
          }
          className="studio-slider mt-0.5"
        />
        <div className="flex justify-between text-[11px] text-[#AAAAAA] font-mono tabular-nums -mt-1.5">
          <span>0s</span>
          <span>8s (best)</span>
          <span>15s</span>
        </div>
      </div>

      <div className="border-t border-[#2A2A2A]" />

      {/* Auto Match Toggle */}
      <div className="flex items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-white">Auto Match</p>
          <p className="text-xs text-[#AAAAAA] mt-0.5 leading-snug">
            {autoMatchDetail}
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={settings.autoMatch}
          disabled={disabled}
          onClick={() => {
            onUserAudioGesture?.();
            const next: MergeSettings = {
              ...latestSettingsRef.current,
              autoMatch: !latestSettingsRef.current.autoMatch,
            };
            latestSettingsRef.current = next;
            lastSettledSigRef.current = JSON.stringify(next);
            onChange(next);
            onControlSettled(next, false);
          }}
          className={`min-h-[44px] min-w-[76px] px-3.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap shrink-0 flex items-center justify-between gap-2 border ${
            settings.autoMatch
              ? 'bg-white text-black border-white'
              : 'bg-[#222222] text-[#AAAAAA] border-[#333333] hover:bg-[#2C2C2C]'
          }`}
        >
          <span>{settings.autoMatch ? 'ON' : 'OFF'}</span>
          <span
            className={`w-3.5 h-3.5 rounded-full transition-transform ${
              settings.autoMatch ? 'bg-black' : 'bg-[#777777]'
            }`}
          />
        </button>
      </div>

      <div className="border-t border-[#2A2A2A]" />

      {/* Speed Mode Selector (mutually exclusive radio options) + Speed & Pitch Sliders */}
      <div className="space-y-3.5">
        <div className="space-y-2">
          <p className="text-xs font-semibold text-[#E0E0E0]">Speed Mode</p>
          <div
            role="radiogroup"
            aria-label="Speed Mode"
            className="grid grid-cols-1 gap-2"
          >
            <button
              type="button"
              role="radio"
              aria-checked={settings.speedMode === 'preserve-pitch'}
              disabled={disabled}
              onClick={() => handleSpeedModeSelect('preserve-pitch')}
              className={`min-h-[44px] px-3.5 py-2.5 rounded-xl border text-left transition-colors flex items-center gap-3 ${
                settings.speedMode === 'preserve-pitch'
                  ? 'border-white bg-[#222222] text-white'
                  : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#E0E0E0] hover:bg-[#222222]'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                  settings.speedMode === 'preserve-pitch'
                    ? 'border-white'
                    : 'border-[#777777]'
                }`}
              >
                {settings.speedMode === 'preserve-pitch' && (
                  <span className="w-2 h-2 rounded-full bg-white" />
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-xs sm:text-sm font-semibold text-white leading-snug">
                  Speed — Pitch same rahe
                </span>
                <span className="block text-[11px] text-[#AAAAAA] leading-snug mt-0.5">
                  Sirf tempo badlega, pitch wahi rahegi (time-stretch)
                </span>
              </span>
            </button>

            <button
              type="button"
              role="radio"
              aria-checked={settings.speedMode === 'tape-pitch'}
              disabled={disabled}
              onClick={() => handleSpeedModeSelect('tape-pitch')}
              className={`min-h-[44px] px-3.5 py-2.5 rounded-xl border text-left transition-colors flex items-center gap-3 ${
                settings.speedMode === 'tape-pitch'
                  ? 'border-white bg-[#222222] text-white'
                  : 'border-[#2A2A2A] bg-[#1A1A1A] text-[#E0E0E0] hover:bg-[#222222]'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                  settings.speedMode === 'tape-pitch'
                    ? 'border-white'
                    : 'border-[#777777]'
                }`}
              >
                {settings.speedMode === 'tape-pitch' && (
                  <span className="w-2 h-2 rounded-full bg-white" />
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-xs sm:text-sm font-semibold text-white leading-snug">
                  Speed — Pitch bhi badle
                </span>
                <span className="block text-[11px] text-[#AAAAAA] leading-snug mt-0.5">
                  Tape/vinyl jaisa — fast pe pitch high, slow pe pitch low
                </span>
              </span>
            </button>
          </div>
        </div>

        {/* Speed Slider (0.5x - 1.5x) */}
        <div className="pt-0.5">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="speed-slider"
              className="text-sm font-medium text-[#E0E0E0]"
            >
              {settings.speedMode === 'preserve-pitch'
                ? 'Speed (bina pitch badle)'
                : 'Speed (pitch ke saath)'}
            </label>
            <span className="text-sm font-semibold font-mono tabular-nums text-white">
              {settings.speed.toFixed(2)}x
              {settings.speedMode === 'tape-pitch' &&
                Math.abs(tapePitchShiftSemitones) >= 0.1 && (
                  <span className="text-xs font-normal text-[#AAAAAA] ml-1.5">
                    ({tapePitchShiftSemitones > 0 ? '+' : ''}
                    {tapePitchShiftSemitones.toFixed(1)} st)
                  </span>
                )}
            </span>
          </div>
          <input
            id="speed-slider"
            type="range"
            min={0.5}
            max={1.5}
            step={0.05}
            disabled={disabled}
            value={settings.speed}
            onPointerDown={handleSliderPressStart}
            onTouchStart={handleSliderPressStart}
            onMouseDown={handleSliderPressStart}
            onPointerUp={handleSliderRelease}
            onPointerCancel={handleSliderRelease}
            onTouchEnd={handleSliderRelease}
            onMouseUp={handleSliderRelease}
            onKeyUp={handleSliderRelease}
            onChange={(e) =>
              handleSliderChange('speed', parseFloat(e.target.value))
            }
            className="studio-slider mt-0.5"
          />
          <div className="flex justify-between text-[11px] text-[#AAAAAA] font-mono tabular-nums -mt-1.5">
            <span>0.5x</span>
            <span>1.0x</span>
            <span>1.5x</span>
          </div>
        </div>

        {/* Manual Pitch Slider (-6 to +6 semitones — works in BOTH modes as extra pitch shift) */}
        <div className="pt-1">
          <div className="flex items-baseline justify-between gap-2">
            <label
              htmlFor="pitch-slider"
              className="text-sm font-medium text-[#E0E0E0]"
            >
              {settings.speedMode === 'preserve-pitch'
                ? 'Pitch (bina speed badle)'
                : 'Pitch (extra shift upar/niche)'}
            </label>
            <span className="text-sm font-semibold font-mono tabular-nums text-white">
              {settings.pitchSemitones > 0
                ? `+${settings.pitchSemitones}`
                : settings.pitchSemitones}{' '}
              semitones
            </span>
          </div>
          <input
            id="pitch-slider"
            type="range"
            min={-6}
            max={6}
            step={1}
            disabled={disabled}
            value={settings.pitchSemitones}
            onPointerDown={handleSliderPressStart}
            onTouchStart={handleSliderPressStart}
            onMouseDown={handleSliderPressStart}
            onPointerUp={handleSliderRelease}
            onPointerCancel={handleSliderRelease}
            onTouchEnd={handleSliderRelease}
            onMouseUp={handleSliderRelease}
            onKeyUp={handleSliderRelease}
            onChange={(e) =>
              handleSliderChange('pitchSemitones', parseInt(e.target.value, 10))
            }
            className="studio-slider mt-0.5"
          />
          <div className="flex justify-between text-[11px] text-[#AAAAAA] font-mono tabular-nums -mt-1.5">
            <span>-6</span>
            <span>0</span>
            <span>+6</span>
          </div>
        </div>
      </div>

      <div className="border-t border-[#2A2A2A]" />

      {/* Lofi One-Tap Toggle */}
      <div className="flex items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-white">Lofi</p>
          <p className="text-xs text-[#AAAAAA] mt-0.5 leading-snug">
            0.85x slow vibe · warm 3500 Hz muffled filter · soft vinyl feel
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={settings.lofi}
          disabled={disabled}
          onClick={() => {
            onUserAudioGesture?.();
            const next: MergeSettings = {
              ...latestSettingsRef.current,
              lofi: !latestSettingsRef.current.lofi,
            };
            latestSettingsRef.current = next;
            lastSettledSigRef.current = JSON.stringify(next);
            onChange(next);
            onControlSettled(next, true);
          }}
          className={`min-h-[44px] min-w-[76px] px-3.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap shrink-0 flex items-center justify-between gap-2 border ${
            settings.lofi
              ? 'bg-white text-black border-white'
              : 'bg-[#222222] text-[#AAAAAA] border-[#333333] hover:bg-[#2C2C2C]'
          }`}
        >
          <span>{settings.lofi ? 'ON' : 'OFF'}</span>
          <span
            className={`w-3.5 h-3.5 rounded-full transition-transform ${
              settings.lofi ? 'bg-black' : 'bg-[#777777]'
            }`}
          />
        </button>
      </div>
    </section>
  );
};
